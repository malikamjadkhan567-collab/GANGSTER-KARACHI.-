package com.example

import com.example.data.model.*
import com.example.data.repository.VehicleRepository
import com.example.data.repository.WeaponCombatRepository
import com.example.data.repository.WorldRepository
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {

  private val dummyDao = object : com.example.data.local.WorldDao {
    override fun getAllMarkers() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.SavedMarkerEntity>())
    override suspend fun insertMarker(marker: com.example.data.local.SavedMarkerEntity) = 1L
    override suspend fun deleteMarker(marker: com.example.data.local.SavedMarkerEntity) {}
    override suspend fun deleteMarkerById(id: Long) {}
    override fun getDiscoveredDistricts() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.DiscoveredDistrictEntity>())
    override suspend fun setDistrictDiscovered(entity: com.example.data.local.DiscoveredDistrictEntity) {}
    override fun getAllGarageVehicles() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.SavedVehicleEntity>())
    override fun getGarageVehiclesByOwner(ownerId: String) = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.SavedVehicleEntity>())
    override suspend fun insertGarageVehicle(vehicle: com.example.data.local.SavedVehicleEntity) = 1L
    override suspend fun deleteGarageVehicle(vehicle: com.example.data.local.SavedVehicleEntity) {}
    override suspend fun deleteGarageVehicleById(id: Long) {}
    override fun getAllSavedWeapons() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.SavedWeaponEntity>())
    override fun getWeaponsByOwner(ownerId: String) = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.SavedWeaponEntity>())
    override suspend fun insertSavedWeapon(weapon: com.example.data.local.SavedWeaponEntity) = 1L
    override suspend fun deleteSavedWeapon(weapon: com.example.data.local.SavedWeaponEntity) {}
    override suspend fun deleteSavedWeaponById(id: Long) {}
    override fun getAllProtagonistStates() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.ProtagonistStateEntity>())
    override suspend fun getProtagonistStateById(id: String): com.example.data.local.ProtagonistStateEntity? = null
    override fun observeProtagonistStateById(id: String) = kotlinx.coroutines.flow.flowOf(null)
    override suspend fun saveProtagonistState(state: com.example.data.local.ProtagonistStateEntity) {}
    override suspend fun updateProtagonistLocation(id: String, posX: Float, posY: Float, districtId: String, districtName: String) {}
    override suspend fun updateProtagonistHealth(id: String, health: Float, armor: Float, stamina: Float) {}
    override suspend fun updateProtagonistCash(id: String, cash: Long) {}
    override fun getOutfitsForProtagonist(protagonistId: String) = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.CustomOutfitEntity>())
    override suspend fun insertCustomOutfit(outfit: com.example.data.local.CustomOutfitEntity) = 1L
    override suspend fun deleteCustomOutfit(outfit: com.example.data.local.CustomOutfitEntity) {}
    override suspend fun deleteCustomOutfitById(id: Long) {}
    override fun getAllMissionProgress() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.MissionProgressEntity>())
    override suspend fun saveMissionProgress(entity: com.example.data.local.MissionProgressEntity) {}
    override suspend fun updateMissionStatus(id: String, status: String, rating: String, timestamp: Long) {}
    override fun getAllFactionReputations() = kotlinx.coroutines.flow.flowOf(emptyList<com.example.data.local.FactionReputationEntity>())
    override suspend fun saveFactionReputation(entity: com.example.data.local.FactionReputationEntity) {}
    override suspend fun updateFactionScore(id: String, score: Int, standing: String) {}
  }

  @Test
  fun testDistrictCountAndIntegrity() {
    val repo = WorldRepository(dummyDao)

    // Verify exactly 15 required districts
    assertEquals(15, repo.allDistricts.size)

    val expectedDistricts = listOf(
      "downtown", "defence_gardens", "clifton_heights", "ocean_drive",
      "saddar_central", "tariq_bazaar", "old_town", "lyari_blocks",
      "orangi_district", "industrial_zone", "port_district", "metro_airport",
      "northern_hills", "greenbelt", "fishing_village"
    )
    expectedDistricts.forEach { id ->
      assertNotNull("District $id must exist", repo.getDistrictById(id))
    }

    // Verify 3 distinct protagonists
    assertEquals(3, repo.protagonists.size)
    val ayan = repo.protagonists.find { it.id == "ayan" }
    assertNotNull(ayan)
    assertEquals("lyari_blocks", ayan?.startingDistrictId)

    val shahroz = repo.protagonists.find { it.id == "shahroz" }
    assertNotNull(shahroz)
    assertEquals("port_district", shahroz?.startingDistrictId)

    val daniyal = repo.protagonists.find { it.id == "daniyal" }
    assertNotNull(daniyal)
    assertEquals("defence_gardens", daniyal?.startingDistrictId)

    // Verify Landmark coverage across all 5 mandatory categories
    LandmarkCategory.values().forEach { category ->
      val count = repo.allLandmarks.count { it.category == category }
      assertTrue("Category ${category.name} must have landmarks", count > 0)
    }

    // Verify Hero Tier 1 buildings exist
    val heroLandmarks = repo.allLandmarks.filter { it.interiorTier == InteriorTier.TIER_1_HERO }
    assertTrue("Hero tier 1 landmarks must exist", heroLandmarks.isNotEmpty())
  }

  @Test
  fun testVehicleSystemEcosystemAndPhysics() {
    val vehicleRepo = VehicleRepository(dummyDao)
    val vehicles = vehicleRepo.allVehicles

    // Verify rich vehicle catalog
    assertTrue("Must have at least 15 distinct vehicles", vehicles.size >= 15)

    // Verify category coverage: Sports, Supercars, Muscle, SUVs, Pickups, Motorcycles, Boats, Aircraft, Emergency
    val categories = vehicles.map { it.category }.toSet()
    assertTrue(categories.contains(VehicleCategory.SPORTS))
    assertTrue(categories.contains(VehicleCategory.SUPERCAR))
    assertTrue(categories.contains(VehicleCategory.MUSCLE))
    assertTrue(categories.contains(VehicleCategory.SUV))
    assertTrue(categories.contains(VehicleCategory.PICKUP))
    assertTrue(categories.contains(VehicleCategory.MOTORCYCLE))
    assertTrue(categories.contains(VehicleCategory.BOAT))
    assertTrue(categories.contains(VehicleCategory.AIRCRAFT))
    assertTrue(categories.contains(VehicleCategory.CIVILIAN))
    assertTrue(categories.contains(VehicleCategory.EMERGENCY))

    // Verify Hero Protagonist Affinity vehicles
    val ayanVehicle = vehicles.find { it.id == "veh_khyber_rspec" }
    assertNotNull("Ayan's signature tuner vehicle must exist", ayanVehicle)
    assertEquals("Ayan Khan", ayanVehicle?.protagonistAffinity)

    val shahrozVehicle = vehicles.find { it.id == "veh_shahroz_marauder" }
    assertNotNull("Shahroz's signature heavy 4x4 must exist", shahrozVehicle)
    assertEquals("Shahroz Malik", shahrozVehicle?.protagonistAffinity)

    val daniyalVehicle = vehicles.find { it.id == "veh_daniyal_pegaso" }
    assertNotNull("Daniyal's signature hypercar must exist", daniyalVehicle)
    assertEquals("Daniyal Qureshi", daniyalVehicle?.protagonistAffinity)

    // Verify physics validity
    vehicles.forEach { veh ->
      assertTrue("Mass must be positive", veh.physics.massKg > 0)
      assertTrue("Horsepower must be positive", veh.physics.horsepower > 0)
      assertTrue("Top speed must be positive", veh.physics.topSpeedKmh > 0)
      assertTrue("Gear count must be positive", veh.physics.gearCount > 0)
    }
  }

  @Test
  fun testWeaponCombatAndPoliceSystems() {
    val combatRepo = WeaponCombatRepository(dummyDao)
    val weapons = combatRepo.allWeapons

    // Verify weapon catalog breadth
    assertTrue("Must have at least 12 distinct weapons", weapons.size >= 12)

    val categories = weapons.map { it.category }.toSet()
    assertTrue(categories.contains(WeaponCategory.PISTOL))
    assertTrue(categories.contains(WeaponCategory.SMG))
    assertTrue(categories.contains(WeaponCategory.ASSAULT_RIFLE))
    assertTrue(categories.contains(WeaponCategory.SHOTGUN))
    assertTrue(categories.contains(WeaponCategory.MARKSMAN_SNIPER))
    assertTrue(categories.contains(WeaponCategory.HEAVY))
    assertTrue(categories.contains(WeaponCategory.MELEE))

    // Verify protagonist signature weapons
    val ayanWeapon = weapons.find { it.id == "wep_lyari_striker" }
    assertNotNull("Ayan's signature SMG must exist", ayanWeapon)
    assertEquals("Ayan Khan", ayanWeapon?.protagonistAffinity)

    val shahrozWeapon = weapons.find { it.id == "wep_bolan_ak74" }
    assertNotNull("Shahroz's signature rifle must exist", shahrozWeapon)
    assertEquals("Shahroz Malik", shahrozWeapon?.protagonistAffinity)

    val daniyalWeapon = weapons.find { it.id == "wep_karachi_mptac" }
    assertNotNull("Daniyal's signature suppressed weapon must exist", daniyalWeapon)
    assertEquals("Daniyal Qureshi", daniyalWeapon?.protagonistAffinity)

    // Verify ballistic parameters
    weapons.forEach { wep ->
      assertTrue("Base damage must be positive", wep.baseDamage > 0f)
      assertTrue("Magazine capacity must be positive", wep.magazineCapacity > 0)
      assertTrue("Effective range must be positive", wep.effectiveRangeMeters > 0f)
      assertNotNull("Ammo type must be defined", wep.ammoType)
    }

    // Verify 5-Star Wanted Level escalation tiers
    assertEquals(6, WantedLevel.values().size) // Level 0 to Level 5
    assertEquals(0, WantedLevel.LEVEL_0.stars)
    assertEquals(5, WantedLevel.LEVEL_5.stars)

    // Verify HitZone multipliers
    assertEquals(2.5f, HitZone.HEAD.multiplier, 0.01f)
    assertTrue("Headshot must be critical", HitZone.HEAD.isCritical)
  }

  @Test
  fun testProtagonistCharacterDataAndStatsIntegrity() {
    val charRepo = com.example.data.repository.CharacterRepository(dummyDao)
    val protagonists = charRepo.initialProtagonists

    assertEquals("Must have exactly three playable protagonists", 3, protagonists.size)

    val ayan = protagonists.find { it.id == "ayan" }
    assertNotNull("Ayan must exist", ayan)
    assertEquals("Ayan Khan", ayan?.fullName)
    assertEquals("lyari_blocks", ayan?.homeDistrictId)
    assertTrue("Ayan must specialize in Agility (>= 90)", (ayan?.baseStats?.agility ?: 0) >= 90)
    assertTrue("Ayan must have high Stealth (>= 85)", (ayan?.baseStats?.stealth ?: 0) >= 85)

    val shahroz = protagonists.find { it.id == "shahroz" }
    assertNotNull("Shahroz must exist", shahroz)
    assertEquals("Shahroz Malik", shahroz?.fullName)
    assertEquals("port_district", shahroz?.homeDistrictId)
    assertTrue("Shahroz must specialize in Strength (>= 90)", (shahroz?.baseStats?.strength ?: 0) >= 90)
    assertTrue("Shahroz must specialize in Shooting/Heavy weapons (>= 90)", (shahroz?.baseStats?.shooting ?: 0) >= 90)

    val daniyal = protagonists.find { it.id == "daniyal" }
    assertNotNull("Daniyal must exist", daniyal)
    assertEquals("Daniyal Qureshi", daniyal?.fullName)
    assertEquals("defence_gardens", daniyal?.homeDistrictId)
    assertTrue("Daniyal must specialize in Technical Skill (>= 90)", (daniyal?.baseStats?.technicalSkill ?: 0) >= 90)
    assertTrue("Daniyal must specialize in Social/Business (>= 90)", (daniyal?.baseStats?.socialSkill ?: 0) >= 90)
    assertTrue("Daniyal must specialize in Precision/Accuracy (>= 90)", (daniyal?.baseStats?.accuracy ?: 0) >= 90)

    // Verify distinct locations
    assertNotEquals(ayan?.worldPosX, shahroz?.worldPosX)
    assertNotEquals(shahroz?.worldPosX, daniyal?.worldPosX)
  }

  @Test
  fun testWardrobeCatalogAndPresets() {
    val charRepo = com.example.data.repository.CharacterRepository(dummyDao)
    val catalog = charRepo.clothingCatalog

    assertTrue("Clothing catalog must have at least 15 items across slots", catalog.size >= 15)

    // Verify slots coverage
    val slots = catalog.map { it.slot }.toSet()
    assertTrue(slots.contains(ClothingSlot.UPPER_BODY))
    assertTrue(slots.contains(ClothingSlot.LOWER_BODY))
    assertTrue(slots.contains(ClothingSlot.FOOTWEAR))
    assertTrue(slots.contains(ClothingSlot.HEADWEAR))
    assertTrue(slots.contains(ClothingSlot.EYEWEAR))
    assertTrue(slots.contains(ClothingSlot.WRISTWEAR))

    // Verify default presets exist for each protagonist
    assertTrue(charRepo.defaultAyanOutfits.isNotEmpty())
    assertTrue(charRepo.defaultShahrozOutfits.isNotEmpty())
    assertTrue(charRepo.defaultDaniyalOutfits.isNotEmpty())
  }

  @Test
  fun testMovementProfilesAndAnimation() {
    val charRepo = com.example.data.repository.CharacterRepository(dummyDao)
    val ayan = charRepo.initialProtagonists.find { it.id == "ayan" }
    val shahroz = charRepo.initialProtagonists.find { it.id == "shahroz" }
    val daniyal = charRepo.initialProtagonists.find { it.id == "daniyal" }

    // Ayan has highest sprint speed and fast vaulting
    assertTrue("Ayan must have fastest vault speed", (ayan?.movementProfile?.vaultSpeedSeconds ?: 1f) < 0.45f)
    assertTrue("Ayan must have agile sprint multiplier", (ayan?.movementProfile?.sprintSpeedMultiplier ?: 0f) > 1.2f)

    // Shahroz has heavy knockback and recoil damping
    assertTrue("Shahroz must have highest melee knockback", (shahroz?.movementProfile?.meleeKnockbackMultiplier ?: 0f) > 1.3f)
    assertTrue("Shahroz must have strong recoil damping", (shahroz?.movementProfile?.recoilDampingFactor ?: 0f) > 1.3f)

    // Daniyal has rapid ADS transition
    assertTrue("Daniyal must have fastest aim down sights snap", (daniyal?.movementProfile?.adsTransitionSeconds ?: 1f) <= 0.16f)
  }

  @Test
  fun testProtagonistRelationships() {
    val charRepo = com.example.data.repository.CharacterRepository(dummyDao)
    val ayan = charRepo.initialProtagonists.find { it.id == "ayan" }
    val shahroz = charRepo.initialProtagonists.find { it.id == "shahroz" }
    val daniyal = charRepo.initialProtagonists.find { it.id == "daniyal" }

    assertEquals(2, ayan?.relationships?.size)
    assertEquals(2, shahroz?.relationships?.size)
    assertEquals(2, daniyal?.relationships?.size)

    val ayanToShahroz = ayan?.relationships?.find { it.targetProtagonistId == "shahroz" }
    assertNotNull(ayanToShahroz)
    assertTrue("Ayan respects Shahroz", (ayanToShahroz?.respectScore ?: 0) >= 80)

    val shahrozToDaniyal = shahroz?.relationships?.find { it.targetProtagonistId == "daniyal" }
    assertNotNull(shahrozToDaniyal)
    assertTrue("Shahroz maintains business respect with Daniyal", (shahrozToDaniyal?.respectScore ?: 0) >= 70)
  }

  @Test
  fun testThirtyStoryMissionsIntegrity() {
    val storyRepo = com.example.data.repository.StoryMissionRepository(dummyDao)
    val missions = storyRepo.allMissions

    // Verify exactly 30 missions
    assertEquals("Campaign must contain exactly 30 narrative missions", 30, missions.size)

    // Verify 4 Acts distribution
    val act1 = missions.filter { it.act == StoryAct.ACT_I }
    val act2 = missions.filter { it.act == StoryAct.ACT_II }
    val act3 = missions.filter { it.act == StoryAct.ACT_III }
    val act4 = missions.filter { it.act == StoryAct.ACT_IV }

    assertEquals(8, act1.size) // Missions 1-8
    assertEquals(8, act2.size) // Missions 9-16
    assertEquals(8, act3.size) // Missions 17-24
    assertEquals(6, act4.size) // Missions 25-30

    // Verify rewards and coordinates are valid
    missions.forEach { m ->
      assertTrue("Mission ${m.id} must offer positive cash reward", m.rewardCashPkr > 0)
      assertTrue("Mission ${m.id} must have objectives", m.objectives.isNotEmpty())
      assertTrue("Mission ${m.id} must have at least one protagonist assigned", m.protagonistIds.isNotEmpty())
    }
  }

  @Test
  fun testRomanUrduDialogueAndTranslations() {
    val storyRepo = com.example.data.repository.StoryMissionRepository(dummyDao)
    val missions = storyRepo.allMissions

    // Check that every mission has valid Roman Urdu scripts
    missions.forEach { m ->
      assertTrue("Mission ${m.title} must have dialogue script", m.dialogueScript.isNotEmpty())
      m.dialogueScript.forEach { line ->
        assertTrue("Roman Urdu text must not be empty", line.romanUrduText.isNotBlank())
        assertTrue("English translation must not be empty", line.englishTranslation.isNotBlank())
        assertTrue("Speaker must be assigned", line.speakerName.isNotBlank())
      }
    }
  }

  @Test
  fun testFiveKarachiMetroFactions() {
    val storyRepo = com.example.data.repository.StoryMissionRepository(dummyDao)
    val factions = storyRepo.allFactions

    assertEquals("Must have exactly 5 major factions", 5, factions.size)

    val lsk = factions.find { it.id == "faction_lsk" }
    assertNotNull("Lyari Street Kings must exist", lsk)

    val kps = factions.find { it.id == "faction_kps" }
    assertNotNull("Kemari Port Syndicate must exist", kps)

    val ccg = factions.find { it.id == "faction_ccg" }
    assertNotNull("Clifton Capital Group must exist", ccg)

    val orc = factions.find { it.id == "faction_orc" }
    assertNotNull("Orangi Ridge Cartel must exist", orc)

    val stru = factions.find { it.id == "faction_stru" }
    assertNotNull("Sindh Tactical Response Unit must exist", stru)

    factions.forEach { f ->
      assertTrue("Reputation score must be within [-100, 100]", f.reputationScore in -100..100)
      assertNotNull("Faction standing must be defined", f.standing)
    }
  }

  @Test
  fun testBranchingStoryEndings() {
    assertEquals("Must feature 4 distinct branching endings", 4, StoryEndingChoice.values().size)
    assertNotNull(StoryEndingChoice.valueOf("ENDING_A_BROTHERHOOD"))
    assertNotNull(StoryEndingChoice.valueOf("ENDING_B_CORPORATE"))
    assertNotNull(StoryEndingChoice.valueOf("ENDING_C_PORT_SIEGE"))
    assertNotNull(StoryEndingChoice.valueOf("ENDING_D_LONE_GHOST"))
  }
}
