package com.example.ui.character

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LocomotionMode
import com.example.data.model.PlayableCharacterData
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun CharacterAnimationView(
    viewModel: WorldViewModel,
    activeCharacter: PlayableCharacterData,
    currentLocomotionMode: LocomotionMode,
    modifier: Modifier = Modifier
) {
    val themeColor = Color(activeCharacter.themeColorHex)
    val profile = activeCharacter.movementProfile

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "UE5 ANIMATION BLUEPRINT & LOCOMOTION",
                                style = MaterialTheme.typography.titleMedium,
                                color = KarachiGold,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "Motion Warping • Layered Blend Per Bone • Control Rig IK",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = themeColor.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, themeColor)
                        ) {
                            Text(
                                text = activeCharacter.fullName.uppercase(),
                                color = themeColor,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Live Locomotion State Machine Selector
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("ACTIVE LOCOMOTION STATE MACHINE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(LocomotionMode.values()) { mode ->
                            val isSelected = mode == currentLocomotionMode
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) themeColor else KarachiSurface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) themeColor else KarachiBorder),
                                modifier = Modifier
                                    .clickable { viewModel.setLocomotionMode(mode) }
                                    .testTag("anim_mode_${mode.name}")
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text(
                                        text = mode.title,
                                        color = if (isSelected) Color.Black else TextPrimary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        text = "${mode.speedKmh.toInt()} km/h",
                                        color = if (isSelected) Color.Black.copy(alpha = 0.7f) else TextMuted,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Real-time Velocity & Blend Space Meter
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("BLEND SPACE 1D / DIRECTIONAL VELOCITY", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(14.dp))

                    val speedNormalized = (currentLocomotionMode.speedKmh / 30f).coerceIn(0f, 1f)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "${currentLocomotionMode.speedKmh.toInt()} KM/H",
                            style = MaterialTheme.typography.headlineMedium,
                            color = KarachiCyan,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "STATE: ${currentLocomotionMode.name}",
                            style = MaterialTheme.typography.labelMedium,
                            color = themeColor,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Progress bar
                    LinearProgressIndicator(
                        progress = { speedNormalized },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(10.dp)
                            .clip(RoundedCornerShape(5.dp)),
                        color = themeColor,
                        trackColor = KarachiObsidian
                    )
                }
            }
        }

        // Character-Specific Movement Profile Comparison
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("PROTAGONIST UNIQUE MOVEMENT PROFILE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = profile.signatureMovementStyle,
                        style = MaterialTheme.typography.bodyMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.SemiBold
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    ProfileMetricRow("Sprint Acceleration Multiplier", "${profile.sprintSpeedMultiplier}x", profile.sprintSpeedMultiplier >= 1.2f, themeColor)
                    ProfileMetricRow("Parkour Vault Speed", "${profile.vaultSpeedSeconds}s", profile.vaultSpeedSeconds <= 0.45f, themeColor)
                    ProfileMetricRow("Melee Knockback Multiplier", "${profile.meleeKnockbackMultiplier}x", profile.meleeKnockbackMultiplier >= 1.2f, themeColor)
                    ProfileMetricRow("Aim Down Sights Snap Speed", "${profile.adsTransitionSeconds}s", profile.adsTransitionSeconds <= 0.18f, themeColor)
                    ProfileMetricRow("Heavy Recoil Damping Factor", "${profile.recoilDampingFactor}x", profile.recoilDampingFactor >= 1.2f, themeColor)
                }
            }
        }

        // UE5 Motion Warping & IK Telemetry
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("UE5 SKELETAL RIG & CONTROL RIG TELEMETRY", style = MaterialTheme.typography.labelSmall, color = KarachiGold, fontWeight = FontWeight.Bold)
                    Text("• Foot Placement IK: Two-Bone IK active with surface normal trace (-45cm)", color = TextSecondary, fontSize = 11.sp)
                    Text("• Layered Blend Per Bone: Torso spine_01 blend for weapon aiming while sprinting", color = TextSecondary, fontSize = 11.sp)
                    Text("• Motion Warping: Dynamic hurdle warp targets synchronized with obstacle ledge", color = TextSecondary, fontSize = 11.sp)
                    Text("• Ragdoll to Get-Up: Physical animation blend weight active (Physics Asset)", color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun ProfileMetricRow(label: String, value: String, isSpecialty: Boolean, themeColor: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            if (isSpecialty) {
                Icon(Icons.Default.Star, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(12.dp))
            }
            Text(label, color = TextPrimary, fontSize = 11.5.sp)
        }
        Text(
            value,
            color = if (isSpecialty) themeColor else TextSecondary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}
