package com.example.ui.story

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.StoryEndingChoice
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun BranchingEndingsView(
    viewModel: WorldViewModel,
    modifier: Modifier = Modifier
) {
    var selectedEnding by remember { mutableStateOf<StoryEndingChoice?>(StoryEndingChoice.ENDING_A_BROTHERHOOD) }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("endings_header_card"),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "KARACHI METRO: CLIMACTIC ENDINGS",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "4 Divergent Branching Paths • Player Agency & Narrative Resolution",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
            }
        }

        items(StoryEndingChoice.values()) { ending ->
            val isSelected = selectedEnding == ending
            val themeColor = when (ending) {
                StoryEndingChoice.ENDING_A_BROTHERHOOD -> Color(0xFF10B981)
                StoryEndingChoice.ENDING_B_CORPORATE -> KarachiGold
                StoryEndingChoice.ENDING_C_PORT_SIEGE -> KarachiCrimson
                StoryEndingChoice.ENDING_D_LONE_GHOST -> KarachiCyan
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("ending_card_${ending.name}")
                    .clickable { selectedEnding = ending },
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) KarachiSurface else KarachiDarkNavy
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (isSelected) themeColor else KarachiBorder
                ),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = ending.title,
                            style = MaterialTheme.typography.titleSmall,
                            color = if (isSelected) themeColor else TextPrimary,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = themeColor.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, themeColor)
                        ) {
                            Text(
                                text = ending.endingCode,
                                color = themeColor,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = ending.synopsis,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 12.sp,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = KarachiObsidian,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("SURVIVORS: ${ending.survivorProtagonists}", color = TextPrimary, fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(3.dp))
                            Text("THEMATIC CORE: ${ending.moralTheme}", color = themeColor, fontSize = 10.sp)
                        }
                    }

                    if (isSelected) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Button(
                            onClick = { /* Simulated trigger */ },
                            colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Movie, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "TRIGGER THIS ENDING SCENARIO",
                                color = Color.Black,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}
