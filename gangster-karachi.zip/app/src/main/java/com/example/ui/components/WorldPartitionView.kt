package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.District
import com.example.data.model.WorldDataLayer
import com.example.ui.theme.*
import kotlin.math.abs
import kotlin.math.max

@Composable
fun WorldPartitionView(
    districts: List<District>,
    selectedDistrict: District,
    playerPos: Pair<Float, Float>,
    activeDataLayers: Set<WorldDataLayer>,
    onToggleDataLayer: (WorldDataLayer) -> Unit,
    onSelectCellDistrict: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var streamingDistanceKm by remember { mutableFloatStateOf(1.5f) }

    val gridSize = 8
    val playerCellX = (playerPos.first * gridSize).toInt().coerceIn(0, gridSize - 1)
    val playerCellY = (playerPos.second * gridSize).toInt().coerceIn(0, gridSize - 1)

    // Calculate memory based on active layers
    val totalMemoryMb = activeDataLayers.sumOf { it.memoryMb.toDouble() }.toFloat()
    val maxMemoryBudgetMb = 2500f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("world_partition_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "WORLD PARTITION // STREAMING MATRIX",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "64km² Seamless Karachi Metro Grid • 500m Dynamic Cells",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = KarachiSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan)
                ) {
                    Text(
                        text = "UE5.4 NATIVE",
                        style = MaterialTheme.typography.labelSmall,
                        color = KarachiCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Memory Budget Meter
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("WORLD STREAMING VRAM BUDGET", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
                        Text(
                            "${totalMemoryMb.toInt()} MB / ${maxMemoryBudgetMb.toInt()} MB",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (totalMemoryMb > 2000f) KarachiCrimson else KarachiCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LinearProgressIndicator(
                        progress = { (totalMemoryMb / maxMemoryBudgetMb).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = if (totalMemoryMb > 2000f) KarachiCrimson else KarachiGold,
                        trackColor = KarachiSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Active Nanite Meshes: 184,200", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
                        Text("Lumen Surface Cache: 320 MB", style = MaterialTheme.typography.bodySmall, color = TextMuted, fontSize = 10.sp)
                        Text("Virtual Shadow Maps: Active", style = MaterialTheme.typography.bodySmall, color = KarachiEmerald, fontSize = 10.sp)
                    }
                }
            }
        }

        // Interactive 8x8 Spatial Grid
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("SPATIAL LOADING CELL INSPECTOR", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
                        Text("Player Cell: [$playerCellX, $playerCellY]", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 10.sp)
                    }
                    Spacer(modifier = Modifier.height(10.dp))

                    // 8x8 Grid Box
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(1f)
                            .background(KarachiObsidian, RoundedCornerShape(8.dp))
                            .border(1.dp, KarachiBorder, RoundedCornerShape(8.dp))
                            .padding(4.dp)
                    ) {
                        for (y in 0 until gridSize) {
                            Row(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                for (x in 0 until gridSize) {
                                    val dist = max(abs(x - playerCellX), abs(y - playerCellY))
                                    val isPlayerCell = (x == playerCellX && y == playerCellY)

                                    val cellColor = when {
                                        isPlayerCell -> KarachiGold
                                        dist == 1 -> KarachiCyan.copy(alpha = 0.7f)
                                        dist == 2 -> Color(0xFF1E88E5).copy(alpha = 0.4f)
                                        else -> KarachiSurfaceVariant.copy(alpha = 0.25f)
                                    }

                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .fillMaxHeight()
                                            .padding(1.dp)
                                            .clip(RoundedCornerShape(2.dp))
                                            .background(cellColor)
                                            .clickable {
                                                // Find nearest district
                                                val normX = (x + 0.5f) / gridSize
                                                val normY = (y + 0.5f) / gridSize
                                                val nearest = districts.minByOrNull { d ->
                                                    val dx = d.mapCoordsX - normX
                                                    val dy = d.mapCoordsY - normY
                                                    dx * dx + dy * dy
                                                }
                                                nearest?.let { onSelectCellDistrict(it.id) }
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        if (isPlayerCell) {
                                            Icon(
                                                Icons.Default.PersonPin,
                                                contentDescription = null,
                                                tint = KarachiObsidian,
                                                modifier = Modifier.size(14.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    // Grid Legend
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        LegendItem(color = KarachiGold, label = "Priority Active")
                        LegendItem(color = KarachiCyan, label = "Nanite Streamed")
                        LegendItem(color = Color(0xFF1E88E5), label = "HLOD Distant")
                        LegendItem(color = KarachiSurfaceVariant, label = "Unloaded (RAM)")
                    }
                }
            }
        }

        // Data Layers Toggle List
        item {
            Text("DATA LAYERS RUNTIME TOGGLES", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
        }

        items(WorldDataLayer.values()) { layer ->
            val isEnabled = activeDataLayers.contains(layer)
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = if (isEnabled) KarachiSurface else KarachiObsidian,
                border = androidx.compose.foundation.BorderStroke(1.dp, if (isEnabled) KarachiCyan.copy(alpha = 0.5f) else KarachiBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = layer.layerName,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextPrimary,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Estimated Footprint: ${layer.memoryMb.toInt()} MB VRAM",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = { onToggleDataLayer(layer) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = KarachiCyan,
                            checkedTrackColor = KarachiSurfaceVariant,
                            uncheckedThumbColor = TextMuted,
                            uncheckedTrackColor = KarachiObsidian
                        )
                    )
                }
            }
        }

        // World Partition Technical Architecture
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("UNREAL ENGINE 5 PARTITION SPECIFICATION", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
                    Text(
                        "• Cell Size: 500m (50,000 Unreal Units) optimized for urban vehicle velocities.\n" +
                        "• HLOD Layer 1: Merged building exterior shells at 800m distance.\n" +
                        "• HLOD Layer 2: Landscape-integrated skyline proxy at 2,500m distance.\n" +
                        "• Spatial Loading: Controlled via UKarachiWorldPartitionManager.\n" +
                        "• Nanite Geometry: Enabled on all masonry, stone, road asphalt, and concrete structures.\n" +
                        "• Virtual Shadow Maps (VSM): Cached directional sun shadows with clipmaps for performance.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 18.sp,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun LegendItem(color: Color, label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(modifier = Modifier.size(8.dp).clip(RoundedCornerShape(2.dp)).background(color))
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
    }
}
