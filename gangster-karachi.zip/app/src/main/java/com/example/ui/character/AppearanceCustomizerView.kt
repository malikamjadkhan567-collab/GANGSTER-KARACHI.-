package com.example.ui.character

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FaceCustomization
import com.example.data.model.PlayableCharacterData
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun AppearanceCustomizerView(
    viewModel: WorldViewModel,
    activeCharacter: PlayableCharacterData,
    modifier: Modifier = Modifier
) {
    val themeColor = Color(activeCharacter.themeColorHex)
    var currentAppearance by remember(activeCharacter.id) {
        mutableStateOf(activeCharacter.appearance)
    }

    val skinToneColors = listOf(
        0xFFFBD7B5, // Fair
        0xFFE0AC69, // Warm Olive
        0xFFC68642, // Sun-kissed Bronze
        0xFF8D5524  // Deep Tan
    )

    val hairstyles = listOf(
        "Street Low Fade",
        "Textured Crew Cut",
        "Slicked Back Pompadour",
        "Buzz Cut",
        "Long Wavy Locs"
    )

    val beards = listOf(
        "Clean Shaven",
        "5 O'clock Stubble",
        "Sculpted Royal Goatee",
        "Full Tactical Beard",
        "Corporate Boxed Beard"
    )

    val scars = listOf(
        "none",
        "Right Brow Scar",
        "Left Cheek Slash",
        "Chin Notch"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "FACIAL & GROOMING STUDIO",
                            style = MaterialTheme.typography.titleMedium,
                            color = KarachiGold,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Styling Profile for ${activeCharacter.fullName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = themeColor
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.updateFaceCustomization(currentAppearance)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("apply_appearance_button")
                    ) {
                        Text("APPLY", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Face Presets (1 to 5)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("FACE MESH PRESET (1–5)", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        for (preset in 1..5) {
                            val isSelected = currentAppearance.presetId == preset
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) themeColor else KarachiSurface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) themeColor else KarachiBorder),
                                modifier = Modifier
                                    .clickable {
                                        currentAppearance = currentAppearance.copy(presetId = preset)
                                    }
                                    .testTag("face_preset_$preset")
                            ) {
                                Box(
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "#$preset",
                                        color = if (isSelected) Color.Black else TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // Skin Tone Selection
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("EPIDERMAL COMPLEXION / SKIN TONE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        skinToneColors.forEachIndexed { index, hex ->
                            val isSelected = currentAppearance.skinToneIndex == index
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) KarachiGold else KarachiBorder,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        currentAppearance = currentAppearance.copy(skinToneIndex = index)
                                    }
                                    .testTag("skin_tone_$index")
                            )
                        }
                    }
                }
            }
        }

        // Hairstyle Selection
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("HAIRSTYLE & CUT", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        hairstyles.forEach { style ->
                            val isSelected = currentAppearance.hairstyleId == style
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) KarachiSurface else KarachiObsidian,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) themeColor else KarachiBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        currentAppearance = currentAppearance.copy(hairstyleId = style)
                                    }
                                    .testTag("hair_$style")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(style, color = if (isSelected) themeColor else TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = themeColor, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Facial Hair Selection
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("FACIAL HAIR / BEARD GROOMING", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        beards.forEach { beard ->
                            val isSelected = currentAppearance.facialHairId == beard
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) KarachiSurface else KarachiObsidian,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) themeColor else KarachiBorder),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        currentAppearance = currentAppearance.copy(facialHairId = beard)
                                    }
                                    .testTag("beard_$beard")
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(beard, color = if (isSelected) themeColor else TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    if (isSelected) {
                                        Icon(Icons.Default.Check, contentDescription = null, tint = themeColor, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Scars & Markings
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("COMBAT SCARS & FACIAL MARKS", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        scars.forEach { scar ->
                            val isSelected = currentAppearance.scarId == scar
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) KarachiCrimson.copy(alpha = 0.2f) else KarachiSurface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) KarachiCrimson else KarachiBorder),
                                modifier = Modifier
                                    .weight(1f)
                                    .clickable {
                                        currentAppearance = currentAppearance.copy(scarId = scar)
                                    }
                            ) {
                                Box(modifier = Modifier.padding(8.dp), contentAlignment = Alignment.Center) {
                                    Text(
                                        text = if (scar == "none") "CLEAN" else scar.split(" ")[0].uppercase(),
                                        color = if (isSelected) KarachiCrimson else TextSecondary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
