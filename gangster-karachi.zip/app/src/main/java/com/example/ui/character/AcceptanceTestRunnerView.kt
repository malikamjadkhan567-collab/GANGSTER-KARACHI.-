package com.example.ui.character

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun AcceptanceTestRunnerView(
    viewModel: WorldViewModel,
    testLogs: List<String>,
    isRunning: Boolean,
    modifier: Modifier = Modifier
) {
    val totalTests = 15
    val passedCount = testLogs.count { it.contains("PASSED") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("acceptance_test_header"),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "MASTER PROMPT 04 ACCEPTANCE VERIFIER",
                                style = MaterialTheme.typography.titleMedium,
                                color = KarachiGold,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "15 Mandatory Automated Engine & Integration Tests",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted
                            )
                        }

                        Button(
                            onClick = { viewModel.runPrompt04AcceptanceTests() },
                            enabled = !isRunning,
                            colors = ButtonDefaults.buttonColors(containerColor = KarachiCyan),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("run_acceptance_tests_button")
                        ) {
                            if (isRunning) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(16.dp),
                                    color = Color.Black,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("TESTING...", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("RUN ALL 15 TESTS", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Progress Overview
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "STATUS: ${if (isRunning) "RUNNING VERIFICATION SUITE..." else if (passedCount == totalTests) "ALL 15 TESTS PASSED ✓" else "READY TO EXECUTE"}",
                            style = MaterialTheme.typography.labelMedium,
                            color = if (passedCount == totalTests) Color(0xFF10B981) else KarachiGold,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$passedCount / $totalTests PASSED",
                            style = MaterialTheme.typography.labelMedium,
                            color = KarachiCyan,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    LinearProgressIndicator(
                        progress = { if (totalTests > 0) passedCount.toFloat() / totalTests else 0f },
                        modifier = Modifier.fillMaxWidth().height(8.dp),
                        color = if (passedCount == totalTests) Color(0xFF10B981) else KarachiCyan,
                        trackColor = KarachiObsidian
                    )
                }
            }
        }

        // Test Logs & Result Entries
        if (testLogs.isEmpty()) {
            item {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = KarachiDarkNavy,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Default.FactCheck, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Click 'RUN ALL 15 TESTS' to execute the full integration verification suite.", color = TextSecondary, fontSize = 12.sp)
                    }
                }
            }
        } else {
            items(testLogs) { log ->
                val isPassed = log.contains("PASSED")
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isPassed) KarachiSurface else KarachiDarkNavy
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isPassed) Color(0xFF10B981).copy(alpha = 0.5f) else KarachiBorder
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            if (isPassed) Icons.Default.CheckCircle else Icons.Default.Pending,
                            contentDescription = null,
                            tint = if (isPassed) Color(0xFF10B981) else KarachiGold,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = log,
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isPassed) TextPrimary else TextSecondary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
