package com.example.ui.simulation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.TrafficLightState
import com.example.data.model.TrafficVehicleAgent

@Composable
fun TrafficSimulationView(
    vehicles: List<TrafficVehicleAgent>,
    trafficLightState: TrafficLightState,
    onCycleTrafficLight: () -> Unit,
    onTriggerEmergencyCorridor: () -> Unit,
    onSpawnTrafficAccident: () -> Unit,
    onResetTrafficFlow: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D1117))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Traffic Control Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "KARACHI METRO TRAFFIC AI",
                            color = Color(0xFF00E5FF),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )

                        // Traffic Light Indicator
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color.Black)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(Color(trafficLightState.colorHex))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                trafficLightState.label,
                                color = Color(trafficLightState.colorHex),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        "Autonomous Mass Entity vehicles navigate multi-lane Karachi arterials, respect signal states, and dynamically clear priority lanes for emergency sirens.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Traffic Control Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = onCycleTrafficLight,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF238636)),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("Cycle Signal", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onTriggerEmergencyCorridor,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("Emergency Siren", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onSpawnTrafficAccident,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("Spawn Collision", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onResetTrafficFlow,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF424242)),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("Reset Flow", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Active Traffic Vehicles List
        items(vehicles) { veh ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (veh.isYieldingToEmergency) Color(0xFF132338) else Color(0xFF161B22)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (veh.isYieldingToEmergency) Color(0xFF00B0FF) else Color(0xFF30363D)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                veh.type.title,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                veh.laneName,
                                color = Color.Gray,
                                fontSize = 10.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFF21262D)
                        ) {
                            Text(
                                "${veh.currentSpeedKmh.toInt()} km/h",
                                color = Color(0xFFFFD54F),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(4.dp),
                            color = Color.Black.copy(alpha = 0.35f)
                        ) {
                            Column(modifier = Modifier.padding(6.dp)) {
                                Text("Headway Gap", color = Color.Gray, fontSize = 8.sp)
                                Text("${String.format("%.1f", veh.distanceToFrontVehicleMeters)}m", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(4.dp),
                            color = Color.Black.copy(alpha = 0.35f)
                        ) {
                            Column(modifier = Modifier.padding(6.dp)) {
                                Text("Brake Status", color = Color.Gray, fontSize = 8.sp)
                                Text(
                                    if (veh.isBraking) "BRAKING" else "CRUISING",
                                    color = if (veh.isBraking) Color(0xFFFF5252) else Color(0xFF00E676),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(4.dp),
                            color = Color.Black.copy(alpha = 0.35f)
                        ) {
                            Column(modifier = Modifier.padding(6.dp)) {
                                Text("Emergency Yield", color = Color.Gray, fontSize = 8.sp)
                                Text(
                                    if (veh.isYieldingToEmergency) "PULLED ASIDE" else "CLEAR",
                                    color = if (veh.isYieldingToEmergency) Color(0xFF00B0FF) else Color.Gray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
