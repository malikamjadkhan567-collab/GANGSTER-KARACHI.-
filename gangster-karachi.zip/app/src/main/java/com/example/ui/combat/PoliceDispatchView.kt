package com.example.ui.combat

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun PoliceDispatchView(
    wantedLevel: WantedLevel,
    policeSearchPhase: PoliceSearchPhase,
    searchDecayProgress: Float,
    policeHeatPercentage: Float,
    activePoliceUnits: List<PoliceUnitInstance>,
    dispatchRadioLogs: List<RadioDispatchTransmission>,
    currentDistrictName: String,
    onReportCrime: (CrimeType) -> Unit,
    onSetWantedStars: (Int) -> Unit,
    onBreakVisualContact: () -> Unit,
    onClearWanted: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("police_dispatch_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "METRO POLICE WANTED & DISPATCH",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "5-Star Escalation • Last Known Position • Radio Intercept",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (wantedLevel.stars > 0) KarachiCrimson.copy(alpha = 0.2f) else KarachiSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, if (wantedLevel.stars > 0) KarachiCrimson else KarachiBorder)
                ) {
                    Text(
                        text = if (wantedLevel.stars > 0) "WANTED" else "CLEAR",
                        style = MaterialTheme.typography.labelSmall,
                        color = if (wantedLevel.stars > 0) KarachiCrimson else KarachiEmerald,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // 5-Star Wanted Rating Bar & Response Protocol
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (wantedLevel.stars > 0) KarachiCrimson else KarachiBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("FELONY WANTED LEVEL", style = MaterialTheme.typography.labelSmall, color = KarachiGold)

                        // 5 Stars Row
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            for (star in 1..5) {
                                val isLit = star <= wantedLevel.stars
                                Icon(
                                    Icons.Default.Star,
                                    contentDescription = "Star $star",
                                    tint = if (isLit) KarachiCrimson else Color(0xFF37474F),
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                    }

                    Text(
                        text = wantedLevel.title.uppercase(),
                        style = MaterialTheme.typography.titleMedium,
                        color = if (wantedLevel.stars > 0) KarachiCrimson else TextPrimary,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Text(
                        text = wantedLevel.policeResponseDesc,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    )

                    Divider(color = KarachiBorder.copy(alpha = 0.5f))

                    // Long-term Police Heat meter
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("DISTRICT POLICE HEAT ($currentDistrictName)", style = MaterialTheme.typography.labelSmall, color = KarachiCyan)
                        Text("${policeHeatPercentage.toInt()}% HEAT", style = MaterialTheme.typography.labelSmall, color = KarachiGold, fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(
                        progress = { (policeHeatPercentage / 100f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = if (policeHeatPercentage > 70f) KarachiCrimson else KarachiGold,
                        trackColor = KarachiObsidian
                    )
                }
            }
        }

        // Police Memory & Last Known Position (LKP) Radar
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("PURSUIT SEARCH ZONE & LKP MEMORY", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
                        Text(
                            text = when (policeSearchPhase) {
                                PoliceSearchPhase.IN_SIGHT -> "LINE OF SIGHT ACTIVE"
                                PoliceSearchPhase.LOST_SIGHT_LKP -> "SEARCHING LKP"
                                PoliceSearchPhase.EXPANDING_GRID_SEARCH -> "EXPANDING GRID"
                                PoliceSearchPhase.DECAY_COOLDOWN -> "SEARCH COOLDOWN"
                                PoliceSearchPhase.EVADED, PoliceSearchPhase.ALL_CLEAR -> "ALL CLEAR"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = if (policeSearchPhase == PoliceSearchPhase.IN_SIGHT) KarachiCrimson else KarachiCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Tactical Radar Canvas
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(KarachiObsidian)
                            .border(1.dp, KarachiBorder, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Canvas(modifier = Modifier.fillMaxSize()) {
                            val cx = size.width / 2f
                            val cy = size.height / 2f

                            // Concentric search range rings
                            drawCircle(color = KarachiBorder.copy(alpha = 0.4f), radius = 35f, center = Offset(cx, cy), style = Stroke(1.5f))
                            drawCircle(color = KarachiBorder.copy(alpha = 0.3f), radius = 70f, center = Offset(cx, cy), style = Stroke(1.5f))

                            // Crosshair axis
                            drawLine(color = KarachiBorder.copy(alpha = 0.3f), start = Offset(cx, 0f), end = Offset(cx, size.height), strokeWidth = 1f)
                            drawLine(color = KarachiBorder.copy(alpha = 0.3f), start = Offset(0f, cy), end = Offset(size.width, cy), strokeWidth = 1f)

                            if (wantedLevel.stars > 0) {
                                // Last Known Position (LKP) Ghost Reticle
                                drawCircle(color = KarachiGold.copy(alpha = 0.25f), radius = 28f, center = Offset(cx, cy))
                                drawCircle(color = KarachiGold, radius = 5f, center = Offset(cx, cy))

                                // Responding Police Units
                                drawCircle(color = KarachiCrimson, radius = 4f, center = Offset(cx - 45f, cy - 25f))
                                drawCircle(color = KarachiCrimson, radius = 4f, center = Offset(cx + 38f, cy + 20f))
                                if (wantedLevel.stars >= 4) {
                                    drawCircle(color = Color(0xFF29B6F6), radius = 6f, center = Offset(cx - 20f, cy + 42f)) // Helicopter
                                }
                            }
                        }

                        if (wantedLevel.stars > 0) {
                            Text(
                                text = "LKP ACTIVE // SEARCH RADIUS: 450M",
                                style = MaterialTheme.typography.labelSmall,
                                color = KarachiGold,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.align(Alignment.BottomCenter).padding(6.dp)
                            )
                        } else {
                            Text(
                                text = "RADAR CLEAR // NO ACTIVE SEARCH",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.align(Alignment.Center)
                            )
                        }
                    }

                    // Search Decay Cooldown Progress Bar
                    if (wantedLevel.stars > 0) {
                        Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Evade Cooldown Timer", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 10.sp)
                                Text("${(searchDecayProgress * 100).toInt()}% EVADED", style = MaterialTheme.typography.labelSmall, color = KarachiCyan, fontSize = 10.sp)
                            }
                            LinearProgressIndicator(
                                progress = { searchDecayProgress },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = KarachiCyan,
                                trackColor = KarachiObsidian
                            )
                        }
                    }

                    // Pursuit Evade & Clear Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onBreakVisualContact,
                            colors = ButtonDefaults.buttonColors(containerColor = KarachiSurfaceVariant),
                            modifier = Modifier.weight(1f).testTag("evade_line_of_sight_button")
                        ) {
                            Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Lose Visual (LKP)", color = KarachiCyan, fontSize = 11.sp)
                        }

                        Button(
                            onClick = onClearWanted,
                            colors = ButtonDefaults.buttonColors(containerColor = KarachiEmerald.copy(alpha = 0.85f)),
                            modifier = Modifier.weight(1f).testTag("clear_wanted_button")
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, tint = KarachiObsidian, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Clear Warrants", color = KarachiObsidian, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Crime Event Simulator Buttons
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("CRIME EVENT DISPATCH TRIGGERS", style = MaterialTheme.typography.labelSmall, color = KarachiGold)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CrimeTriggerChip("Vehicle Theft (★1)", { onReportCrime(CrimeType.VEHICLE_THEFT) }, Modifier.weight(1f))
                        CrimeTriggerChip("Firearm Discharge (★1)", { onReportCrime(CrimeType.WEAPON_DISCHARGE) }, Modifier.weight(1f))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CrimeTriggerChip("Officer Assault (★2)", { onReportCrime(CrimeType.OFFICER_ATTACK) }, Modifier.weight(1f))
                        CrimeTriggerChip("Officer Down (★3)", { onReportCrime(CrimeType.OFFICER_DOWN) }, Modifier.weight(1f))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CrimeTriggerChip("Explosive Blast (★4)", { onReportCrime(CrimeType.EXPLOSION_ATTACK) }, Modifier.weight(1f))
                        CrimeTriggerChip("Level 5 Lockdown (★5)", { onSetWantedStars(5) }, Modifier.weight(1f))
                    }
                }
            }
        }

        // Active Responding Police Units
        item {
            Text("DEPLOYED LAW ENFORCEMENT FLEET (${activePoliceUnits.size} UNITS)", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
        }

        if (activePoliceUnits.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = KarachiDarkNavy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No active pursuit units dispatched. City status is Code 4 (Normal Patrols).",
                        color = TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(12.dp),
                        fontSize = 11.sp
                    )
                }
            }
        } else {
            items(activePoliceUnits) { unit ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = KarachiDarkNavy,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Icon(
                                if (unit.type == PoliceUnitType.POLICE_HELICOPTER) Icons.Default.Flight else Icons.Default.LocalPolice,
                                contentDescription = null,
                                tint = KarachiCyan,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(unit.callsign, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text(unit.type.displayName, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = KarachiCrimson.copy(alpha = 0.2f)
                        ) {
                            Text(
                                text = unit.state,
                                color = KarachiCrimson,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 8.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Live Tactical Police Radio Dispatch Logs
        item {
            Text("POLICE TACTICAL RADIO INTERCEPT LOGS", style = MaterialTheme.typography.labelSmall, color = KarachiCyan)
        }

        items(dispatchRadioLogs) { log ->
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = KarachiSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Mic, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(14.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = "${log.senderCallsign} // FREQ 462.875 MHz",
                            style = MaterialTheme.typography.labelSmall,
                            color = KarachiGold,
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "« ${log.messageText} »",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CrimeTriggerChip(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(containerColor = KarachiSurfaceVariant),
        modifier = modifier.height(38.dp)
    ) {
        Text(label, fontSize = 10.sp, color = TextPrimary)
    }
}
