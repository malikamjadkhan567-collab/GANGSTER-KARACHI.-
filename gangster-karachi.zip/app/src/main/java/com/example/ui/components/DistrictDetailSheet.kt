package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun DistrictDetailSheet(
    district: District,
    landmarks: List<Landmark>,
    activeProtagonist: Protagonist,
    onFastTravel: () -> Unit,
    onAddWaypoint: (title: String, note: String) -> Unit,
    onSelectLandmark: (Landmark) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var showWaypointDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
            .background(KarachiDarkNavy)
            .testTag("district_detail_sheet"),
        colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
        border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Drag handle & close
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .clip(RoundedCornerShape(3.dp))
                            .background(Color(district.colorHex))
                    )
                    Text(
                        text = district.name.uppercase(),
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.testTag("close_district_sheet")
                ) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            // Badges row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = KarachiSurfaceVariant
                ) {
                    Text(
                        text = district.biome.displayName,
                        style = MaterialTheme.typography.labelSmall,
                        color = KarachiCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }

                val securityBadgeColor = when (district.securityLevel) {
                    SecurityLevel.MINIMAL -> KarachiCrimson
                    SecurityLevel.LOW -> Color(0xFFFF9800)
                    SecurityLevel.MEDIUM -> KarachiGold
                    SecurityLevel.HIGH -> KarachiCyan
                    SecurityLevel.GARRISONED -> Color(0xFFE91E63)
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = securityBadgeColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, securityBadgeColor)
                ) {
                    Text(
                        text = "SEC: ${district.securityLevel.label}",
                        style = MaterialTheme.typography.labelSmall,
                        color = securityBadgeColor,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            // Tabs
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = KarachiSurface,
                contentColor = KarachiGold,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = KarachiGold
                    )
                }
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Overview", fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Architecture", fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Factions & Ops", fontSize = 12.sp) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Landmarks (${landmarks.size})", fontSize = 12.sp) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Tab Content
            Box(modifier = Modifier.weight(1f, fill = false).heightIn(max = 240.dp)) {
                when (selectedTab) {
                    0 -> OverviewTab(district, onFastTravel, onShowAddWaypoint = { showWaypointDialog = true })
                    1 -> ArchitectureTab(district)
                    2 -> FactionsAndOpsTab(district)
                    3 -> LandmarksTab(landmarks, onSelectLandmark)
                }
            }
        }
    }

    if (showWaypointDialog) {
        var wpTitle by remember { mutableStateOf("Waypoint: ${district.name}") }
        var wpNote by remember { mutableStateOf("Tactical reconnaissance marker in ${district.name}") }

        AlertDialog(
            onDismissRequest = { showWaypointDialog = false },
            title = { Text("Save World Waypoint", color = KarachiGold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = wpTitle,
                        onValueChange = { wpTitle = it },
                        label = { Text("Marker Title") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = wpNote,
                        onValueChange = { wpNote = it },
                        label = { Text("Intelligence Note") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onAddWaypoint(wpTitle, wpNote)
                        showWaypointDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = KarachiGold)
                ) {
                    Text("Save to Database", color = KarachiObsidian, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showWaypointDialog = false }) {
                    Text("Cancel", color = TextSecondary)
                }
            },
            containerColor = KarachiSurface,
            shape = RoundedCornerShape(12.dp)
        )
    }
}

@Composable
private fun OverviewTab(
    district: District,
    onFastTravel: () -> Unit,
    onShowAddWaypoint: () -> Unit
) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text(
                text = district.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                lineHeight = 18.sp
            )
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DataStatCard(title = "POPULATION", value = district.populationDensity, icon = Icons.Default.Groups, modifier = Modifier.weight(1f))
                DataStatCard(title = "TRAFFIC", value = district.trafficDensity, icon = Icons.Default.Traffic, modifier = Modifier.weight(1f))
            }
        }
        item {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = KarachiSurface,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.CloudQueue, contentDescription = null, tint = KarachiCyan)
                    Column {
                        Text("MICROCLIMATE & LUMEN PROFILE", style = MaterialTheme.typography.labelSmall, color = KarachiCyan, fontSize = 9.sp)
                        Text(district.weatherProfile, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
                    }
                }
            }
        }
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onFastTravel,
                    colors = ButtonDefaults.buttonColors(containerColor = KarachiGold),
                    modifier = Modifier.weight(1f).testTag("fast_travel_button")
                ) {
                    Icon(Icons.Default.FlashOn, contentDescription = null, tint = KarachiObsidian, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Fast Travel Here", color = KarachiObsidian, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                }

                OutlinedButton(
                    onClick = onShowAddWaypoint,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = KarachiCyan),
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan),
                    modifier = Modifier.weight(1f).testTag("add_waypoint_button")
                ) {
                    Icon(Icons.Default.BookmarkAdd, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Save Waypoint", fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun ArchitectureTab(district: District) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("ARCHITECTURAL STYLE & MODULAR KITS", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
            Text(district.architectureStyle, style = MaterialTheme.typography.bodySmall, color = TextPrimary)
        }
        item {
            Text("TIER 1 — HERO BUILDINGS (FULLY ENTERABLE)", style = MaterialTheme.typography.labelSmall, color = KarachiCyan)
            district.heroBuildings.forEach { b ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = KarachiSurface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                ) {
                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Star, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(b, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Text("TIER 2 — GAMEPLAY INTERIORS (MODULAR)", style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            district.gameplayInteriors.forEach { b ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = KarachiSurfaceVariant,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                ) {
                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.CheckCircleOutline, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(b, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Text("TIER 3 — BACKGROUND BUILDINGS", style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text("Exterior Nanite geometry with interior window parallax mapping and dynamic time-of-day emissive window states.", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 10.sp)
        }
    }
}

@Composable
private fun FactionsAndOpsTab(district: District) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("FACTION INFLUENCE & GANG TURFS", style = MaterialTheme.typography.labelSmall, color = KarachiCrimson)
            district.factionZones.forEach { f ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = KarachiSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCrimson.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                ) {
                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = KarachiCrimson, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(f, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Text("MISSION & HEIST SECTORS", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
            district.missionZones.forEach { m ->
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = KarachiSurface,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                ) {
                    Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MyLocation, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(m, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                    }
                }
            }
        }
        item {
            Text("VERTICAL TRANSIT & CORRIDORS", style = MaterialTheme.typography.labelSmall, color = KarachiCyan)
            district.navigationFeatures.forEach { n ->
                Row(modifier = Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AltRoute, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(n, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
private fun LandmarksTab(
    landmarks: List<Landmark>,
    onSelectLandmark: (Landmark) -> Unit
) {
    if (landmarks.isEmpty()) {
        Box(modifier = Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
            Text("No major landmarks designated in this sector.", color = TextMuted, fontSize = 12.sp)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(landmarks) { lm ->
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = KarachiSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                    onClick = { onSelectLandmark(lm) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        val icon = when (lm.category) {
                            LandmarkCategory.EMERGENCY -> Icons.Default.LocalHospital
                            LandmarkCategory.COMMERCE -> Icons.Default.Storefront
                            LandmarkCategory.TRANSPORTATION -> Icons.Default.DirectionsTransit
                            LandmarkCategory.ENTERTAINMENT -> Icons.Default.Nightlife
                            LandmarkCategory.GAMEPLAY -> Icons.Default.VpnKey
                        }
                        Icon(icon, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(20.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(lm.name, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text("${lm.category.title} • ${lm.interiorTier.tierName.split("—")[0].trim()}", style = MaterialTheme.typography.labelSmall, color = KarachiCyan, fontSize = 9.sp)
                        }
                        Icon(Icons.Default.ChevronRight, contentDescription = null, tint = TextMuted)
                    }
                }
            }
        }
    }
}

@Composable
private fun DataStatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = KarachiSurface,
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Icon(icon, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(12.dp))
                Text(title, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 10.sp)
        }
    }
}
