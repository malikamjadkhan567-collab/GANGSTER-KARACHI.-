package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.District
import com.example.data.model.SecurityLevel
import com.example.ui.theme.*

@Composable
fun DistrictsListView(
    districts: List<District>,
    selectedDistrict: District,
    onSelectDistrict: (District) -> Unit,
    modifier: Modifier = Modifier
) {
    var searchQuery by remember { mutableStateOf("") }
    var selectedSecurityFilter by remember { mutableStateOf<SecurityLevel?>(null) }

    val filtered = districts.filter { d ->
        (searchQuery.isEmpty() || d.name.contains(searchQuery, ignoreCase = true) || d.description.contains(searchQuery, ignoreCase = true)) &&
        (selectedSecurityFilter == null || d.securityLevel == selectedSecurityFilter)
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("districts_list_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Title & Stats
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "KARACHI METRO // 15 DISTRICTS",
                    style = MaterialTheme.typography.titleMedium,
                    color = KarachiGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Seamless Geographic Continuum • Coastal to Mountain Ridgeline",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = KarachiSurfaceVariant
            ) {
                Text(
                    text = "${filtered.size} REGIONS",
                    style = MaterialTheme.typography.labelSmall,
                    color = KarachiCyan,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Search bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search districts, biomes, or architecture...", fontSize = 12.sp, color = TextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = KarachiGold) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("district_search_input"),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = KarachiSurface,
                unfocusedContainerColor = KarachiSurface,
                focusedBorderColor = KarachiGold,
                unfocusedBorderColor = KarachiBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        // Districts LazyColumn
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered) { district ->
                val isSelected = district.id == selectedDistrict.id
                val districtColor = Color(district.colorHex)

                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) KarachiDarkNavy else KarachiSurface
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) KarachiGold else KarachiBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectDistrict(district) }
                        .testTag("district_card_${district.id}")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(12.dp)
                                        .clip(RoundedCornerShape(3.dp))
                                        .background(districtColor)
                                )
                                Text(
                                    text = district.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = districtColor.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = district.biome.displayName.split(" ")[0],
                                    style = MaterialTheme.typography.labelSmall,
                                    color = districtColor,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = district.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            maxLines = 2,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        // Highlights Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Sec: ${district.securityLevel.label.split("/")[0].trim()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = KarachiCyan,
                                fontSize = 9.sp
                            )
                            Text(
                                text = "Hero: ${district.heroBuildings.size} | Gameplay: ${district.gameplayInteriors.size}",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextMuted,
                                fontSize = 9.sp
                            )
                            Icon(
                                Icons.Default.ArrowForward,
                                contentDescription = "View on Map",
                                tint = KarachiGold,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
