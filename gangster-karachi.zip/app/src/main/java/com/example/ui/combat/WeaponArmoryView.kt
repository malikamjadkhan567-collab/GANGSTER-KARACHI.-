package com.example.ui.combat

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.SavedWeaponEntity
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun WeaponArmoryView(
    weapons: List<Weapon>,
    selectedWeapon: Weapon,
    activeProtagonist: Protagonist,
    savedWeapons: List<SavedWeaponEntity>,
    onSelectWeapon: (Weapon) -> Unit,
    onSaveToInventory: (Weapon, String) -> Unit,
    onDeleteSavedWeapon: (SavedWeaponEntity) -> Unit,
    onEquipToRange: (Weapon) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedCategoryFilter by remember { mutableStateOf<WeaponCategory?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val filtered = weapons.filter { w ->
        (selectedCategoryFilter == null || w.category == selectedCategoryFilter) &&
        (searchQuery.isEmpty() || w.name.contains(searchQuery, ignoreCase = true) || w.manufacturer.contains(searchQuery, ignoreCase = true) || w.description.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("weapon_armory_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "KARACHI METRO // TACTICAL ARMORY",
                    style = MaterialTheme.typography.titleMedium,
                    color = KarachiGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Fictional Arsenal • Attachments • Protagonist Loadouts",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = KarachiSurfaceVariant
            ) {
                Text(
                    text = "${filtered.size} WEAPONS",
                    style = MaterialTheme.typography.labelSmall,
                    color = KarachiCyan,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by weapon name, caliber, role...", fontSize = 12.sp, color = TextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = KarachiGold) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("weapon_search_input"),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = KarachiSurface,
                unfocusedContainerColor = KarachiSurface,
                focusedBorderColor = KarachiGold,
                unfocusedBorderColor = KarachiBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        // Category Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(
                    selected = selectedCategoryFilter == null,
                    onClick = { selectedCategoryFilter = null },
                    label = { Text("All Arsenal", fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = KarachiGold, selectedLabelColor = KarachiObsidian)
                )
            }
            items(WeaponCategory.values()) { cat ->
                val isSelected = selectedCategoryFilter == cat
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategoryFilter = if (isSelected) null else cat },
                    label = { Text(cat.displayName.split(" ")[0], fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = KarachiCyan, selectedLabelColor = KarachiObsidian)
                )
            }
        }

        // Weapon Cards List
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered) { wep ->
                val isSelected = wep.id == selectedWeapon.id

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) KarachiDarkNavy else KarachiSurface
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isSelected) 2.dp else 1.dp,
                        color = if (isSelected) KarachiGold else KarachiBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectWeapon(wep) }
                        .testTag("weapon_card_${wep.id}")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = wep.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${wep.manufacturer} • ${wep.ammoType.label}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = KarachiCyan,
                                    fontSize = 11.sp
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = when (wep.rarityTier) {
                                    "BLACK_MARKET" -> KarachiCrimson
                                    "MILITARY" -> Color(0xFF29B6F6)
                                    else -> KarachiGold
                                }
                            ) {
                                Text(
                                    text = wep.rarityTier,
                                    color = KarachiObsidian,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 8.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Text(
                            text = wep.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        // Protagonist Affinity Tag
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Affinity: ${wep.protagonistAffinity}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (wep.protagonistAffinity == "Universal") TextMuted else KarachiGold,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "Slot: ${wep.defaultSlot.title.split(" ")[0]}",
                                style = MaterialTheme.typography.labelSmall,
                                color = KarachiCyan,
                                fontSize = 10.sp
                            )
                        }

                        Divider(color = KarachiBorder.copy(alpha = 0.5f))

                        // Mechanical Specs Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            WeaponSpecBadge("DAMAGE", "${wep.baseDamage.toInt()}")
                            WeaponSpecBadge("RANGE", "${wep.effectiveRangeMeters.toInt()}m")
                            WeaponSpecBadge("ROF", "${wep.fireRateRpm} RPM")
                            WeaponSpecBadge("MAGAZINE", "${wep.magazineCapacity} rds")
                            WeaponSpecBadge("WEIGHT", "${wep.weightKg} kg")
                        }

                        // Action Buttons: Equip & Save To Inventory
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    onSelectWeapon(wep)
                                    onEquipToRange(wep)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSelected) KarachiGold else KarachiSurfaceVariant
                                ),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Icon(
                                    Icons.Default.Adjust,
                                    contentDescription = null,
                                    tint = if (isSelected) KarachiObsidian else TextPrimary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isSelected) "READY IN RANGE" else "SELECT & TEST",
                                    color = if (isSelected) KarachiObsidian else TextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                )
                            }

                            OutlinedButton(
                                onClick = {
                                    onSaveToInventory(wep, activeProtagonist.id)
                                    Toast.makeText(context, "${wep.name} added to ${activeProtagonist.name}'s loadout!", Toast.LENGTH_SHORT).show()
                                },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = KarachiCyan),
                                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan),
                                modifier = Modifier.weight(1f).height(40.dp)
                            ) {
                                Icon(Icons.Default.BookmarkAdd, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save Loadout", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeaponSpecBadge(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
        Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}
