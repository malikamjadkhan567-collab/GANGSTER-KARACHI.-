package com.example.ui.story

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.MissionStatus
import com.example.data.model.StoryAct
import com.example.data.model.StoryMission
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun StoryMissionsListView(
    viewModel: WorldViewModel,
    missions: List<StoryMission>,
    activeMission: StoryMission?,
    onSelectMission: (StoryMission) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedAct by remember { mutableStateOf(StoryAct.ACT_I) }
    val filteredMissions = missions.filter { it.act == selectedAct }
    val completedCount = missions.count { it.status == MissionStatus.COMPLETED }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
    ) {
        // Campaign Overview Header
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = KarachiDarkNavy,
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "KARACHI UNDERWORLD STORY CAMPAIGN",
                            style = MaterialTheme.typography.titleMedium,
                            color = KarachiGold,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "30 Cinematic Missions • Roman Urdu Voice Scripts • Multi-Protagonist Heists",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = KarachiSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
                    ) {
                        Text(
                            text = "$completedCount / 30 DONE",
                            color = KarachiCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Act Navigation Tabs
                ScrollableTabRow(
                    selectedTabIndex = StoryAct.values().indexOf(selectedAct),
                    containerColor = KarachiObsidian,
                    contentColor = KarachiGold,
                    edgePadding = 0.dp,
                    divider = {}
                ) {
                    StoryAct.values().forEach { act ->
                        val isSelected = act == selectedAct
                        Tab(
                            selected = isSelected,
                            onClick = { selectedAct = act },
                            text = {
                                Text(
                                    text = act.title.split(":")[0],
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) KarachiGold else TextSecondary
                                )
                            }
                        )
                    }
                }
            }
        }

        // Missions List
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Text(
                    text = "${selectedAct.title.uppercase()} • ${selectedAct.subtitle}",
                    style = MaterialTheme.typography.labelSmall,
                    color = KarachiCyan,
                    fontWeight = FontWeight.Bold
                )
            }

            items(filteredMissions) { mission ->
                val isCurrentActive = activeMission?.id == mission.id

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("mission_card_${mission.id}")
                        .clickable { onSelectMission(mission) },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isCurrentActive) KarachiSurface else KarachiDarkNavy
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (isCurrentActive) KarachiGold else if (mission.status == MissionStatus.COMPLETED) Color(0xFF10B981) else KarachiBorder
                    ),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = KarachiObsidian,
                                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
                                ) {
                                    Text(
                                        text = "M${if (mission.missionNumber < 10) "0" else ""}${mission.missionNumber}",
                                        color = KarachiGold,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = mission.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Status Chip
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = when (mission.status) {
                                    MissionStatus.COMPLETED -> Color(0xFF10B981).copy(alpha = 0.2f)
                                    MissionStatus.IN_PROGRESS -> KarachiGold.copy(alpha = 0.2f)
                                    MissionStatus.AVAILABLE -> KarachiCyan.copy(alpha = 0.2f)
                                    MissionStatus.LOCKED -> KarachiBorder.copy(alpha = 0.3f)
                                    MissionStatus.FAILED -> KarachiCrimson.copy(alpha = 0.2f)
                                },
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    when (mission.status) {
                                        MissionStatus.COMPLETED -> Color(0xFF10B981)
                                        MissionStatus.IN_PROGRESS -> KarachiGold
                                        MissionStatus.AVAILABLE -> KarachiCyan
                                        MissionStatus.LOCKED -> KarachiBorder
                                        MissionStatus.FAILED -> KarachiCrimson
                                    }
                                )
                            ) {
                                Text(
                                    text = mission.status.name,
                                    fontSize = 8.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (mission.status) {
                                        MissionStatus.COMPLETED -> Color(0xFF10B981)
                                        MissionStatus.IN_PROGRESS -> KarachiGold
                                        MissionStatus.AVAILABLE -> KarachiCyan
                                        MissionStatus.LOCKED -> TextMuted
                                        MissionStatus.FAILED -> KarachiCrimson
                                    },
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = mission.summary,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Protagonists involved & location
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                mission.protagonistIds.forEach { protoId ->
                                    val (name, colorHex) = when (protoId) {
                                        "ayan" -> Pair("AYAN", 0xFF00E5FF)
                                        "shahroz" -> Pair("SHAHROZ", 0xFFFF4444)
                                        "daniyal" -> Pair("DANIYAL", 0xFFFFB703)
                                        else -> Pair(protoId.uppercase(), 0xFF94A3B8)
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(3.dp),
                                        color = Color(colorHex).copy(alpha = 0.15f),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(colorHex))
                                    ) {
                                        Text(
                                            text = name,
                                            color = Color(colorHex),
                                            fontSize = 7.5.sp,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                        )
                                    }
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Place, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(12.dp))
                                Text(
                                    text = mission.districtName,
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Rewards row & action
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "₨ ${(mission.rewardCashPkr / 1000)}K PKR REWARD",
                                color = KarachiGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )

                            Button(
                                onClick = { onSelectMission(mission) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (mission.status == MissionStatus.COMPLETED) KarachiSurface else KarachiGold
                                ),
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("launch_mission_${mission.id}")
                            ) {
                                Text(
                                    text = if (mission.status == MissionStatus.COMPLETED) "REPLAY" else if (mission.status == MissionStatus.IN_PROGRESS) "CONTINUE" else "BRIEFING",
                                    color = if (mission.status == MissionStatus.COMPLETED) TextPrimary else Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
