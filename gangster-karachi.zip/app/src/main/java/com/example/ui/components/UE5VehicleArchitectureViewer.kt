package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UE5VehicleArchitectureData
import com.example.ui.theme.*

@Composable
fun UE5VehicleArchitectureViewer(
    modifier: Modifier = Modifier
) {
    var selectedCodeTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    val codeSnippets = listOf(
        Pair("KarachiVehicleDataAsset.h", UE5VehicleArchitectureData.vehicleDataAssetHeader),
        Pair("KarachiVehicleBase.h", UE5VehicleArchitectureData.vehicleBaseHeader),
        Pair("KarachiVehicleSubsystem.h", UE5VehicleArchitectureData.vehicleSubsystemHeader)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("ue5_vehicle_architecture_viewer"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "UE5 // VEHICLE SYSTEM ARCHITECTURE",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Chaos Physics • UPrimaryDataAsset • Subsystems • Damage Models",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = KarachiSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan)
                ) {
                    Text(
                        text = "PROMPT 02",
                        style = MaterialTheme.typography.labelSmall,
                        color = KarachiCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Code Inspector Tabs
        item {
            TabRow(
                selectedTabIndex = selectedCodeTab,
                containerColor = KarachiSurface,
                contentColor = KarachiGold,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedCodeTab]),
                        color = KarachiGold
                    )
                }
            ) {
                codeSnippets.forEachIndexed { index, pair ->
                    Tab(
                        selected = selectedCodeTab == index,
                        onClick = { selectedCodeTab = index },
                        text = { Text(pair.first, fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                    )
                }
            }
        }

        // Code Display Card
        item {
            val currentCode = codeSnippets[selectedCodeTab].second
            val currentTitle = codeSnippets[selectedCodeTab].first

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF06090F)),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = KarachiCyan,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("UE5 Vehicle Code", currentCode)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Copied $currentTitle to clipboard", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Code", tint = KarachiGold, modifier = Modifier.size(18.dp))
                        }
                    }
                    Divider(color = KarachiBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))

                    val horizontalScrollState = rememberScrollState()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .horizontalScroll(horizontalScrollState)
                    ) {
                        Text(
                            text = currentCode,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = TextPrimary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Master Build Prompt 02 Deliverables Audit
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "PROMPT 02 FINAL ACCEPTANCE AUDIT & VERIFICATION",
                        style = MaterialTheme.typography.titleSmall,
                        color = KarachiGold,
                        fontWeight = FontWeight.Bold
                    )

                    AuditItem("1. Vehicles Actually Implemented", "20+ vehicle configurations created covering Sports, Supercars, Muscle, SUVs, Pickups, Motorcycles, Speedboats, Fishing Dhows, Helicopters, Public Buses, Taxis, and Police Interceptors.")
                    AuditItem("2. Vehicle Classes Created", "UKarachiVehicleDataAsset, AKarachiVehicleBase, UKarachiVehicleSubsystem, AKarachiCarVehicle, AKarachiMotorcycleVehicle, AKarachiBoatVehicle, AKarachiHelicopterVehicle.")
                    AuditItem("3. Physics Engine Implemented", "Drivetrain models (FWD, RWD, AWD, 4x4, Marine Impeller, Rotor), surface friction multipliers (Dry Asphalt, Wet Asphalt, Sand, Dirt, Mud), lateral G-force, mass/torque curves, independent 4-wheel suspension deflection.")
                    AuditItem("4. Damage Model Implemented", "Body scratch %, panel dent %, cracked glass, engine temperature overheat, blown tire physics, headlight failure, full repair loop.")
                    AuditItem("5. Camera Perspectives", "Chase Close, Chase Wide, Cockpit 1st Person (dashboard/steering wheel), Hood Cam with dynamic speed follow.")
                    AuditItem("6. Garage Persistence Implemented", "Persistent Room Database (garage_vehicles table) tracking custom paint, finishes, tint, performance stages, turbo, armor, mileage, and protagonist ownership.")
                    AuditItem("7. Customization Framework", "Modular paint finishes (Metallic, Gloss, Matte, Satin, Chrome), 8 custom colors, spoilers, window tint, ECU tuning Stages 1-3, Turbocharger kit, race brakes, and armor.")
                    AuditItem("8. AI Vehicle Interfaces", "UKarachiVehicleSubsystem traffic spawner pool with district-weighted distributions (Defence Gardens = Luxury, Saddar = Taxis/Buses, Industrial = Heavy Pickups).")
                    AuditItem("9. Known Limitations", "[NOT IMPLEMENTED] Desktop native Chaos PhysX real-time solver (requires desktop UE5.4 compilation); [NOT IMPLEMENTED] Force-feedback external hardware steering wheel drivers.")
                    AuditItem("10. Reserved for Prompt 03", "[NOT IMPLEMENTED] Drive-by weapons, vehicle-mounted armaments, weapon recoil, police tactical spike strips, and felony heat tracking.")
                }
            }
        }
    }
}

@Composable
private fun AuditItem(title: String, description: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = KarachiCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
    }
}
