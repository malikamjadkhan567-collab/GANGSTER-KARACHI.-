package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.TimeOfDay
import com.example.ui.theme.*

@Composable
fun LumenLightingControl(
    selectedTimeOfDay: TimeOfDay,
    onSelectTimeOfDay: (TimeOfDay) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("lumen_lighting_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "LUMEN // DYNAMIC LIGHTING & TIME OF DAY",
                style = MaterialTheme.typography.titleMedium,
                color = KarachiGold,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Real-time Global Illumination, Ocean Reflections & Emissives",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        // Time of Day Selector Row
        item {
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                items(TimeOfDay.values()) { tod ->
                    val isSelected = tod == selectedTimeOfDay
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) KarachiGold else KarachiSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) KarachiGold else KarachiBorder),
                        onClick = { onSelectTimeOfDay(tod) },
                        modifier = Modifier.testTag("tod_${tod.name.lowercase()}")
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            val icon = when (tod) {
                                TimeOfDay.DAWN -> Icons.Default.WbTwilight
                                TimeOfDay.NOON -> Icons.Default.WbSunny
                                TimeOfDay.GOLDEN_HOUR -> Icons.Default.BrightnessMedium
                                TimeOfDay.TWILIGHT -> Icons.Default.NightsStay
                                TimeOfDay.MIDNIGHT -> Icons.Default.Bedtime
                            }
                            Icon(
                                icon,
                                contentDescription = null,
                                tint = if (isSelected) KarachiObsidian else KarachiCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = tod.label.split("-")[0].trim(),
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) KarachiObsidian else TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Atmospheric Concept Art Visualizer
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    val imageRes = if (selectedTimeOfDay == TimeOfDay.MIDNIGHT || selectedTimeOfDay == TimeOfDay.TWILIGHT) {
                        R.drawable.img_port_district
                    } else {
                        R.drawable.img_karachi_skyline
                    }

                    Image(
                        painter = painterResource(id = imageRes),
                        contentDescription = "Karachi Metro Environment Lighting Vista",
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(190.dp)
                            .clip(RoundedCornerShape(topStart = 14.dp, topEnd = 14.dp)),
                        contentScale = ContentScale.Crop
                    )

                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = selectedTimeOfDay.label,
                                style = MaterialTheme.typography.titleSmall,
                                color = KarachiGold,
                                fontWeight = FontWeight.Bold
                            )
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = KarachiSurfaceVariant
                            ) {
                                Text(
                                    text = "LUMEN REFL: ${(selectedTimeOfDay.wetSurfaceReflectivity * 100).toInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = KarachiCyan,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Text(
                            text = if (selectedTimeOfDay == TimeOfDay.MIDNIGHT || selectedTimeOfDay == TimeOfDay.TWILIGHT) {
                                "Port District & Industrial Zone under neon and halogen floodlights. Wet asphalt specular reflections and high-contrast shadow casting from shipping gantry cranes."
                            } else {
                                "Clifton Heights and Ocean Drive coastal skyline bathed in warm golden hour sunlight, dynamic ocean waves reflecting the setting sun against glass high-rise facades."
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }

        // Lighting Telemetry Breakdown
        item {
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("LUMEN SHADER & ILLUMINATION TELEMETRY", style = MaterialTheme.typography.labelSmall, color = KarachiGold)

                    TelemetryRow(label = "Direct Sun Lux", value = "${selectedTimeOfDay.ambientLux.toInt()} lx", progress = (selectedTimeOfDay.ambientLux / 110000f).coerceIn(0.01f, 1f))
                    TelemetryRow(label = "Sun Elevation Angle", value = "${selectedTimeOfDay.sunAngleDeg.toInt()}°", progress = ((selectedTimeOfDay.sunAngleDeg + 60f) / 150f).coerceIn(0f, 1f))
                    TelemetryRow(label = "Indirect Diffuse Bounce", value = "${(selectedTimeOfDay.lumenIndirectBounce * 100).toInt()}%", progress = selectedTimeOfDay.lumenIndirectBounce)
                    TelemetryRow(label = "Wet Surface Specular Fresnel", value = "${(selectedTimeOfDay.wetSurfaceReflectivity * 100).toInt()}%", progress = selectedTimeOfDay.wetSurfaceReflectivity)
                }
            }
        }

        // Material Wetness Reaction Note
        item {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = KarachiDarkNavy,
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(Icons.Default.WaterDrop, contentDescription = null, tint = KarachiCyan)
                    Column {
                        Text("DYNAMIC MATERIAL WETNESS SYSTEM", style = MaterialTheme.typography.labelSmall, color = KarachiCyan)
                        Text(
                            "In Karachi Metro, wet surfaces (rain, coastal spray, high humidity) dynamically decrease material roughness and increase normal map specular highlights for photorealistic roads and concrete.",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 16.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryRow(label: String, value: String, progress: Float) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
            Text(value, style = MaterialTheme.typography.bodySmall, color = KarachiGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = KarachiGold,
            trackColor = KarachiSurfaceVariant
        )
    }
}
