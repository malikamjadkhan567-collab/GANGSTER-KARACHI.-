package com.example.ui.simulation

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import kotlin.math.*

@Composable
fun WorldClockWeatherView(
    clock: GameClock,
    env: EnvironmentSnapshot,
    onHourChanged: (Float) -> Unit,
    onTimeSpeedChanged: (Float) -> Unit,
    onWeatherSelected: (WeatherType) -> Unit,
    onRainIntensityChanged: (Float) -> Unit,
    onTriggerLightning: () -> Unit,
    onSaveSimulationState: () -> Unit,
    feedbackMessage: String?
) {
    val phase = clock.currentPhase
    val skyColor = Color(phase.skyTintHex)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D1117))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Feedback Banner
        if (feedbackMessage != null) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF00E676).copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF00E676)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF00E676))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            feedbackMessage,
                            color = Color(0xFF00E676),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Sky & Day/Night Phase Hero Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22))
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                listOf(skyColor.copy(alpha = 0.85f), Color(0xFF161B22))
                            )
                        )
                        .padding(18.dp)
                ) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "KARACHI WORLD TIME",
                                    color = Color(0xFF00E5FF),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                                Row(verticalAlignment = Alignment.Bottom) {
                                    Text(
                                        clock.formattedTime,
                                        color = Color.White,
                                        fontSize = 38.sp,
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        "PKT (UTC+5)",
                                        color = Color.LightGray,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(bottom = 8.dp)
                                    )
                                }
                            }

                            // Day & Season Badge
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = Color.Black.copy(alpha = 0.5f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                                    Text(
                                        "Day ${clock.dayNumber}",
                                        color = Color(0xFFFFD700),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        clock.dayOfWeek,
                                        color = Color.White,
                                        fontSize = 11.sp
                                    )
                                    Text(
                                        clock.season,
                                        color = Color.Cyan,
                                        fontSize = 10.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Current Phase Details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (phase.sunAngleDegrees > 0) Icons.Default.WbSunny else Icons.Default.NightlightRound,
                                    contentDescription = null,
                                    tint = if (phase.sunAngleDegrees > 0) Color(0xFFFFB300) else Color(0xFF90CAF9),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    phase.displayName,
                                    color = Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Lightbulb,
                                    contentDescription = null,
                                    tint = if (phase.streetLightsOn) Color(0xFFFFD54F) else Color.Gray,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    if (phase.streetLightsOn) "Street Lights ON" else "Street Lights OFF",
                                    color = if (phase.streetLightsOn) Color(0xFFFFD54F) else Color.Gray,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Lighting metrics
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(6.dp),
                                color = Color.Black.copy(alpha = 0.35f)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Ambient Lux", color = Color.Gray, fontSize = 9.sp)
                                    Text("${phase.ambientLux.toInt()} lx", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(6.dp),
                                color = Color.Black.copy(alpha = 0.35f)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Sun Elevation", color = Color.Gray, fontSize = 9.sp)
                                    Text("${phase.sunAngleDegrees.toInt()}°", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                            Surface(
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(6.dp),
                                color = Color.Black.copy(alpha = 0.35f)
                            ) {
                                Column(modifier = Modifier.padding(8.dp)) {
                                    Text("Lumen GI Bounce", color = Color.Gray, fontSize = 9.sp)
                                    Text(if (phase.sunAngleDegrees > 0) "Direct Sunlight" else "Indirect Moon Bounce", color = Color.Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Time Control Sliders & Speed Presets
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "TIME SPEED & 24H SCRUBBER",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        "Scrub World Hour: ${String.format("%.1f", clock.decimalHour)}h",
                        color = Color(0xFF00E5FF),
                        fontSize = 11.sp
                    )
                    Slider(
                        value = clock.decimalHour,
                        onValueChange = { onHourChanged(it) },
                        valueRange = 0f..23.99f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF00E5FF),
                            activeTrackColor = Color(0xFF00E5FF)
                        )
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text("Time Flow Multipliers:", color = Color.Gray, fontSize = 10.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            1.0f to "1x Real-Time",
                            5.0f to "5x Fast",
                            30.0f to "30x Speed",
                            60.0f to "60x Orbit"
                        ).forEach { (spd, lbl) ->
                            val isSel = clock.timeSpeedMultiplier == spd
                            Button(
                                onClick = { onTimeSpeedChanged(spd) },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) Color(0xFF00E5FF) else Color(0xFF21262D)
                                )
                            ) {
                                Text(
                                    lbl,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isSel) Color.Black else Color.White
                                )
                            }
                        }
                    }
                }
            }
        }

        // 10 Day/Night Phases Selector
        item {
            Column {
                Text(
                    "DAY/NIGHT PHASES (10 PHASES)",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(DayNightPhase.values()) { p ->
                        val isCurrent = clock.currentPhase == p
                        Surface(
                            modifier = Modifier
                                .width(120.dp)
                                .clickable { onHourChanged(p.startHour + 0.2f) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isCurrent) Color(p.skyTintHex).copy(alpha = 0.9f) else Color(0xFF21262D),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isCurrent) Color(0xFF00E5FF) else Color(0xFF30363D)
                            )
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    p.name.replace("_", " "),
                                    color = if (isCurrent) Color.White else Color.LightGray,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    p.displayName,
                                    color = Color(0xFFFFD54F),
                                    fontSize = 9.sp,
                                    maxLines = 1
                                )
                                Text(
                                    "${p.startHour.toInt()}:00 - ${p.endHour.toInt()}:00",
                                    color = Color.Gray,
                                    fontSize = 8.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Weather Selector (10 Dynamic Weather Types)
        item {
            Column {
                Text(
                    "DYNAMIC WEATHER SYSTEMS (10 TYPES)",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(WeatherType.values()) { w ->
                        val isSel = env.weatherType == w
                        Surface(
                            modifier = Modifier
                                .width(135.dp)
                                .clickable { onWeatherSelected(w) },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSel) Color(0xFF1E3A8A) else Color(0xFF21262D),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isSel) Color(0xFF60A5FA) else Color(0xFF30363D)
                            )
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Icon(
                                        when (w) {
                                            WeatherType.CLEAR -> Icons.Default.WbSunny
                                            WeatherType.PARTLY_CLOUDY, WeatherType.CLOUDY -> Icons.Default.CloudQueue
                                            WeatherType.OVERCAST -> Icons.Default.Cloud
                                            WeatherType.LIGHT_RAIN, WeatherType.HEAVY_RAIN -> Icons.Default.Umbrella
                                            WeatherType.STORM -> Icons.Default.FlashOn
                                            WeatherType.FOG -> Icons.Default.BlurOn
                                            WeatherType.DUSTY_HAZY -> Icons.Default.Grain
                                            WeatherType.WINDY -> Icons.Default.Air
                                        },
                                        contentDescription = null,
                                        tint = if (isSel) Color(0xFF93C5FD) else Color.Gray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Text(
                                        "${(w.roadGripMultiplier * 100).toInt()}% Grip",
                                        color = if (w.roadGripMultiplier < 0.7f) Color(0xFFFF5252) else Color(0xFF00E676),
                                        fontSize = 8.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    w.displayName,
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "Wind ${w.baseWindSpeedKmh.toInt()} km/h",
                                    color = Color.LightGray,
                                    fontSize = 9.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Live Weather Parameters & Road Reaction
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "LIVE ATMOSPHERIC & ROAD REACTION",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0D1117)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Rain Intensity", color = Color.Gray, fontSize = 9.sp)
                                Text("${(env.rainIntensity * 100).toInt()}%", color = Color(0xFF64B5F6), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                LinearProgressIndicator(
                                    progress = { env.rainIntensity },
                                    modifier = Modifier.fillMaxWidth().height(4.dp),
                                    color = Color(0xFF64B5F6)
                                )
                            }
                        }
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0D1117)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Road Wetness", color = Color.Gray, fontSize = 9.sp)
                                Text("${(env.wetRoadFactor * 100).toInt()}%", color = Color(0xFF81D4FA), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                LinearProgressIndicator(
                                    progress = { env.wetRoadFactor },
                                    modifier = Modifier.fillMaxWidth().height(4.dp),
                                    color = Color(0xFF81D4FA)
                                )
                            }
                        }
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0D1117)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Visibility", color = Color.Gray, fontSize = 9.sp)
                                Text("${env.visibilityMeters.toInt()}m", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0D1117)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Wind & Direction", color = Color.Gray, fontSize = 9.sp)
                                Text("${env.windSpeedKmh.toInt()} km/h (${env.windBearingDegrees.toInt()}° SW)", color = Color(0xFFFFD54F), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0D1117)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Ocean Waves (Sea View)", color = Color.Gray, fontSize = 9.sp)
                                Text("${String.format("%.1f", env.waveHeightMeters)}m Chop", color = Color(0xFF4FC3F7), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Manual Rain Slider
                    Text("Manual Rain Intensity Control: ${(env.rainIntensity * 100).toInt()}%", color = Color.LightGray, fontSize = 11.sp)
                    Slider(
                        value = env.rainIntensity,
                        onValueChange = { onRainIntensityChanged(it) },
                        valueRange = 0f..1.0f,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF64B5F6),
                            activeTrackColor = Color(0xFF64B5F6)
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Action buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onTriggerLightning,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB300)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.FlashOn, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Trigger Lightning Flash", color = Color.Black, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onSaveSimulationState,
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF238636)),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Save World State", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
