package com.example.ui.story

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DialogueLine
import com.example.data.model.MissionObjective
import com.example.data.model.MissionStatus
import com.example.data.model.StoryMission
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun ActiveMissionPlayerView(
    viewModel: WorldViewModel,
    mission: StoryMission,
    onBackToList: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentDialogueIndex by remember { mutableIntStateOf(0) }
    var isPlayingDialogue by remember { mutableStateOf(true) }
    var objectivesState by remember(mission.id) {
        mutableStateOf(mission.objectives.map { it.copy() })
    }

    val isAllCompleted = objectivesState.all { it.isCompleted }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
    ) {
        // Mission Top Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = KarachiDarkNavy,
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackToList) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = KarachiGold)
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "MISSION ${mission.missionNumber}: ${mission.title.uppercase()}",
                            style = MaterialTheme.typography.titleMedium,
                            color = KarachiGold,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "${mission.act.title.split(":")[0]} • ${mission.districtName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = KarachiCyan
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = KarachiSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
                    ) {
                        Text(
                            text = "₨ ${(mission.rewardCashPkr / 1000)}K",
                            color = KarachiGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Objective Checklist Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("mission_objectives_card"),
                    colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("OPERATIONAL OBJECTIVES", style = MaterialTheme.typography.labelSmall, color = KarachiGold, fontWeight = FontWeight.Bold)
                            Text(
                                text = "${objectivesState.count { it.isCompleted }} / ${objectivesState.size} COMPLETED",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isAllCompleted) Color(0xFF10B981) else TextSecondary,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        objectivesState.forEachIndexed { index, obj ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp)
                                    .clickable {
                                        val updated = objectivesState.toMutableList()
                                        updated[index] = obj.copy(isCompleted = !obj.isCompleted)
                                        objectivesState = updated
                                    }
                                    .testTag("objective_checkbox_$index"),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Checkbox(
                                    checked = obj.isCompleted,
                                    onCheckedChange = { checked ->
                                        val updated = objectivesState.toMutableList()
                                        updated[index] = obj.copy(isCompleted = checked)
                                        objectivesState = updated
                                    },
                                    colors = CheckboxDefaults.colors(
                                        checkedColor = Color(0xFF10B981),
                                        checkmarkColor = Color.Black
                                    )
                                )

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = obj.description,
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = if (obj.isCompleted) TextMuted else TextPrimary,
                                        fontWeight = if (obj.isCompleted) FontWeight.Normal else FontWeight.SemiBold
                                    )
                                    if (obj.goldCondition.isNotEmpty()) {
                                        Text(
                                            text = "★ Gold Requirement: ${obj.goldCondition}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = KarachiGold,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Real-time Roman Urdu Dialogue Engine
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("dialogue_engine_card"),
                    colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(16.dp))
                                Text(
                                    text = "ROMAN URDU DIALOGUE FEED",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = KarachiCyan,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = {
                                        if (currentDialogueIndex > 0) currentDialogueIndex--
                                    },
                                    enabled = currentDialogueIndex > 0
                                ) {
                                    Icon(Icons.Default.SkipPrevious, contentDescription = "Prev", tint = if (currentDialogueIndex > 0) KarachiGold else TextMuted, modifier = Modifier.size(18.dp))
                                }

                                IconButton(
                                    onClick = { isPlayingDialogue = !isPlayingDialogue }
                                ) {
                                    Icon(
                                        if (isPlayingDialogue) Icons.Default.Pause else Icons.Default.PlayArrow,
                                        contentDescription = "Play/Pause",
                                        tint = KarachiGold,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        if (currentDialogueIndex < mission.dialogueScript.size - 1) currentDialogueIndex++
                                    },
                                    enabled = currentDialogueIndex < mission.dialogueScript.size - 1
                                ) {
                                    Icon(
                                        Icons.Default.SkipNext,
                                        contentDescription = "Next",
                                        tint = if (currentDialogueIndex < mission.dialogueScript.size - 1) KarachiGold else TextMuted,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (mission.dialogueScript.isNotEmpty()) {
                            val activeLine = mission.dialogueScript[currentDialogueIndex]
                            val speakerColor = Color(activeLine.speakerAccentHex)

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = KarachiObsidian,
                                border = androidx.compose.foundation.BorderStroke(1.dp, speakerColor),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = activeLine.speakerName.uppercase(),
                                            color = speakerColor,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 11.sp
                                        )
                                        Text(
                                            text = "[Line ${currentDialogueIndex + 1}/${mission.dialogueScript.size}]",
                                            color = TextMuted,
                                            fontSize = 9.sp,
                                            fontFamily = FontFamily.Monospace
                                        )
                                    }

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // Roman Urdu Speech
                                    Text(
                                        text = "\"${activeLine.romanUrduText}\"",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold,
                                        fontStyle = FontStyle.Italic,
                                        fontSize = 13.5.sp
                                    )

                                    Spacer(modifier = Modifier.height(6.dp))

                                    // English Subtitle
                                    Text(
                                        text = "Subtitles: ${activeLine.englishTranslation}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary,
                                        fontSize = 11.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Complete / Finish Mission Action
            item {
                Button(
                    onClick = {
                        viewModel.completeMission(mission.id)
                        onBackToList()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("complete_mission_action_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "COMPLETE MISSION & CLAIM REWARDS",
                        color = Color.Black,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                }
            }
        }
    }
}
