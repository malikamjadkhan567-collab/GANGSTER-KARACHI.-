package com.example.ui.simulation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SimulationLODMetrics

@Composable
fun SimulationLODView(
    metrics: SimulationLODMetrics,
    selectedGraphicsPreset: String,
    onGraphicsPresetSelected: (String) -> Unit
) {
    val presets = listOf("Low", "Medium", "High", "Ultra", "Cinematic")

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D1117))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // LOD Architecture Header
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "UNREAL ENGINE 5 SIMULATION LOD (4 TIERS)",
                        color = Color(0xFF00E5FF),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "Scalable multi-tier simulation architecture preventing per-actor tick bottlenecks across 15 Karachi districts while preserving 60 FPS.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0D1117)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Tick Budget", color = Color.Gray, fontSize = 8.sp)
                                Text("${metrics.simulationTickTimeMs} ms / 16.6ms", color = Color(0xFF00E676), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF0D1117)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("FPS Target", color = Color.Gray, fontSize = 8.sp)
                                Text("${metrics.currentFpsTarget} FPS Locked", color = Color.Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // The 4 LOD Tiers
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Level 0
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B2A1B)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E7D32))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("LEVEL 0 — NEAR PLAYER (< 50m)", color = Color(0xFF81C784), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${metrics.level0NearCount} Actors", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Full skeletal animation, Chaos vehicle physics, individual raycast perception, Niagara rain splashes, complete 3D spatialized audio.",
                            color = Color.LightGray,
                            fontSize = 10.sp
                        )
                    }
                }

                // Level 1
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2633)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1976D2))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("LEVEL 1 — MEDIUM DISTANCE (50 - 250m)", color = Color(0xFF64B5F6), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${metrics.level1MediumCount} Actors", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Simplified crowd locomotion, vertex-animated meshes, spline path following, instanced traffic, reduced raycast frequency (10Hz).",
                            color = Color.LightGray,
                            fontSize = 10.sp
                        )
                    }
                }

                // Level 2
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF2E2416)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFF57C00))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("LEVEL 2 — FAR DISTANCE (250 - 1000m)", color = Color(0xFFFFB74D), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${metrics.level2FarCount} Entities", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Statistical traffic flow along arterial splines, 2D billboard imposters, district density heatmaps, low-frequency position updates (1Hz).",
                            color = Color.LightGray,
                            fontSize = 10.sp
                        )
                    }
                }

                // Level 3
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1F1B2A)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF7B1FA2))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("LEVEL 3 — OUTSIDE ACTIVE CELLS (> 1000m)", color = Color(0xFFBA68C8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Text("${metrics.level3BackgroundCount} Virtualized", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "Pure data simulation. Zero actor overhead, zero skeletal meshes. World Partition cells unloaded to disk until player approaches.",
                            color = Color.LightGray,
                            fontSize = 10.sp
                        )
                    }
                }
            }
        }

        // Scalable Graphics Settings
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "GRAPHICS & ENGINE SCALABILITY TARGET",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        presets.forEach { preset ->
                            val isSel = selectedGraphicsPreset == preset
                            Button(
                                onClick = { onGraphicsPresetSelected(preset) },
                                modifier = Modifier.weight(1f),
                                contentPadding = PaddingValues(vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (isSel) Color(0xFF00E5FF) else Color(0xFF21262D)
                                )
                            ) {
                                Text(
                                    preset,
                                    color = if (isSel) Color.Black else Color.White,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        when (selectedGraphicsPreset) {
                            "Low" -> "Screen Space Global Illumination, Cascaded Shadow Maps, 30 FPS cap, 50% density"
                            "Medium" -> "Software Lumen, Virtual Shadow Maps, 60 FPS, 75% density"
                            "High" -> "Hardware Ray Traced Lumen, High Resolution Virtual Shadow Maps, Nanite enabled"
                            "Ultra" -> "Full Lumen Ray Tracing, Max Reflection Bounces, Subsurface Scattering, 100% density"
                            else -> "Cinematic 4K Path Tracing for cutscenes, uncompressed textures, full volumetric clouds"
                        },
                        color = Color.Cyan,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}
