package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// GANGSTER KARACHI — NEXT GEN Color Palette
val KarachiObsidian = Color(0xFF090D16)
val KarachiDarkNavy = Color(0xFF0F1523)
val KarachiSurface = Color(0xFF161E31)
val KarachiSurfaceVariant = Color(0xFF1E2840)
val KarachiBorder = Color(0xFF2A3756)

val KarachiGold = Color(0xFFFFB800)
val KarachiGoldDark = Color(0xFFD49200)
val KarachiCyan = Color(0xFF00E5FF)
val KarachiCrimson = Color(0xFFFF2E63)
val KarachiEmerald = Color(0xFF00E676)
val KarachiPurple = Color(0xFFBB86FC)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Map District specific tones
val DistrictLuxuryGold = Color(0xFFFFD54F)
val DistrictCoastalCyan = Color(0xFF26C6DA)
val DistrictCommercialAmber = Color(0xFFFFA726)
val DistrictIndustrialSteel = Color(0xFF78909C)
val DistrictWorkingBrick = Color(0xFFFF7043)
val DistrictGreenbelt = Color(0xFF66BB6A)
val DistrictHillsStone = Color(0xFF8D6E63)
