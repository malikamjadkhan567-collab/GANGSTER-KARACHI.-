package com.example.ui.components

import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.local.SavedVehicleEntity
import com.example.data.model.PaintFinish
import com.example.data.model.Protagonist
import com.example.data.model.Vehicle
import com.example.ui.theme.*

@Composable
fun GarageCustomizerView(
    vehicle: Vehicle,
    activeProtagonist: Protagonist,
    garageVehicles: List<SavedVehicleEntity>,
    onSaveToGarage: (Vehicle, String) -> Unit,
    onDeleteFromGarage: (SavedVehicleEntity) -> Unit,
    onSelectVehicle: (String) -> Unit,
    onBackToSimulator: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedPaintColor by remember { mutableLongStateOf(vehicle.customization.paintColorHex) }
    var selectedFinish by remember { mutableStateOf(vehicle.customization.finish) }
    var tintLevel by remember { mutableFloatStateOf(vehicle.customization.windowTintPct.toFloat()) }
    var spoilerLevel by remember { mutableIntStateOf(vehicle.customization.spoilerStage) }
    var engineTuneStage by remember { mutableIntStateOf(vehicle.customization.engineTuneStage) }
    var turboInstalled by remember { mutableStateOf(vehicle.customization.turboInstalled) }
    var sportSuspension by remember { mutableStateOf(vehicle.customization.sportSuspension) }
    var raceBrakes by remember { mutableStateOf(vehicle.customization.raceBrakes) }
    var sportTires by remember { mutableStateOf(vehicle.customization.sportTires) }
    var armorPlating by remember { mutableStateOf(vehicle.customization.armorPlating) }

    val paintColors = listOf(
        Pair("Karachi Gold", 0xFFFFB800),
        Pair("Obsidian Black", 0xFF0D1117),
        Pair("Electric Cyan", 0xFF00E5FF),
        Pair("Crimson Red", 0xFFFF3366),
        Pair("British Racing Green", 0xFF1B5E20),
        Pair("Pure White Pearl", 0xFFF5F5F5),
        Pair("Ultra Violet", 0xFF7C4DFF),
        Pair("Gunmetal Grey", 0xFF455A64)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("garage_customizer_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "CUSTOMIZATION & GARAGE WORKSHOP",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Modular Tuning • Persistent Ownership • Protagonist Bays",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Button(
                    onClick = onBackToSimulator,
                    colors = ButtonDefaults.buttonColors(containerColor = KarachiGold)
                ) {
                    Icon(Icons.Default.DriveEta, contentDescription = null, tint = KarachiObsidian, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Drive Now", color = KarachiObsidian, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        // Workshop Banner
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.fillMaxWidth().height(150.dp)) {
                    Image(
                        painter = painterResource(id = R.drawable.img_garage_workshop),
                        contentDescription = "Garage Workshop",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )

                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = KarachiObsidian.copy(alpha = 0.85f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan),
                        modifier = Modifier.align(Alignment.BottomStart).padding(10.dp)
                    ) {
                        Text(
                            text = "BAY: ${activeProtagonist.name.uppercase()}'S GARAGE",
                            style = MaterialTheme.typography.labelSmall,
                            color = KarachiCyan,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }

        // 1. Exterior Paint & Finishes Studio
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("EXTERIOR PAINT & CLEARCOAT FINISH", style = MaterialTheme.typography.labelSmall, color = KarachiGold)

                    // Color Swatches
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(paintColors) { (name, hex) ->
                            val isSelected = selectedPaintColor == hex
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(Color(hex))
                                    .border(
                                        width = if (isSelected) 3.dp else 1.dp,
                                        color = if (isSelected) KarachiGold else KarachiBorder,
                                        shape = CircleShape
                                    )
                                    .clickable {
                                        selectedPaintColor = hex
                                        vehicle.customization.paintColorHex = hex
                                    }
                            )
                        }
                    }

                    // Paint Finishes
                    Text("Finish Texture:", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(PaintFinish.values()) { finish ->
                            val isSelected = selectedFinish == finish
                            FilterChip(
                                selected = isSelected,
                                onClick = {
                                    selectedFinish = finish
                                    vehicle.customization.finish = finish
                                },
                                label = { Text(finish.label.split(" ")[0], fontSize = 10.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = KarachiCyan,
                                    selectedLabelColor = KarachiObsidian
                                )
                            )
                        }
                    }

                    // Window Tint Slider
                    Text("Window Solar Tint: ${tintLevel.toInt()}%", style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
                    Slider(
                        value = tintLevel,
                        onValueChange = {
                            tintLevel = it
                            vehicle.customization.windowTintPct = it.toInt()
                        },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = KarachiGold, activeTrackColor = KarachiGold)
                    )

                    // Aerodynamic Spoilers
                    Text("Rear Aerodynamic Wing:", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("None", "Lip", "GT Wing", "Carbon").forEachIndexed { index, name ->
                            val isSelected = spoilerLevel == index
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSelected) KarachiGold else KarachiSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) KarachiGold else KarachiBorder),
                                onClick = {
                                    spoilerLevel = index
                                    vehicle.customization.spoilerStage = index
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = name,
                                    color = if (isSelected) KarachiObsidian else TextPrimary,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. Performance Tuning & Dyno Shop
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("PERFORMANCE DYNO TUNING & MECHANICAL UPGRADES", style = MaterialTheme.typography.labelSmall, color = KarachiCyan)

                    // ECU Stages
                    Text("Engine ECU Stage:", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Stock (0)", "Stage 1 (+15%)", "Stage 2 (+30%)", "Stage 3 (+50%)").forEachIndexed { stage, label ->
                            val isSelected = engineTuneStage == stage
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSelected) KarachiCyan else KarachiSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) KarachiCyan else KarachiBorder),
                                onClick = {
                                    engineTuneStage = stage
                                    vehicle.customization.engineTuneStage = stage
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isSelected) KarachiObsidian else TextPrimary,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(vertical = 6.dp),
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }

                    // Mechanical Upgrade Checkboxes
                    UpgradeCheckbox("Twin Turbocharger Spool Kit", turboInstalled) {
                        turboInstalled = !turboInstalled
                        vehicle.customization.turboInstalled = turboInstalled
                    }

                    UpgradeCheckbox("Sport Lowered Stiff Suspension", sportSuspension) {
                        sportSuspension = !sportSuspension
                        vehicle.customization.sportSuspension = sportSuspension
                    }

                    UpgradeCheckbox("Drilled Carbon-Ceramic Race Brakes", raceBrakes) {
                        raceBrakes = !raceBrakes
                        vehicle.customization.raceBrakes = raceBrakes
                    }

                    UpgradeCheckbox("High-Grip Semi-Slick Sport Tires", sportTires) {
                        sportTires = !sportTires
                        vehicle.customization.sportTires = sportTires
                    }

                    UpgradeCheckbox("Reinforced Armor Plating & Run-Flat Tires", armorPlating) {
                        armorPlating = !armorPlating
                        vehicle.customization.armorPlating = armorPlating
                    }
                }
            }
        }

        // Save & Store in Garage Action
        item {
            Button(
                onClick = {
                    onSaveToGarage(vehicle, activeProtagonist.id)
                    Toast.makeText(context, "${vehicle.name} stored in ${activeProtagonist.name}'s garage!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = KarachiGold),
                modifier = Modifier.fillMaxWidth().height(50.dp).testTag("save_to_garage_button")
            ) {
                Icon(Icons.Default.Save, contentDescription = null, tint = KarachiObsidian)
                Spacer(modifier = Modifier.width(8.dp))
                Text("SAVE VEHICLE TO ${activeProtagonist.name.uppercase()}'S GARAGE", color = KarachiObsidian, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            }
        }

        // 3. Stored Garage Fleet List
        item {
            Text(
                text = "PERSISTENT GARAGE FLEET (${garageVehicles.size} STORED)",
                style = MaterialTheme.typography.labelSmall,
                color = KarachiGold
            )
        }

        if (garageVehicles.isEmpty()) {
            item {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = KarachiDarkNavy,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No vehicles stored yet. Tap 'Save Vehicle To Garage' to add this vehicle to your persistent Room database fleet.",
                        color = TextMuted,
                        style = MaterialTheme.typography.bodySmall,
                        modifier = Modifier.padding(14.dp),
                        fontSize = 11.sp
                    )
                }
            }
        } else {
            items(garageVehicles) { gVeh ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = KarachiSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(16.dp)
                                    .clip(CircleShape)
                                    .background(Color(gVeh.paintColorHex))
                            )
                            Column {
                                Text(gVeh.customName, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Text(
                                    "Owner: ${gVeh.ownerProtagonistId.uppercase()} • Stage ${gVeh.engineTuneStage} Tune • Cond: ${gVeh.conditionPct.toInt()}%",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = KarachiCyan,
                                    fontSize = 9.sp
                                )
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            IconButton(
                                onClick = { onSelectVehicle(gVeh.vehicleId) }
                            ) {
                                Icon(Icons.Default.DriveEta, contentDescription = "Select", tint = KarachiGold)
                            }
                            IconButton(
                                onClick = { onDeleteFromGarage(gVeh) }
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Delete", tint = KarachiCrimson)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UpgradeCheckbox(label: String, checked: Boolean, onToggle: () -> Unit) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (checked) KarachiSurfaceVariant else KarachiObsidian,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (checked) KarachiCyan.copy(alpha = 0.5f) else KarachiBorder),
        onClick = onToggle,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(label, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontSize = 11.sp)
            Checkbox(
                checked = checked,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(checkedColor = KarachiCyan, checkmarkColor = KarachiObsidian)
            )
        }
    }
}
