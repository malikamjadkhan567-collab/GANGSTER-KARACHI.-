package com.example.ui.combat

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.theme.*

@Composable
fun CombatSimulatorView(
    selectedWeapon: Weapon,
    aimState: AimState,
    playerStance: PlayerStance,
    stealthState: StealthState,
    crosshairSpread: Float,
    selectedSurface: ImpactSurface,
    hitFeedback: String?,
    enemyTarget: EnemyCombatTarget,
    onFireWeapon: () -> Unit,
    onReloadWeapon: () -> Unit,
    onAimStateChange: (AimState) -> Unit,
    onStanceChange: (PlayerStance) -> Unit,
    onSurfaceChange: (ImpactSurface) -> Unit,
    onMeleeAttack: (Boolean) -> Unit,
    onSilentTakedown: () -> Unit,
    onResetTarget: () -> Unit,
    onToggleAttachment: (String) -> Unit,
    onOpenArmory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("combat_simulator_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "COMBAT & BALLISTICS RANGE",
                    style = MaterialTheme.typography.titleMedium,
                    color = KarachiGold,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "${selectedWeapon.name.uppercase()} • ${selectedWeapon.firingMode.label}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = KarachiSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan),
                onClick = onOpenArmory
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(16.dp))
                    Text("Armory", color = KarachiCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Tactical Range Reticle & Target Dummy Canvas
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Top Status Badges
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Stance & Aim Badge
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = KarachiObsidian
                    ) {
                        Text(
                            text = "${playerStance.label.uppercase()} | ${aimState.label.uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = KarachiGold,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    // Stealth Awareness State
                    val stealthColor = when (stealthState) {
                        StealthState.HIDDEN -> KarachiEmerald
                        StealthState.SUSPICIOUS -> KarachiGold
                        StealthState.DETECTED -> Color(0xFFFF9800)
                        StealthState.SEARCHING -> Color(0xFF29B6F6)
                        StealthState.ALERT, StealthState.COMBAT -> KarachiCrimson
                    }
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = stealthColor.copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, stealthColor)
                    ) {
                        Text(
                            text = "AWARENESS: ${stealthState.label.uppercase()}",
                            style = MaterialTheme.typography.labelSmall,
                            color = stealthColor,
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }

                // Target Practice Arena Canvas (Animated Crosshair & Hit Zone Target)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(KarachiObsidian)
                        .border(1.dp, KarachiBorder, RoundedCornerShape(10.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val centerX = size.width / 2f
                        val centerY = size.height / 2f

                        // Target Dummy Silhouette
                        val targetAlpha = if (enemyTarget.isAlive) 0.85f else 0.25f
                        val targetColor = if (enemyTarget.isAlive) Color(0xFF455A64) else KarachiCrimson

                        // Head circle
                        drawCircle(color = targetColor.copy(alpha = targetAlpha), radius = 16f, center = Offset(centerX, centerY - 45f))
                        // Torso box
                        drawRoundRect(
                            color = targetColor.copy(alpha = targetAlpha),
                            topLeft = Offset(centerX - 24f, centerY - 24f),
                            size = androidx.compose.ui.geometry.Size(48f, 55f),
                            cornerRadius = androidx.compose.ui.geometry.CornerRadius(6f, 6f)
                        )
                        // Limbs
                        drawLine(color = targetColor.copy(alpha = targetAlpha), start = Offset(centerX - 24f, centerY - 15f), end = Offset(centerX - 42f, centerY + 15f), strokeWidth = 8f, cap = StrokeCap.Round)
                        drawLine(color = targetColor.copy(alpha = targetAlpha), start = Offset(centerX + 24f, centerY - 15f), end = Offset(centerX + 42f, centerY + 15f), strokeWidth = 8f, cap = StrokeCap.Round)
                        drawLine(color = targetColor.copy(alpha = targetAlpha), start = Offset(centerX - 14f, centerY + 30f), end = Offset(centerX - 18f, centerY + 70f), strokeWidth = 9f, cap = StrokeCap.Round)
                        drawLine(color = targetColor.copy(alpha = targetAlpha), start = Offset(centerX + 14f, centerY + 30f), end = Offset(centerX + 18f, centerY + 70f), strokeWidth = 9f, cap = StrokeCap.Round)

                        // Dynamic Recoil Bloom Crosshair
                        val spread = crosshairSpread.coerceIn(8f, 50f)
                        val crossColor = if (aimState == AimState.ADS) KarachiCyan else KarachiGold
                        // Top pip
                        drawLine(color = crossColor, start = Offset(centerX, centerY - spread - 14f), end = Offset(centerX, centerY - spread), strokeWidth = 2.5f)
                        // Bottom pip
                        drawLine(color = crossColor, start = Offset(centerX, centerY + spread), end = Offset(centerX, centerY + spread + 14f), strokeWidth = 2.5f)
                        // Left pip
                        drawLine(color = crossColor, start = Offset(centerX - spread - 14f, centerY), end = Offset(centerX - spread, centerY), strokeWidth = 2.5f)
                        // Right pip
                        drawLine(color = crossColor, start = Offset(centerX + spread, centerY), end = Offset(centerX + spread + 14f, centerY), strokeWidth = 2.5f)
                        // Center dot
                        drawCircle(color = crossColor, radius = 2.5f, center = Offset(centerX, centerY))
                    }

                    // Target Health / Armor overlay HUD
                    Column(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = if (enemyTarget.isAlive) "${enemyTarget.name} [${enemyTarget.archetype.title}]" else "TARGET NEUTRALIZED (DOWNED)",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (enemyTarget.isAlive) TextPrimary else KarachiCrimson,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(modifier = Modifier.width(200.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Health bar
                            LinearProgressIndicator(
                                progress = { (enemyTarget.health / enemyTarget.maxHealth).coerceIn(0f, 1f) },
                                modifier = Modifier.weight(1f).height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = KarachiEmerald,
                                trackColor = KarachiSurfaceVariant
                            )
                            // Armor bar
                            LinearProgressIndicator(
                                progress = { (enemyTarget.armor / 50f).coerceIn(0f, 1f) },
                                modifier = Modifier.weight(0.6f).height(6.dp).clip(RoundedCornerShape(3.dp)),
                                color = KarachiCyan,
                                trackColor = KarachiSurfaceVariant
                            )
                        }
                    }
                }

                // Hit Feedback Ticker
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = KarachiSurface,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(Icons.Default.Adjust, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(16.dp))
                        Text(
                            text = hitFeedback ?: "READY TO FIRE",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextPrimary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }
        }

        // Ammo & Weapon Status Card
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KarachiSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "${selectedWeapon.currentMagazineAmmo} / ${selectedWeapon.reserveAmmoTotal}",
                            style = MaterialTheme.typography.displaySmall,
                            color = if (selectedWeapon.currentMagazineAmmo <= 3) KarachiCrimson else KarachiGold,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = "AMMO: ${selectedWeapon.ammoType.label}",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 9.sp
                        )
                    }

                    // Reload Button
                    Button(
                        onClick = onReloadWeapon,
                        colors = ButtonDefaults.buttonColors(containerColor = KarachiSurfaceVariant),
                        modifier = Modifier.testTag("reload_button")
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, tint = KarachiCyan)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("RELOAD", color = KarachiCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                }

                // Fire & Trigger Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Melee Strike
                    Button(
                        onClick = { onMeleeAttack(false) },
                        colors = ButtonDefaults.buttonColors(containerColor = KarachiSurfaceVariant),
                        modifier = Modifier.weight(1f).height(54.dp).testTag("melee_strike_button")
                    ) {
                        Icon(Icons.Default.SportsMartialArts, contentDescription = null, tint = TextPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("MELEE", fontSize = 11.sp)
                    }

                    // Silent Takedown
                    Button(
                        onClick = onSilentTakedown,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        modifier = Modifier.weight(1.1f).height(54.dp).testTag("takedown_button")
                    ) {
                        Icon(Icons.Default.VisibilityOff, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("TAKEDOWN", fontSize = 10.sp, color = Color.White)
                    }

                    // Primary FIRE Button
                    Button(
                        onClick = onFireWeapon,
                        colors = ButtonDefaults.buttonColors(containerColor = KarachiCrimson),
                        modifier = Modifier.weight(1.4f).height(54.dp).testTag("fire_button")
                    ) {
                        Icon(Icons.Default.FlashOn, contentDescription = null, tint = Color.White)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("FIRE", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
                    }
                }
            }
        }

        // Aiming Modes & Player Stance Selector
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("AIM PROFILE & TACTICAL STANCE", style = MaterialTheme.typography.labelSmall, color = KarachiCyan)

                // Aim State Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AimState.values().forEach { mode ->
                        val isSelected = aimState == mode
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) KarachiGold else KarachiSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) KarachiGold else KarachiBorder),
                            onClick = { onAimStateChange(mode) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = mode.label.split("(")[0].trim(),
                                color = if (isSelected) KarachiObsidian else TextPrimary,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(vertical = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }

                // Stance Row (Standing, Crouch, Low Cover, High Cover)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    PlayerStance.values().forEach { stance ->
                        val isSelected = playerStance == stance
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) KarachiCyan else KarachiSurface,
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) KarachiCyan else KarachiBorder),
                            onClick = { onStanceChange(stance) },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                text = stance.label.split(" ")[0],
                                color = if (isSelected) KarachiObsidian else TextSecondary,
                                style = MaterialTheme.typography.labelSmall,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(vertical = 8.dp),
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                        }
                    }
                }
            }
        }

        // Impact Surface Testing Row
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("BALLISTIC SURFACE IMPACT SIMULATOR", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(ImpactSurface.values()) { surf ->
                    val isSelected = surf == selectedSurface
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSurfaceChange(surf) },
                        label = { Text(surf.label, fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = KarachiGold,
                            selectedLabelColor = KarachiObsidian
                        )
                    )
                }
            }
        }

        // Attachments Workbench & Target Reset
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KarachiSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("WEAPON ATTACHMENTS & SUPPRESSOR", style = MaterialTheme.typography.labelSmall, color = KarachiGold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AttachmentButton("Suppressor", selectedWeapon.attachments.suppressorInstalled, { onToggleAttachment("SUPPRESSOR") }, Modifier.weight(1f))
                    AttachmentButton("Ext. Mag", selectedWeapon.attachments.extendedMag, { onToggleAttachment("EXTENDED_MAG") }, Modifier.weight(1f))
                    AttachmentButton("Laser Sight", selectedWeapon.attachments.laserSight, { onToggleAttachment("LASER") }, Modifier.weight(1f))
                }

                Button(
                    onClick = onResetTarget,
                    colors = ButtonDefaults.buttonColors(containerColor = KarachiSurfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, tint = KarachiEmerald, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Respawn Practice Target Dummy", fontSize = 11.sp, color = TextPrimary)
                }
            }
        }
    }
}

@Composable
private fun AttachmentButton(label: String, active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (active) KarachiCyan.copy(alpha = 0.2f) else KarachiObsidian,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) KarachiCyan else KarachiBorder),
        onClick = onClick,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = if (active) KarachiCyan else TextSecondary, fontWeight = FontWeight.Bold, fontSize = 10.sp)
            Text(if (active) "ATTACHED" else "OFF", style = MaterialTheme.typography.labelSmall, color = if (active) KarachiEmerald else TextMuted, fontSize = 8.sp)
        }
    }
}
