package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UE5ArchitectureData
import com.example.ui.theme.*

@Composable
fun UE5ArchitectureViewer(
    modifier: Modifier = Modifier
) {
    var selectedCodeTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    val codeSnippets = listOf(
        Pair("KarachiTypes.h", UE5ArchitectureData.karachiTypesHeader),
        Pair("KarachiWorldSubsystem.h", UE5ArchitectureData.karachiWorldSubsystemHeader),
        Pair("KarachiWorldSubsystem.cpp", UE5ArchitectureData.karachiWorldSubsystemCpp)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("ue5_architecture_viewer"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "UNREAL ENGINE 5 // C++ ARCHITECTURE",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Production C++ Subsystems & Data Assets for Karachi Metro",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
            }
        }

        // Code Inspector Tabs
        item {
            TabRow(
                selectedTabIndex = selectedCodeTab,
                containerColor = KarachiSurface,
                contentColor = KarachiGold,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedCodeTab]),
                        color = KarachiGold
                    )
                }
            ) {
                codeSnippets.forEachIndexed { index, pair ->
                    Tab(
                        selected = selectedCodeTab == index,
                        onClick = { selectedCodeTab = index },
                        text = { Text(pair.first, fontSize = 11.sp, fontFamily = FontFamily.Monospace) }
                    )
                }
            }
        }

        // Code Display Card
        item {
            val currentCode = codeSnippets[selectedCodeTab].second
            val currentTitle = codeSnippets[selectedCodeTab].first

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF06090F)),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = KarachiCyan,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("UE5 Source Code", currentCode)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Copied $currentTitle to clipboard", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Code", tint = KarachiGold, modifier = Modifier.size(18.dp))
                        }
                    }
                    Divider(color = KarachiBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))

                    val horizontalScrollState = rememberScrollState()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 280.dp)
                            .horizontalScroll(horizontalScrollState)
                    ) {
                        Text(
                            text = currentCode,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = TextPrimary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Master Build Prompt 01 Architectural Audit
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("PROMPT 01 AUDIT & DELIVERABLES SPECIFICATION", style = MaterialTheme.typography.titleSmall, color = KarachiGold, fontWeight = FontWeight.Bold)

                    SpecificationSection(
                        title = "1. WORLD ARCHITECTURE & MAP HIERARCHY",
                        body = "Seamless 64km² Karachi Metro world partitioning 15 continuous districts:\n" +
                               "Northern Hills (Altitude 400m) → Greenbelt → Orangi → Saddar & Old Town → Downtown Finance → Defence Gardens → Industrial Zone → Port Terminal → Ocean Drive Beachfront."
                    )

                    SpecificationSection(
                        title = "2. WORLD PARTITION & STREAMING STRATEGY",
                        body = "• Grid Cell Size: 500m × 500m (50,000 UU) with 8×8 master matrix.\n" +
                               "• Runtime Spatial Hash: Distance-based dynamic cell loading centered on active player pawn.\n" +
                               "• HLOD Layer 1 (800m): Merged exterior proxies.\n" +
                               "• HLOD Layer 2 (2500m): Baked skyline silhouettes."
                    )

                    SpecificationSection(
                        title = "3. BUILDING INTERIOR TIERS",
                        body = "• Tier 1 (Hero): 100% modeled interior, physical doors, bespoke lighting (Safehouses, Bank Vault, Police HQ, Grand Pearl Hotel).\n" +
                               "• Tier 2 (Gameplay): Modular enterable spaces (Shops, garages, transit hubs, clinics).\n" +
                               "• Tier 3 (Background): Exterior Nanite mesh with parallax window cubemaps."
                    )

                    SpecificationSection(
                        title = "4. MATERIAL SYSTEM (PBR & WET SURFACE SHADERS)",
                        body = "12 PBR Material Masters: Asphalt, Concrete, Glass, Metal, Painted Metal, Teak Wood, Beach Sand, Wet Road, Wet Concrete, Water Surface, Vegetation, Corroded Rust.\n" +
                               "Dynamic Rain/Tidal reaction reduces roughness from 0.85 → 0.12 and increases specular fresnel reflection."
                    )

                    SpecificationSection(
                        title = "5. NAVIGATION FOUNDATION",
                        body = "Recast NavMesh generation partitioned across world cells. Includes dynamic nav-mesh generation around spawned roadblocks, crowd segregation queries, and dedicated vertical climbing nav links for Lyari rooftop routes."
                    )

                    SpecificationSection(
                        title = "6. STATUS OF FUTURE MODULES (PROMPTS 02–08)",
                        body = "• VehicleSystem: [NOT IMPLEMENTED] — Reserved for Prompt 02 (Chaos physics, 125cc bike, diesel flatbed, luxury sedan hooks defined in UKarachiWorldSubsystem)\n" +
                               "• WeaponSystem: [NOT IMPLEMENTED] — Reserved for Prompt 03\n" +
                               "• CharacterSystem: [NOT IMPLEMENTED] — Reserved for Prompt 04\n" +
                               "• PoliceSystem: [NOT IMPLEMENTED] — Reserved for Prompt 05\n" +
                               "• AIWorldSystem: [NOT IMPLEMENTED] — Reserved for Prompt 06\n" +
                               "• WeatherSystem: [NOT IMPLEMENTED] — Reserved for Prompt 07\n" +
                               "• EconomySystem: [NOT IMPLEMENTED] — Reserved for Prompt 08"
                    )
                }
            }
        }
    }
}

@Composable
private fun SpecificationSection(title: String, body: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = KarachiCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(body, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
    }
}
