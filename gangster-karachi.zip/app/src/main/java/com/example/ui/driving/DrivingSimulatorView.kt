package com.example.ui.driving

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.*
import com.example.ui.theme.*
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun DrivingSimulatorView(
    vehicle: Vehicle,
    drivingState: DrivingSimulationState,
    onThrottleChange: (Float) -> Unit,
    onBrakeChange: (Float) -> Unit,
    onSteeringChange: (Float) -> Unit,
    onHandbrakeChange: (Boolean) -> Unit,
    onSurfaceChange: (RoadSurface) -> Unit,
    onToggleAssist: (String) -> Unit,
    onCycleCamera: () -> Unit,
    onToggleLights: () -> Unit,
    onToggleSiren: () -> Unit,
    onHornPress: (Boolean) -> Unit,
    onCollisionTrigger: (Float) -> Unit,
    onRepairVehicle: () -> Unit,
    onOpenGarage: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .verticalScroll(scrollState)
            .padding(16.dp)
            .testTag("driving_simulator_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Vehicle Header & Quick Selector
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = vehicle.name.uppercase(),
                    style = MaterialTheme.typography.titleMedium,
                    color = KarachiGold,
                    fontWeight = FontWeight.ExtraBold
                )
                Text(
                    text = "${vehicle.manufacturer} • ${vehicle.categorySubtitle}",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = KarachiSurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan),
                onClick = onOpenGarage
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(Icons.Default.Build, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(16.dp))
                    Text("Tuning Garage", color = KarachiCyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // Visual Viewport / Vehicle Display Banner
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Box(modifier = Modifier.fillMaxWidth().height(180.dp)) {
                Image(
                    painter = painterResource(id = R.drawable.img_hero_tuner_car),
                    contentDescription = "Active Vehicle Viewport",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Headlight illumination / night glare overlay
                if (drivingState.headlightsOn) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(Color.Transparent, Color(0xFFFFF9C4).copy(alpha = 0.15f), Color.Transparent)
                                )
                            )
                    )
                }

                // Camera Mode Pill
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = KarachiObsidian.copy(alpha = 0.85f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan),
                    modifier = Modifier.align(Alignment.TopStart).padding(10.dp)
                ) {
                    Text(
                        text = "CAM: ${drivingState.cameraView.title.uppercase()}",
                        style = MaterialTheme.typography.labelSmall,
                        color = KarachiCyan,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }

                // Drivetrain & Surface Indicator
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = KarachiObsidian.copy(alpha = 0.85f),
                    modifier = Modifier.align(Alignment.TopEnd).padding(10.dp)
                ) {
                    Text(
                        text = "${vehicle.physics.drivetrain.name} | ${drivingState.activeSurface.name.split("_")[0]}",
                        style = MaterialTheme.typography.labelSmall,
                        color = KarachiGold,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }

                // Emergency siren flasher overlay
                if (drivingState.policeSirenActive) {
                    val infiniteTransition = rememberInfiniteTransition(label = "siren")
                    val sirenAlpha by infiniteTransition.animateFloat(
                        initialValue = 0.1f,
                        targetValue = 0.45f,
                        animationSpec = infiniteRepeatable(tween(350, easing = LinearEasing), RepeatMode.Reverse),
                        label = "sirenFlash"
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(KarachiCrimson.copy(alpha = sirenAlpha), Color.Transparent, KarachiCyan.copy(alpha = sirenAlpha))
                                )
                            )
                    )
                }
            }
        }

        // Cockpit Telemetry Instruments (Speedometer, Tachometer, Gear, G-Force)
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KarachiSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // 1. Digital Speedometer
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${drivingState.currentSpeedKmh.toInt()}",
                            style = MaterialTheme.typography.displayMedium,
                            color = KarachiGold,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("KM/H", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
                    }

                    // 2. Active Gear Indicator
                    Box(
                        modifier = Modifier
                            .size(54.dp)
                            .clip(CircleShape)
                            .background(KarachiDarkNavy)
                            .border(2.dp, KarachiGold, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (drivingState.isReverse) "R" else if (drivingState.currentSpeedKmh < 1f) "N" else "${drivingState.currentGear}",
                            style = MaterialTheme.typography.titleLarge,
                            color = KarachiGold,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace
                        )
                    }

                    // 3. RPM Meter
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${drivingState.currentRpm.toInt()}",
                            style = MaterialTheme.typography.titleLarge,
                            color = if (drivingState.currentRpm > 6800f) KarachiCrimson else KarachiCyan,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                        Text("ENGINE RPM", style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
                    }
                }

                // RPM Gauge Progress Bar
                LinearProgressIndicator(
                    progress = { (drivingState.currentRpm / 8500f).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                    color = if (drivingState.currentRpm > 6800f) KarachiCrimson else KarachiCyan,
                    trackColor = KarachiObsidian
                )

                // Suspension & G-Force Telemetry Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "LATERAL G: ${String.format("%.2f", drivingState.lateralGForce)}G",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextPrimary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "TIRE SLIP: ${drivingState.tireSlipPercentage.toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (drivingState.tireSlipPercentage > 40f) KarachiCrimson else KarachiGold,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "DAMAGE: ${(100f - vehicle.damage.engineHealthPct).toInt()}%",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (vehicle.damage.engineHealthPct < 70f) KarachiCrimson else KarachiEmerald,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // 4-Wheel Independent Suspension Compression Bars
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    WheelSuspensionBar("FL", drivingState.suspensionCompressionFL, Modifier.weight(1f))
                    WheelSuspensionBar("FR", drivingState.suspensionCompressionFR, Modifier.weight(1f))
                    WheelSuspensionBar("RL", drivingState.suspensionCompressionRL, Modifier.weight(1f))
                    WheelSuspensionBar("RR", drivingState.suspensionCompressionRR, Modifier.weight(1f))
                }
            }
        }

        // Road Surface Condition Selector
        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("TEST SURFACE FRICTION COEFFICIENT", style = MaterialTheme.typography.labelSmall, color = KarachiGold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(RoadSurface.values()) { surf ->
                    val isSelected = surf == drivingState.activeSurface
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSurfaceChange(surf) },
                        label = { Text(surf.label.split("(")[0].trim(), fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = KarachiGold,
                            selectedLabelColor = KarachiObsidian
                        )
                    )
                }
            }
        }

        // Interactive Driving Pedals & Steering Controls
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("PHYSICS DRIVING CONTROLS", style = MaterialTheme.typography.labelSmall, color = KarachiCyan)

                // Steering Controls (-40 deg to +40 deg)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = { onSteeringChange(-35f) },
                        colors = ButtonDefaults.buttonColors(containerColor = KarachiSurface),
                        modifier = Modifier.weight(1f).testTag("steer_left_button")
                    ) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Steer Left", tint = KarachiCyan)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Steer L", fontSize = 11.sp, color = TextPrimary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { onSteeringChange(0f) },
                        colors = ButtonDefaults.buttonColors(containerColor = KarachiObsidian),
                        modifier = Modifier.weight(0.8f).testTag("steer_center_button")
                    ) {
                        Text("Center", fontSize = 11.sp, color = TextSecondary)
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    Button(
                        onClick = { onSteeringChange(35f) },
                        colors = ButtonDefaults.buttonColors(containerColor = KarachiSurface),
                        modifier = Modifier.weight(1f).testTag("steer_right_button")
                    ) {
                        Text("Steer R", fontSize = 11.sp, color = TextPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.Default.ArrowForward, contentDescription = "Steer Right", tint = KarachiCyan)
                    }
                }

                // Pedals Row: Throttle (Gas), Brake, Handbrake (Drift)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Foot Brake Pedal
                    Button(
                        onClick = {
                            if (drivingState.brakeInput > 0f) onBrakeChange(0f) else onBrakeChange(1.0f)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (drivingState.brakeInput > 0f) KarachiCrimson else KarachiSurfaceVariant
                        ),
                        modifier = Modifier.weight(1f).height(54.dp).testTag("pedal_brake")
                    ) {
                        Icon(Icons.Default.Gavel, contentDescription = null, tint = TextPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("BRAKE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }

                    // Handbrake / Drift Button
                    Button(
                        onClick = { onHandbrakeChange(!drivingState.handbrakeActive) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (drivingState.handbrakeActive) Color(0xFFFF9800) else KarachiSurfaceVariant
                        ),
                        modifier = Modifier.weight(1f).height(54.dp).testTag("pedal_handbrake")
                    ) {
                        Icon(Icons.Default.SportsScore, contentDescription = null, tint = TextPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(if (drivingState.handbrakeActive) "DRIFT ON" else "HANDBRAKE", fontSize = 10.sp)
                    }

                    // Gas Throttle Pedal
                    Button(
                        onClick = {
                            if (drivingState.throttleInput > 0f) onThrottleChange(0f) else onThrottleChange(1.0f)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (drivingState.throttleInput > 0f) KarachiGold else KarachiSurfaceVariant
                        ),
                        modifier = Modifier.weight(1.2f).height(54.dp).testTag("pedal_gas")
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = if (drivingState.throttleInput > 0f) KarachiObsidian else TextPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("THROTTLE", color = if (drivingState.throttleInput > 0f) KarachiObsidian else TextPrimary, fontWeight = FontWeight.ExtraBold, fontSize = 11.sp)
                    }
                }
            }
        }

        // Auxiliary Vehicle Features & Assist Toggles
        Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = KarachiSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("VEHICLE AUXILIARIES & DRIVING ASSISTS", style = MaterialTheme.typography.labelSmall, color = KarachiGold)

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistToggleButton("ABS", drivingState.absActive, { onToggleAssist("ABS") }, Modifier.weight(1f))
                    AssistToggleButton("TCS", drivingState.tcsActive, { onToggleAssist("TCS") }, Modifier.weight(1f))
                    AssistToggleButton("ESC", drivingState.escActive, { onToggleAssist("ESC") }, Modifier.weight(1f))
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onToggleLights,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = if (drivingState.headlightsOn) KarachiGold else TextSecondary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (drivingState.headlightsOn) KarachiGold else KarachiBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Lightbulb, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Lights", fontSize = 10.sp)
                    }

                    OutlinedButton(
                        onClick = onToggleSiren,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = if (drivingState.policeSirenActive) KarachiCrimson else TextSecondary),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (drivingState.policeSirenActive) KarachiCrimson else KarachiBorder),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Emergency, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Siren", fontSize = 10.sp)
                    }

                    OutlinedButton(
                        onClick = onCycleCamera,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = KarachiCyan),
                        border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Camera", fontSize = 10.sp)
                    }
                }

                // Crash Simulator & Repair Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onCollisionTrigger(75f) },
                        colors = ButtonDefaults.buttonColors(containerColor = KarachiCrimson.copy(alpha = 0.85f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Dangerous, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Test Collision Impact", fontSize = 11.sp, color = Color.White)
                    }

                    Button(
                        onClick = onRepairVehicle,
                        colors = ButtonDefaults.buttonColors(containerColor = KarachiEmerald.copy(alpha = 0.85f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Healing, contentDescription = null, tint = KarachiObsidian, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Full Repair", fontSize = 11.sp, color = KarachiObsidian, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
private fun WheelSuspensionBar(wheelLabel: String, compression: Float, modifier: Modifier = Modifier) {
    Column(modifier = modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(wheelLabel, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 9.sp)
        Spacer(modifier = Modifier.height(2.dp))
        LinearProgressIndicator(
            progress = { compression },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
            color = if (compression > 0.75f) KarachiCrimson else KarachiCyan,
            trackColor = KarachiObsidian
        )
    }
}

@Composable
private fun AssistToggleButton(label: String, active: Boolean, onToggle: () -> Unit, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = if (active) KarachiCyan.copy(alpha = 0.2f) else KarachiObsidian,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (active) KarachiCyan else KarachiBorder),
        onClick = onToggle,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = if (active) KarachiCyan else TextSecondary, fontWeight = FontWeight.Bold)
            Text(if (active) "ACTIVE" else "OFF", style = MaterialTheme.typography.labelSmall, color = if (active) KarachiEmerald else TextMuted, fontSize = 8.sp)
        }
    }
}
