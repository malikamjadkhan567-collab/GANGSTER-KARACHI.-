package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.*
import com.example.ui.CameraMode
import com.example.ui.ViewLayer
import com.example.ui.theme.*
import kotlin.math.*

@OptIn(ExperimentalTextApi::class)
@Composable
fun KarachiMapCanvas(
    districts: List<District>,
    landmarks: List<Landmark>,
    selectedDistrict: District,
    selectedLandmark: Landmark?,
    activeProtagonist: Protagonist,
    playerPos: Pair<Float, Float>,
    timeOfDay: TimeOfDay,
    viewLayer: ViewLayer,
    cameraMode: CameraMode,
    activeDataLayers: Set<WorldDataLayer>,
    categoryFilter: LandmarkCategory?,
    onDistrictClick: (District) -> Unit,
    onLandmarkClick: (Landmark) -> Unit,
    onMapTap: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }

    // Wave animation for the Arabian Sea
    val infiniteTransition = rememberInfiniteTransition(label = "oceanWave")
    val waveOffset by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 40f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveOffset"
    )

    val textMeasurer = rememberTextMeasurer()

    Box(
        modifier = modifier
            .fillMaxSize()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF070B12))
            .testTag("karachi_map_canvas_container")
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("karachi_map_canvas")
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        scale = (scale * zoom).coerceIn(0.8f, 3.5f)
                        val maxOffset = 500f * scale
                        offset = Offset(
                            (offset.x + pan.x).coerceIn(-maxOffset, maxOffset),
                            (offset.y + pan.y).coerceIn(-maxOffset, maxOffset)
                        )
                    }
                }
                .pointerInput(Unit) {
                    detectTapGestures { tapOffset ->
                        // Calculate normalized map coordinates
                        // Invert the transformation: tapOffset = original * scale + offset
                        // Therefore original = (tapOffset - offset) / scale
                        val canvasW = size.width
                        val canvasH = size.height
                        val origX = (tapOffset.x - offset.x) / scale
                        val origY = (tapOffset.y - offset.y) / scale
                        val normX = (origX / canvasW).coerceIn(0f, 1f)
                        val normY = (origY / canvasH).coerceIn(0f, 1f)

                        // Check if tapped near a landmark
                        val tappedLandmark = landmarks.find { lm ->
                            val dx = (lm.posX * canvasW) - origX
                            val dy = (lm.posY * canvasH) - origY
                            sqrt(dx * dx + dy * dy) < 28f
                        }

                        if (tappedLandmark != null) {
                            onLandmarkClick(tappedLandmark)
                        } else {
                            // Check if tapped inside a district
                            val tappedDistrict = districts.minByOrNull { d ->
                                val dx = (d.mapCoordsX * canvasW) - origX
                                val dy = (d.mapCoordsY * canvasH) - origY
                                dx * dx + dy * dy
                            }
                            if (tappedDistrict != null) {
                                onDistrictClick(tappedDistrict)
                            }
                            onMapTap(normX, normY)
                        }
                    }
                }
        ) {
            val width = size.width
            val height = size.height

            // Apply viewport transformation
            drawContext.transform.translate(offset.x, offset.y)
            drawContext.transform.scale(scale, scale, Offset(width / 2f, height / 2f))

            // 1. Draw Base Terrain & Arabian Sea Water
            drawOceanAndCoast(width, height, waveOffset, timeOfDay)

            // 2. Draw Northern Hills & Greenbelt
            drawTopography(width, height, timeOfDay)

            // 3. Draw World Partition Streaming Grid (if Terrain / Core layer enabled)
            if (activeDataLayers.contains(WorldDataLayer.LAYER_TERRAIN_NANITE)) {
                drawWorldPartitionGrid(width, height, playerPos)
            }

            // 4. Draw District Boundaries & Heatmaps
            drawDistrictZones(districts, selectedDistrict, width, height, textMeasurer)

            // 5. Draw Road Networks, Highways & Tunnels (Traffic Nav Grid)
            if (activeDataLayers.contains(WorldDataLayer.LAYER_TRAFFIC_NAV)) {
                drawRoadNetwork(width, height, viewLayer)
            }

            // 6. Draw Layer specific features (Underground sewers or Rooftops)
            if (viewLayer == ViewLayer.UNDERGROUND && activeDataLayers.contains(WorldDataLayer.LAYER_UNDERGROUND_SEWER)) {
                drawUndergroundTunnels(width, height)
            } else if (viewLayer == ViewLayer.ROOFTOP) {
                drawRooftopSkywalks(width, height)
            }

            // 7. Draw Landmarks
            drawLandmarksLayer(landmarks, categoryFilter, selectedLandmark, width, height, viewLayer)

            // 8. Draw Protagonist Starting Safehouse Spawns
            drawProtagonistSpawns(activeProtagonist, width, height, textMeasurer)

            // 9. Draw Active Player Location Marker
            drawPlayerMarker(playerPos, width, height)
        }

        // Map HUD Controls Overlay
        MapHudOverlay(
            scale = scale,
            viewLayer = viewLayer,
            cameraMode = cameraMode,
            timeOfDay = timeOfDay,
            onResetView = {
                scale = 1f
                offset = Offset.Zero
            },
            onZoomIn = { scale = (scale * 1.25f).coerceAtMost(3.5f) },
            onZoomOut = { scale = (scale / 1.25f).coerceAtLeast(0.8f) },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
        )
    }
}

private fun DrawScope.drawOceanAndCoast(width: Float, height: Float, waveOffset: Float, tod: TimeOfDay) {
    // Arabian Sea in the south and south-west
    val oceanColor = when (tod) {
        TimeOfDay.DAWN -> Color(0xFF1A334B)
        TimeOfDay.NOON -> Color(0xFF0F4C75)
        TimeOfDay.GOLDEN_HOUR -> Color(0xFF1E3A5F)
        TimeOfDay.TWILIGHT -> Color(0xFF0B1E36)
        TimeOfDay.MIDNIGHT -> Color(0xFF050B14)
    }

    // Coastal Water Polygon (Bottom-left corner to bottom right)
    val oceanPath = Path().apply {
        moveTo(0f, height * 0.65f)
        cubicTo(
            width * 0.15f, height * (0.68f + (waveOffset * 0.001f)),
            width * 0.35f, height * 0.72f,
            width * 0.60f, height * 0.88f
        )
        lineTo(width, height * 0.95f)
        lineTo(width, height)
        lineTo(0f, height)
        close()
    }
    drawPath(oceanPath, oceanColor)

    // Beach Sand Shoreline (Ocean Drive / Sea View)
    val sandColor = Color(0xFFC2B280).copy(alpha = 0.35f)
    drawPath(
        oceanPath,
        brush = Brush.verticalGradient(
            colors = listOf(sandColor, Color.Transparent),
            startY = height * 0.64f,
            endY = height * 0.76f
        ),
        style = Stroke(width = 14f)
    )
}

private fun DrawScope.drawTopography(width: Float, height: Float, tod: TimeOfDay) {
    // Northern Hills (Top region)
    val hillsColor = Color(0xFF3E2723).copy(alpha = 0.25f)
    drawOval(
        color = hillsColor,
        topLeft = Offset(width * 0.20f, -height * 0.10f),
        size = Size(width * 0.60f, height * 0.35f)
    )

    // Greenbelt Nature Reserve (Top right)
    val greenbeltColor = Color(0xFF1B5E20).copy(alpha = 0.22f)
    drawOval(
        color = greenbeltColor,
        topLeft = Offset(width * 0.55f, height * 0.05f),
        size = Size(width * 0.40f, height * 0.30f)
    )
}

private fun DrawScope.drawWorldPartitionGrid(width: Float, height: Float, playerPos: Pair<Float, Float>) {
    val gridSize = 8
    val cellW = width / gridSize
    val cellH = height / gridSize

    val playerCellX = (playerPos.first * gridSize).toInt().coerceIn(0, gridSize - 1)
    val playerCellY = (playerPos.second * gridSize).toInt().coerceIn(0, gridSize - 1)

    for (x in 0 until gridSize) {
        for (y in 0 until gridSize) {
            val dist = max(abs(x - playerCellX), abs(y - playerCellY))
            val cellColor = when {
                dist == 0 -> KarachiGold.copy(alpha = 0.18f) // Priority player cell
                dist <= 1 -> KarachiCyan.copy(alpha = 0.10f) // Loaded Nanite cells
                dist <= 2 -> Color(0xFF64B5F6).copy(alpha = 0.04f) // HLOD cells
                else -> Color.Transparent
            }
            if (cellColor != Color.Transparent) {
                drawRect(
                    color = cellColor,
                    topLeft = Offset(x * cellW, y * cellH),
                    size = Size(cellW, cellH)
                )
            }
            // Grid lines
            drawRect(
                color = KarachiBorder.copy(alpha = 0.30f),
                topLeft = Offset(x * cellW, y * cellH),
                size = Size(cellW, cellH),
                style = Stroke(width = 1f)
            )
        }
    }
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawDistrictZones(
    districts: List<District>,
    selected: District,
    width: Float,
    height: Float,
    textMeasurer: TextMeasurer
) {
    districts.forEach { d ->
        val centerX = d.mapCoordsX * width
        val centerY = d.mapCoordsY * height
        val radiusPx = d.radius * width

        val isSelected = d.id == selected.id
        val districtColor = Color(d.colorHex)

        // Zone area glow
        drawCircle(
            color = districtColor.copy(alpha = if (isSelected) 0.22f else 0.08f),
            radius = radiusPx,
            center = Offset(centerX, centerY)
        )
        // Zone boundary
        drawCircle(
            color = districtColor.copy(alpha = if (isSelected) 0.90f else 0.40f),
            radius = radiusPx,
            center = Offset(centerX, centerY),
            style = Stroke(width = if (isSelected) 3.5f else 1.5f)
        )

        // District Label
        val textResult = textMeasurer.measure(
            text = AnnotatedString(d.name.uppercase()),
            style = TextStyle(
                color = if (isSelected) KarachiGold else TextSecondary,
                fontSize = if (isSelected) 10.sp else 8.sp,
                fontWeight = if (isSelected) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Medium
            )
        )
        drawText(
            textLayoutResult = textResult,
            topLeft = Offset(centerX - textResult.size.width / 2f, centerY - textResult.size.height / 2f)
        )
    }
}

private fun DrawScope.drawRoadNetwork(width: Float, height: Float, layer: ViewLayer) {
    val roadAlpha = if (layer == ViewLayer.UNDERGROUND) 0.20f else 0.85f

    // 1. Outer Highway Ring Expressway (Connects peripheral districts)
    val outerHighwayPath = Path().apply {
        moveTo(width * 0.15f, height * 0.70f)
        cubicTo(width * 0.10f, height * 0.40f, width * 0.25f, height * 0.15f, width * 0.48f, height * 0.12f)
        cubicTo(width * 0.75f, height * 0.10f, width * 0.85f, height * 0.30f, width * 0.78f, height * 0.55f)
        cubicTo(width * 0.75f, height * 0.70f, width * 0.60f, height * 0.85f, width * 0.38f, height * 0.80f)
    }
    // Highway outline & glow
    drawPath(outerHighwayPath, KarachiGold.copy(alpha = 0.4f * roadAlpha), style = Stroke(width = 8f))
    drawPath(outerHighwayPath, Color(0xFF2C3E50).copy(alpha = roadAlpha), style = Stroke(width = 5f))

    // 2. Coastal Freeway (Port -> Ocean Drive -> Clifton Heights -> Defence)
    val coastalFreeway = Path().apply {
        moveTo(width * 0.16f, height * 0.68f)
        cubicTo(width * 0.28f, height * 0.74f, width * 0.38f, height * 0.78f, width * 0.48f, height * 0.66f)
        lineTo(width * 0.68f, height * 0.58f)
    }
    drawPath(coastalFreeway, KarachiCyan.copy(alpha = 0.5f * roadAlpha), style = Stroke(width = 6f))
    drawPath(coastalFreeway, Color(0xFF1E2840).copy(alpha = roadAlpha), style = Stroke(width = 4f))

    // 3. Central Arterial Boulevard (Airport -> Downtown -> Saddar -> Old Town -> Port)
    val centralBoulevard = Path().apply {
        moveTo(width * 0.76f, height * 0.32f) // Airport
        lineTo(width * 0.58f, height * 0.42f)
        lineTo(width * 0.52f, height * 0.44f) // Downtown
        lineTo(width * 0.44f, height * 0.42f) // Saddar
        lineTo(width * 0.36f, height * 0.46f) // Old Town
        lineTo(width * 0.22f, height * 0.54f) // Industrial
        lineTo(width * 0.16f, height * 0.68f) // Port
    }
    drawPath(centralBoulevard, Color(0xFF334E68).copy(alpha = roadAlpha), style = Stroke(width = 5f))

    // 4. Northern Mountain Pass Road
    val mountainPass = Path().apply {
        moveTo(width * 0.46f, height * 0.12f)
        cubicTo(width * 0.40f, height * 0.22f, width * 0.42f, height * 0.30f, width * 0.44f, height * 0.42f)
    }
    drawPath(mountainPass, Color(0xFF8D6E63).copy(alpha = roadAlpha), style = Stroke(width = 3.5f))
}

private fun DrawScope.drawUndergroundTunnels(width: Float, height: Float) {
    // Glowing cyan/green sewer and utility tunnels
    val sewerSpine = Path().apply {
        moveTo(width * 0.32f, height * 0.38f) // Lyari
        lineTo(width * 0.42f, height * 0.40f) // Saddar
        lineTo(width * 0.52f, height * 0.46f) // Downtown vault
        lineTo(width * 0.44f, height * 0.10f) // Northern quarry bunker link
    }
    drawPath(sewerSpine, KarachiEmerald.copy(alpha = 0.7f), style = Stroke(width = 4.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f))))
}

private fun DrawScope.drawRooftopSkywalks(width: Float, height: Float) {
    // Glowing amber rooftop corridors across Lyari and Downtown
    val lyariRooftops = Path().apply {
        moveTo(width * 0.30f, height * 0.37f)
        lineTo(width * 0.32f, height * 0.39f)
        lineTo(width * 0.34f, height * 0.38f)
        lineTo(width * 0.33f, height * 0.40f)
    }
    drawPath(lyariRooftops, KarachiGold.copy(alpha = 0.9f), style = Stroke(width = 4f))

    val downtownSkywalks = Path().apply {
        moveTo(width * 0.50f, height * 0.43f)
        lineTo(width * 0.53f, height * 0.45f)
        lineTo(width * 0.55f, height * 0.42f)
    }
    drawPath(downtownSkywalks, KarachiCyan.copy(alpha = 0.9f), style = Stroke(width = 4f))
}

private fun DrawScope.drawLandmarksLayer(
    landmarks: List<Landmark>,
    categoryFilter: LandmarkCategory?,
    selectedLandmark: Landmark?,
    width: Float,
    height: Float,
    viewLayer: ViewLayer
) {
    landmarks.forEach { lm ->
        if (categoryFilter != null && lm.category != categoryFilter) return@forEach

        val isSelected = selectedLandmark?.id == lm.id
        val posX = lm.posX * width
        val posY = lm.posY * height

        val pinColor = when (lm.category) {
            LandmarkCategory.EMERGENCY -> KarachiCrimson
            LandmarkCategory.COMMERCE -> KarachiGold
            LandmarkCategory.TRANSPORTATION -> KarachiCyan
            LandmarkCategory.ENTERTAINMENT -> KarachiPurple
            LandmarkCategory.GAMEPLAY -> KarachiEmerald
        }

        // Selection Pulse
        if (isSelected) {
            drawCircle(color = pinColor.copy(alpha = 0.4f), radius = 16f, center = Offset(posX, posY))
        }

        // Outer ring & pin body
        drawCircle(color = Color.Black, radius = 9f, center = Offset(posX, posY))
        drawCircle(color = pinColor, radius = 7f, center = Offset(posX, posY))
        drawCircle(color = Color.White, radius = 2.5f, center = Offset(posX, posY))
    }
}

@OptIn(ExperimentalTextApi::class)
private fun DrawScope.drawProtagonistSpawns(
    activeProtagonist: Protagonist,
    width: Float,
    height: Float,
    textMeasurer: TextMeasurer
) {
    // Draw spawn markers for Ayan, Shahroz, Daniyal
    val spawns = listOf(
        Triple("AYAN", Offset(0.31f * width, 0.39f * height), Color(0xFFFF5722)),
        Triple("SHAHROZ", Offset(0.17f * width, 0.67f * height), Color(0xFF546E7A)),
        Triple("DANIYAL", Offset(0.70f * width, 0.60f * height), Color(0xFFFFD700))
    )

    spawns.forEach { (name, pos, col) ->
        val isActive = activeProtagonist.name.uppercase().contains(name)
        drawCircle(
            color = col.copy(alpha = if (isActive) 0.6f else 0.25f),
            radius = if (isActive) 18f else 11f,
            center = pos
        )
        drawCircle(
            color = col,
            radius = if (isActive) 8f else 5f,
            center = pos
        )

        val badgeText = textMeasurer.measure(
            text = AnnotatedString("★ $name"),
            style = TextStyle(
                color = col,
                fontSize = 8.sp,
                fontWeight = androidx.compose.ui.text.font.FontWeight.Bold
            )
        )
        drawText(
            textLayoutResult = badgeText,
            topLeft = Offset(pos.x - badgeText.size.width / 2f, pos.y + 10f)
        )
    }
}

private fun DrawScope.drawPlayerMarker(playerPos: Pair<Float, Float>, width: Float, height: Float) {
    val px = playerPos.first * width
    val py = playerPos.second * height

    // Glowing player radar reticle
    drawCircle(color = KarachiGold.copy(alpha = 0.35f), radius = 22f, center = Offset(px, py))
    drawCircle(color = KarachiGold, radius = 6f, center = Offset(px, py))
    drawCircle(color = Color.White, radius = 2.5f, center = Offset(px, py))

    // Directional orientation reticle spikes
    drawLine(color = KarachiGold, start = Offset(px - 14f, py), end = Offset(px - 7f, py), strokeWidth = 2f)
    drawLine(color = KarachiGold, start = Offset(px + 7f, py), end = Offset(px + 14f, py), strokeWidth = 2f)
    drawLine(color = KarachiGold, start = Offset(px, py - 14f), end = Offset(px, py - 7f), strokeWidth = 2f)
    drawLine(color = KarachiGold, start = Offset(px, py + 7f), end = Offset(px, py + 14f), strokeWidth = 2f)
}

@Composable
private fun MapHudOverlay(
    scale: Float,
    viewLayer: ViewLayer,
    cameraMode: CameraMode,
    timeOfDay: TimeOfDay,
    onResetView: () -> Unit,
    onZoomIn: () -> Unit,
    onZoomOut: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.End,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Telemetry Badge
        Surface(
            shape = RoundedCornerShape(8.dp),
            color = KarachiObsidian.copy(alpha = 0.85f),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
        ) {
            Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                Text(
                    text = "KARACHI METRO // ENGINE",
                    style = MaterialTheme.typography.labelSmall,
                    color = KarachiGold,
                    fontSize = 9.sp
                )
                Text(
                    text = "LAYER: ${viewLayer.name} | ZOOM: ${(scale * 100).toInt()}%",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextPrimary,
                    fontSize = 10.sp
                )
                Text(
                    text = "LIGHTING: ${timeOfDay.label.split("-")[0].trim()}",
                    style = MaterialTheme.typography.bodySmall,
                    color = KarachiCyan,
                    fontSize = 9.sp
                )
            }
        }

        // Zoom & Reset buttons
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            IconButton(
                onClick = onZoomIn,
                modifier = Modifier
                    .size(40.dp)
                    .background(KarachiSurface, RoundedCornerShape(8.dp))
                    .testTag("map_zoom_in")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = TextPrimary)
            }
            IconButton(
                onClick = onZoomOut,
                modifier = Modifier
                    .size(40.dp)
                    .background(KarachiSurface, RoundedCornerShape(8.dp))
                    .testTag("map_zoom_out")
            ) {
                Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = TextPrimary)
            }
            IconButton(
                onClick = onResetView,
                modifier = Modifier
                    .size(40.dp)
                    .background(KarachiSurface, RoundedCornerShape(8.dp))
                    .testTag("map_reset_view")
            ) {
                Icon(Icons.Default.CenterFocusStrong, contentDescription = "Center View", tint = KarachiGold)
            }
        }
    }
}
