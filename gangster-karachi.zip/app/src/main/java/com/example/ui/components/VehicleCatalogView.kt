package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Vehicle
import com.example.data.model.VehicleCategory
import com.example.ui.theme.*

@Composable
fun VehicleCatalogView(
    vehicles: List<Vehicle>,
    selectedVehicle: Vehicle,
    onSelectVehicle: (Vehicle) -> Unit,
    onStartDrive: (Vehicle) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategoryFilter by remember { mutableStateOf<VehicleCategory?>(null) }
    var searchQuery by remember { mutableStateOf("") }

    val filtered = vehicles.filter { v ->
        (selectedCategoryFilter == null || v.category == selectedCategoryFilter) &&
        (searchQuery.isEmpty() || v.name.contains(searchQuery, ignoreCase = true) || v.manufacturer.contains(searchQuery, ignoreCase = true) || v.categorySubtitle.contains(searchQuery, ignoreCase = true))
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("vehicle_catalog_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "KARACHI METRO // VEHICLE FLEET",
                    style = MaterialTheme.typography.titleMedium,
                    color = KarachiGold,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Cars • Bikes • Boats • Aircraft • Heavy Trucks • Emergency",
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
            }
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = KarachiSurfaceVariant
            ) {
                Text(
                    text = "${filtered.size} VEHICLES",
                    style = MaterialTheme.typography.labelSmall,
                    color = KarachiCyan,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search by name, class, manufacturer...", fontSize = 12.sp, color = TextMuted) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = KarachiGold) },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { searchQuery = "" }) {
                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = TextSecondary)
                    }
                }
            },
            singleLine = true,
            modifier = Modifier.fillMaxWidth().testTag("vehicle_search_input"),
            shape = RoundedCornerShape(10.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = KarachiSurface,
                unfocusedContainerColor = KarachiSurface,
                focusedBorderColor = KarachiGold,
                unfocusedBorderColor = KarachiBorder,
                focusedTextColor = TextPrimary,
                unfocusedTextColor = TextPrimary
            )
        )

        // Category Filter Chips
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                FilterChip(
                    selected = selectedCategoryFilter == null,
                    onClick = { selectedCategoryFilter = null },
                    label = { Text("All Fleet", fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = KarachiGold, selectedLabelColor = KarachiObsidian)
                )
            }
            items(VehicleCategory.values()) { cat ->
                val isSelected = selectedCategoryFilter == cat
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategoryFilter = if (isSelected) null else cat },
                    label = { Text(cat.displayName.split(" ")[0], fontSize = 10.sp) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = KarachiCyan, selectedLabelColor = KarachiObsidian)
                )
            }
        }

        // Vehicles List
        LazyColumn(
            modifier = Modifier.weight(1f),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(filtered) { veh ->
                val isCurrent = veh.id == selectedVehicle.id
                val specs = veh.physics

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = if (isCurrent) KarachiDarkNavy else KarachiSurface
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isCurrent) 2.dp else 1.dp,
                        color = if (isCurrent) KarachiGold else KarachiBorder
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectVehicle(veh) }
                        .testTag("vehicle_card_${veh.id}")
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = veh.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = "${veh.manufacturer} • ${veh.categorySubtitle}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = KarachiCyan,
                                    fontSize = 11.sp
                                )
                            }

                            if (veh.isHeroVehicle) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = KarachiGold
                                ) {
                                    Text(
                                        text = "HERO SPEC",
                                        color = KarachiObsidian,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 8.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }

                        Text(
                            text = veh.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary,
                            fontSize = 11.sp,
                            lineHeight = 15.sp
                        )

                        // Protagonist & Price Tag Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Affinity: ${veh.protagonistAffinity}",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (veh.protagonistAffinity == "Universal") TextMuted else KarachiGold,
                                fontSize = 10.sp
                            )
                            Text(
                                text = "PKR ${(veh.economy.purchasePricePkr / 100000)} Lakh",
                                style = MaterialTheme.typography.bodySmall,
                                color = KarachiEmerald,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Divider(color = KarachiBorder.copy(alpha = 0.5f))

                        // Mechanical Specs Grid
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            SpecBadge("POWER", "${specs.horsepower} HP")
                            SpecBadge("TORQUE", "${specs.torqueNm} Nm")
                            SpecBadge("0-100", "${specs.acceleration0To100}s")
                            SpecBadge("TOP SPEED", "${specs.topSpeedKmh} KM/H")
                            SpecBadge("DRIVE", specs.drivetrain.name)
                        }

                        // Drive Action Button
                        Button(
                            onClick = {
                                onSelectVehicle(veh)
                                onStartDrive(veh)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isCurrent) KarachiGold else KarachiSurfaceVariant
                            ),
                            modifier = Modifier.fillMaxWidth().height(40.dp)
                        ) {
                            Icon(
                                Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = if (isCurrent) KarachiObsidian else TextPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isCurrent) "DRIVE IN PHYSICS SIMULATOR" else "SELECT & TEST DRIVE",
                                color = if (isCurrent) KarachiObsidian else TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SpecBadge(label: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = TextMuted, fontSize = 8.sp)
        Text(value, style = MaterialTheme.typography.bodySmall, color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
    }
}
