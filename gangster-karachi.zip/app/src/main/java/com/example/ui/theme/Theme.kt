package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = KarachiGold,
    onPrimary = KarachiObsidian,
    primaryContainer = KarachiSurfaceVariant,
    onPrimaryContainer = KarachiGold,
    secondary = KarachiCyan,
    onSecondary = KarachiObsidian,
    secondaryContainer = KarachiSurface,
    onSecondaryContainer = KarachiCyan,
    tertiary = KarachiCrimson,
    onTertiary = Color.White,
    background = KarachiObsidian,
    onBackground = TextPrimary,
    surface = KarachiDarkNavy,
    onSurface = TextPrimary,
    surfaceVariant = KarachiSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = KarachiBorder,
    error = KarachiCrimson
)

private val LightColorScheme = DarkColorScheme // Game interface is locked to cinematic dark theme

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Preserve bespoke game theme
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
