package com.example.ui.character

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.CharacterSwitchMode
import com.example.data.model.PlayableCharacterData
import com.example.data.model.SwitchTransitionState
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun CharacterSwitcherView(
    viewModel: WorldViewModel,
    characters: List<PlayableCharacterData>,
    activeCharacter: PlayableCharacterData,
    switchMode: CharacterSwitchMode,
    transitionState: SwitchTransitionState,
    onSwitchRequested: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Box(modifier = modifier.fillMaxSize().background(KarachiObsidian)) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header: 3-Protagonist Switching Overview
            item {
                Card(
                    modifier = Modifier.fillMaxWidth().testTag("switch_header_card"),
                    colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "PROTAGONIST OPERATIONAL HUB",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = KarachiGold,
                                    fontWeight = FontWeight.ExtraBold,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "3 Persistent World Entities • Seamless Partition Switching",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = TextMuted
                                )
                            }

                            // Switch Mode Toggle (Cinematic vs Fast)
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = KarachiSurface,
                                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                                modifier = Modifier.clickable {
                                    val nextMode = if (switchMode == CharacterSwitchMode.CINEMATIC_SKY_CAMERA) {
                                        CharacterSwitchMode.FAST_SWITCH
                                    } else {
                                        CharacterSwitchMode.CINEMATIC_SKY_CAMERA
                                    }
                                    viewModel.setCharacterSwitchMode(nextMode)
                                }.testTag("switch_mode_toggle")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        if (switchMode == CharacterSwitchMode.CINEMATIC_SKY_CAMERA) Icons.Default.Videocam else Icons.Default.FlashOn,
                                        contentDescription = null,
                                        tint = KarachiCyan,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Text(
                                        text = if (switchMode == CharacterSwitchMode.CINEMATIC_SKY_CAMERA) "CINEMATIC SKY" else "FAST WARP",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = KarachiCyan,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Protagonist Cards (Ayan, Shahroz, Daniyal)
            items(characters) { charData ->
                val isActive = charData.id == activeCharacter.id
                val themeColor = Color(charData.themeColorHex)

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("protagonist_card_${charData.id}")
                        .clickable {
                            if (!isActive) {
                                onSwitchRequested(charData.id)
                            }
                        },
                    colors = CardDefaults.cardColors(
                        containerColor = if (isActive) KarachiSurface else KarachiDarkNavy
                    ),
                    border = androidx.compose.foundation.BorderStroke(
                        width = if (isActive) 2.dp else 1.dp,
                        color = if (isActive) themeColor else KarachiBorder
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // Character Portrait
                            val imageResId = when (charData.id) {
                                "ayan" -> R.drawable.img_ayan_portrait
                                "shahroz" -> R.drawable.img_shahroz_portrait
                                "daniyal" -> R.drawable.img_daniyal_portrait
                                else -> R.drawable.img_ayan_portrait
                            }

                            Box(
                                modifier = Modifier
                                    .size(72.dp)
                                    .clip(RoundedCornerShape(10.dp))
                                    .border(2.dp, themeColor, RoundedCornerShape(10.dp))
                            ) {
                                Image(
                                    painter = painterResource(id = imageResId),
                                    contentDescription = charData.fullName,
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = ContentScale.Crop
                                )
                                if (isActive) {
                                    Surface(
                                        color = themeColor,
                                        shape = RoundedCornerShape(topStart = 0.dp, bottomEnd = 0.dp, bottomStart = 4.dp, topEnd = 4.dp),
                                        modifier = Modifier.align(Alignment.BottomEnd)
                                    ) {
                                        Text(
                                            text = "ACTIVE",
                                            color = Color.Black,
                                            fontWeight = FontWeight.ExtraBold,
                                            fontSize = 8.sp,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }

                            // Info Header
                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = charData.fullName,
                                        style = MaterialTheme.typography.titleMedium,
                                        color = TextPrimary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "₨ ${(charData.cashBalancePkr / 1000)}K",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = KarachiGold,
                                        fontWeight = FontWeight.Bold,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }

                                Text(
                                    text = charData.title,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = themeColor,
                                    fontWeight = FontWeight.SemiBold
                                )

                                Spacer(modifier = Modifier.height(4.dp))

                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(Icons.Default.LocationOn, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(12.dp))
                                    Text(
                                        text = "${charData.currentDistrictName} (X: ${charData.worldPosX.toInt()}, Y: ${charData.worldPosY.toInt()})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondary,
                                        fontSize = 9.sp
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Stats Highlights
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            StatChip(label = "AGI", value = charData.baseStats.agility, color = KarachiCyan)
                            StatChip(label = "STR", value = charData.baseStats.strength, color = KarachiCrimson)
                            StatChip(label = "DRV", value = charData.baseStats.driving, color = KarachiGold)
                            StatChip(label = "SHT", value = charData.baseStats.shooting, color = Color(0xFFE2E8F0))
                            StatChip(label = "STL", value = charData.baseStats.stealth, color = Color(0xFFA855F7))
                            StatChip(label = "TEC", value = charData.baseStats.technicalSkill, color = Color(0xFF10B981))
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Safehouse & Current Loadout Details
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = KarachiObsidian,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "SAFEHOUSE: ${charData.safehouseName}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = KarachiGold,
                                        fontSize = 9.5.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "OUTFIT: ${charData.activeOutfit.name}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = themeColor,
                                        fontSize = 9.sp
                                    )
                                }

                                Spacer(modifier = Modifier.height(4.dp))

                                Text(
                                    text = charData.movementProfile.signatureMovementStyle,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        // Switch Button
                        if (!isActive) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = { onSwitchRequested(charData.id) },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("switch_to_${charData.id}_button"),
                                colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.SyncAlt, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "SWITCH TO ${charData.fullName.uppercase()}",
                                    color = Color.Black,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 0.5.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Cinematic Switch Overlay
        AnimatedVisibility(
            visible = transitionState != SwitchTransitionState.IDLE,
            enter = fadeIn(animationSpec = tween(200)),
            exit = fadeOut(animationSpec = tween(200))
        ) {
            CinematicSwitchOverlay(
                transitionState = transitionState,
                targetCharacter = activeCharacter
            )
        }
    }
}

@Composable
private fun StatChip(label: String, value: Int, color: Color) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = KarachiObsidian,
        border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(label, fontSize = 8.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Text("$value", fontSize = 11.sp, color = color, fontWeight = FontWeight.ExtraBold)
        }
    }
}

@Composable
fun CinematicSwitchOverlay(
    transitionState: SwitchTransitionState,
    targetCharacter: PlayableCharacterData
) {
    val infiniteTransition = rememberInfiniteTransition(label = "radar")
    val radarPulse by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(800, easing = LinearEasing), RepeatMode.Reverse),
        label = "pulse"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.85f)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(24.dp)
        ) {
            CircularProgressIndicator(
                color = Color(targetCharacter.themeColorHex),
                strokeWidth = 3.dp,
                modifier = Modifier.size(54.dp)
            )

            Text(
                text = when (transitionState) {
                    SwitchTransitionState.PULL_UP_CAMERA -> "HIGH-ALTITUDE DRONE CLIMB — 450M..."
                    SwitchTransitionState.MAP_PAN_OVERVIEW -> "STREAMING WORLD PARTITION SECTORS..."
                    SwitchTransitionState.DIVE_INTO_TARGET -> "FOCAL DIVE: ${targetCharacter.currentDistrictName.uppercase()}..."
                    SwitchTransitionState.COMPLETED -> "TARGET OPERATOR SYNCHRONIZED"
                    else -> "INITIALIZING CHARACTER TRANSITION..."
                },
                style = MaterialTheme.typography.titleSmall,
                color = KarachiGold,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )

            Text(
                text = "SYNCHRONIZING WITH ${targetCharacter.fullName.uppercase()}",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                fontSize = 11.sp
            )

            Surface(
                shape = RoundedCornerShape(8.dp),
                color = KarachiDarkNavy,
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("LAT/LON: [${targetCharacter.worldPosX.toInt()}, ${targetCharacter.worldPosY.toInt()}]", color = KarachiCyan, fontSize = 10.sp, fontFamily = FontFamily.Monospace)
                    Text("DISTRICT: ${targetCharacter.currentDistrictName}", color = TextPrimary, fontSize = 10.sp)
                }
            }
        }
    }
}
