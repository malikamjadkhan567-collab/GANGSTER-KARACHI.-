package com.example.ui.simulation

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PedestrianActionState
import com.example.data.model.PedestrianAgent

@Composable
fun PedestrianSimulationView(
    pedestrians: List<PedestrianAgent>,
    currentHour: Float,
    isRaining: Boolean,
    onTriggerGunfirePanic: () -> Unit,
    onTriggerRainShelter: () -> Unit,
    onResetPedestriansCalm: () -> Unit
) {
    val scheduleTitle = when {
        currentHour in 6.0f..10.0f -> "Morning Commute & Bazaar Opening"
        currentHour in 10.0f..17.0f -> "Daytime Commercial & Industrial Activity"
        currentHour in 17.0f..21.5f -> "Evening Peak: Saddar & Sea View Rush"
        currentHour in 21.5f..24.0f -> "Karachi Nightlife & Late Food Streets (Burns Road)"
        else -> "Late Night Sehri / Reduced Pedestrian Density"
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0D1117))
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Schedule & Perception Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF161B22)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF30363D))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "KARACHI PEDESTRIAN AI & SCHEDULE",
                            color = Color(0xFF00E5FF),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF21262D)
                        ) {
                            Text(
                                "${pedestrians.size} Active Agents",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        scheduleTitle,
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "Agents utilize perception cones (hearing 40m, vision 110°, lighting & rain occlusion) to modulate behavior dynamically.",
                        color = Color.Gray,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // Reaction Simulation Triggers
                    Text("Interactive World Triggers:", color = Color.LightGray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = onTriggerGunfirePanic,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F)),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("Simulate Gunshot Panic", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onTriggerRainShelter,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0288D1)),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("Seek Rain Shelter", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = onResetPedestriansCalm,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(6.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF388E3C)),
                            contentPadding = PaddingValues(vertical = 4.dp)
                        ) {
                            Text("Reset To Calm", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // List of Active Pedestrians
        items(pedestrians) { ped ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (ped.state.isPanicked) Color(0xFF2A1515) else Color(0xFF161B22)
                ),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (ped.state.isPanicked) Color(0xFFFF5252) else Color(0xFF30363D)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when {
                                            ped.state.isPanicked -> Color(0xFFFF1744)
                                            ped.hasUmbrella -> Color(0xFF00E5FF)
                                            else -> Color(0xFF00E676)
                                        }
                                    )
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                ped.name,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color(0xFF21262D)
                        ) {
                            Text(
                                "LOD ${ped.lodLevel}",
                                color = Color.LightGray,
                                fontSize = 9.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "${ped.outfitStyle} • District: ${ped.districtId.replace("d_", "").capitalize()}",
                        color = Color.Gray,
                        fontSize = 10.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (ped.state.isPanicked) Color(0xFFD32F2F).copy(alpha = 0.2f) else Color(0xFF00E5FF).copy(alpha = 0.15f)
                        ) {
                            Text(
                                ped.state.displayName,
                                color = if (ped.state.isPanicked) Color(0xFFFF5252) else Color(0xFF00E5FF),
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }

                        if (ped.hasUmbrella) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Umbrella, contentDescription = null, tint = Color(0xFF64B5F6), modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Umbrella Equipped", color = Color(0xFF64B5F6), fontSize = 10.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        "\"${ped.dialogueSnippet}\"",
                        color = Color(0xFFFFD54F),
                        fontSize = 11.sp,
                        fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                    )
                }
            }
        }
    }
}
