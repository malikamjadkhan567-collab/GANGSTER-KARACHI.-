package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UE5CombatArchitectureData
import com.example.ui.theme.*

@Composable
fun UE5CombatArchitectureViewer(
    modifier: Modifier = Modifier
) {
    var selectedCodeTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current

    val codeSnippets = listOf(
        Pair("KarachiWeaponDataAsset.h", UE5CombatArchitectureData.weaponDataAssetHeader),
        Pair("KarachiWeaponBase.h", UE5CombatArchitectureData.weaponBaseHeader),
        Pair("KarachiPoliceWantedSubsystem.h", UE5CombatArchitectureData.policeWantedSubsystemHeader)
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("ue5_combat_architecture_viewer"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "UE5 // COMBAT & WANTED SUBSYSTEMS",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Ballistics • 5-Star Wanted Subsystem • Recoil • Stealth AI",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = KarachiSurface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCyan)
                ) {
                    Text(
                        text = "PROMPT 03",
                        style = MaterialTheme.typography.labelSmall,
                        color = KarachiCyan,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Code Inspector Tabs
        item {
            TabRow(
                selectedTabIndex = selectedCodeTab,
                containerColor = KarachiSurface,
                contentColor = KarachiGold,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedCodeTab]),
                        color = KarachiGold
                    )
                }
            ) {
                codeSnippets.forEachIndexed { index, pair ->
                    Tab(
                        selected = selectedCodeTab == index,
                        onClick = { selectedCodeTab = index },
                        text = { Text(pair.first, fontSize = 10.sp, fontFamily = FontFamily.Monospace) }
                    )
                }
            }
        }

        // Code Display Card
        item {
            val currentCode = codeSnippets[selectedCodeTab].second
            val currentTitle = codeSnippets[selectedCodeTab].first

            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF06090F)),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = currentTitle,
                            style = MaterialTheme.typography.labelSmall,
                            color = KarachiCyan,
                            fontFamily = FontFamily.Monospace
                        )
                        IconButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("UE5 Combat Code", currentCode)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(context, "Copied $currentTitle to clipboard", Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Code", tint = KarachiGold, modifier = Modifier.size(18.dp))
                        }
                    }
                    Divider(color = KarachiBorder.copy(alpha = 0.5f), modifier = Modifier.padding(vertical = 6.dp))

                    val horizontalScrollState = rememberScrollState()
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                            .horizontalScroll(horizontalScrollState)
                    ) {
                        Text(
                            text = currentCode,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = TextPrimary,
                            lineHeight = 15.sp
                        )
                    }
                }
            }
        }

        // Master Build Prompt 03 Deliverables Audit
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "PROMPT 03 FINAL ACCEPTANCE AUDIT & VERIFICATION",
                        style = MaterialTheme.typography.titleSmall,
                        color = KarachiGold,
                        fontWeight = FontWeight.Bold
                    )

                    AuditItem("1. Weapons Actually Implemented", "16 fictional weapons covering Pistols (PK-9 Viper, Indus P-17, Magnum .44), SMGs (Lyari Striker, MP-Tac), Assault Rifles (Bolan AK-74, M4, TAR-21), Shotguns (Shera 12G, Riot-12), Marksman/Snipers (.308 Hunter, Falcon .50), RPG-X, and Melee weapons.")
                    AuditItem("2. Combat Framework Implemented", "Hip Fire, Shoulder Aim, and ADS (Aim Down Sights), vertical/horizontal recoil bloom, HitZone multipliers (Headshot 2.5x critical, Torso 1.0x, Limbs 0.75x/0.6x), and multi-surface impact particles (Concrete, Metal, Glass, Wood, Dirt, Water).")
                    AuditItem("3. Stealth & Cover Systems", "Player stances (Standing, Crouch, Low Cover, High Cover, Sprint) with dynamic stealth awareness states (Hidden, Suspicious, Detected, Searching, Alert, Combat), and silent takedowns.")
                    AuditItem("4. Five-Star Wanted System", "Escalation levels (⭐ Level 1 Local Response to ⭐⭐⭐⭐⭐ Level 5 Maximum Response), police units (Foot Officers, Cruisers, Interceptor Bikes, SWAT Vans, Air-Overwatch Helicopter).")
                    AuditItem("5. Police Memory (Last Known Position)", "Last Known Position (LKP) marker tracking, dynamic search zone expansion, and evasion cooldown decay.")
                    AuditItem("6. Police Dispatch & Tactical Radio", "Fictional police radio communications and dispatch transmissions broadcasted across high-priority frequencies.")
                    AuditItem("7. Vehicle Combat Integration", "Police patrol vehicles, pursuit interceptors, and air support helicopters integrated from Prompt 02's vehicle framework.")
                    AuditItem("8. Save System Persistence", "Persistent Room Database (saved_weapons table) tracking owned weapons, equipped slots, ammunition states, and attachments.")
                    AuditItem("9. Known Limitations", "[NOT IMPLEMENTED] Desktop native Chaos PhysX ragdoll solver (requires desktop UE5.4 runtime); [NOT IMPLEMENTED] Hardware motion capture stunt performance rigs.")
                    AuditItem("10. Reserved for Prompt 04+", "[NOT IMPLEMENTED] Full character animation blueprints and 3-way protagonist live hot-switching (Prompt 04); [NOT IMPLEMENTED] 30 Handcrafted Story Missions (Prompt 05).")
                }
            }
        }
    }
}

@Composable
private fun AuditItem(title: String, description: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Text(title, style = MaterialTheme.typography.labelSmall, color = KarachiCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        Text(description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp, lineHeight = 16.sp)
    }
}
