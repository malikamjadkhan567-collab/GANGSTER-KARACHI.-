package com.example.ui.character

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PlayableCharacterData
import com.example.data.model.ProtagonistRelationship
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun CharacterRelationshipsView(
    viewModel: WorldViewModel,
    activeCharacter: PlayableCharacterData,
    modifier: Modifier = Modifier
) {
    val themeColor = Color(activeCharacter.themeColorHex)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "PROTAGONIST DYNAMICS & FACTION AFFINITY",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Dynamic Relationship Matrix for ${activeCharacter.fullName}",
                        style = MaterialTheme.typography.labelSmall,
                        color = themeColor
                    )
                }
            }
        }

        // Relationship Cards
        items(activeCharacter.relationships) { rel ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = rel.targetName,
                                style = MaterialTheme.typography.titleSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "STATUS: ${rel.relationshipStatus.uppercase()}",
                                style = MaterialTheme.typography.labelSmall,
                                color = KarachiGold,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 9.sp
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = if (rel.hostilityScore > 30) KarachiCrimson.copy(alpha = 0.2f) else KarachiCyan.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, if (rel.hostilityScore > 30) KarachiCrimson else KarachiCyan)
                        ) {
                            Text(
                                text = if (rel.hostilityScore > 30) "CAUTIOUS" else "ALIGNED",
                                color = if (rel.hostilityScore > 30) KarachiCrimson else KarachiCyan,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = rel.narrativeNotes,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Metrics
                    RelationshipMeterRow("TRUST SCORE", rel.trustScore, KarachiCyan)
                    RelationshipMeterRow("RESPECT SCORE", rel.respectScore, KarachiGold)
                    RelationshipMeterRow("LOYALTY SCORE", rel.loyaltyScore, Color(0xFF10B981))
                    RelationshipMeterRow("HOSTILITY INDEX", rel.hostilityScore, KarachiCrimson)
                }
            }
        }

        // Narrative Foundation for Prompt 05
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = KarachiSurface),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Icon(Icons.Default.AutoStories, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(16.dp))
                        Text("MASTER PROMPT 05 STORY FOUNDATION READY", color = KarachiGold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                    Text(
                        text = "Relationship values dynamically modulate contact phone calls, heist cuts, faction backup response, and narrative branches in Master Prompt 05.",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun RelationshipMeterRow(label: String, value: Int, color: Color) {
    Column(modifier = Modifier.padding(vertical = 3.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(label, fontSize = 9.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Text("$value / 100", fontSize = 10.sp, color = color, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
        }
        Spacer(modifier = Modifier.height(3.dp))
        LinearProgressIndicator(
            progress = { (value / 100f).coerceIn(0f, 1f) },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = color,
            trackColor = KarachiObsidian
        )
    }
}
