package com.example.ui.character

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.CustomOutfitEntity
import com.example.data.model.*
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun WardrobeStudioView(
    viewModel: WorldViewModel,
    activeCharacter: PlayableCharacterData,
    customOutfits: List<CustomOutfitEntity>,
    modifier: Modifier = Modifier
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Wardrobe Slots, 1: Preset Outfits, 2: Saved Custom (1-5)
    var selectedSlot by remember { mutableStateOf(ClothingSlot.UPPER_BODY) }
    var saveDialogVisible by remember { mutableStateOf(false) }
    var newOutfitName by remember { mutableStateOf("") }
    var newOutfitCategory by remember { mutableStateOf(OutfitCategory.STREET) }

    val themeColor = Color(activeCharacter.themeColorHex)
    val availableItems = remember(selectedSlot) {
        viewModel.getClothingItemsForSlot(selectedSlot)
    }

    Box(modifier = modifier.fillMaxSize().background(KarachiObsidian)) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Header Bar
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = KarachiDarkNavy,
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "KARACHI CUSTOMS WARDROBE",
                                style = MaterialTheme.typography.titleMedium,
                                color = KarachiGold,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            )
                            Text(
                                text = "${activeCharacter.fullName.uppercase()} • ${activeCharacter.safehouseName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = themeColor
                            )
                        }

                        Button(
                            onClick = { saveDialogVisible = true },
                            colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.testTag("save_outfit_button")
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SAVE OUTFIT", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Wardrobe Navigation Tabs
                    TabRow(
                        selectedTabIndex = selectedTab,
                        containerColor = KarachiObsidian,
                        contentColor = KarachiGold,
                        divider = {},
                        indicator = {}
                    ) {
                        Tab(
                            selected = selectedTab == 0,
                            onClick = { selectedTab = 0 },
                            text = { Text("SLOT PIECES", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTab == 1,
                            onClick = { selectedTab = 1 },
                            text = { Text("PRESET STYLES", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                        Tab(
                            selected = selectedTab == 2,
                            onClick = { selectedTab = 2 },
                            text = { Text("SAVED SLOTS", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        )
                    }
                }
            }

            // Body Area
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Current Equipped Outfit Showcase Card
                item {
                    EquippedOutfitCard(character = activeCharacter)
                }

                when (selectedTab) {
                    0 -> {
                        // Slot Category Selector
                        item {
                            Text("SELECT CLOTHING SLOT", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(ClothingSlot.values()) { slot ->
                                    val isSelected = slot == selectedSlot
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = if (isSelected) themeColor else KarachiSurface,
                                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) themeColor else KarachiBorder),
                                        modifier = Modifier.clickable { selectedSlot = slot }.testTag("slot_tab_${slot.name}")
                                    ) {
                                        Text(
                                            text = slot.displayName,
                                            color = if (isSelected) Color.Black else TextPrimary,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            fontSize = 11.sp,
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                        )
                                    }
                                }
                            }
                        }

                        // Clothing Items in Selected Slot
                        items(availableItems) { item ->
                            val isEquipped = when (item.slot) {
                                ClothingSlot.UPPER_BODY -> activeCharacter.activeOutfit.upperBody.id == item.id
                                ClothingSlot.LOWER_BODY -> activeCharacter.activeOutfit.lowerBody.id == item.id
                                ClothingSlot.FOOTWEAR -> activeCharacter.activeOutfit.footwear.id == item.id
                                ClothingSlot.HEADWEAR -> activeCharacter.activeOutfit.headwear?.id == item.id
                                ClothingSlot.EYEWEAR -> activeCharacter.activeOutfit.eyewear?.id == item.id
                                ClothingSlot.WRISTWEAR -> activeCharacter.activeOutfit.wristwear?.id == item.id
                                ClothingSlot.ACCESSORY -> activeCharacter.activeOutfit.accessory?.id == item.id
                            }

                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("clothing_item_${item.id}")
                                    .clickable {
                                        viewModel.equipClothingItem(item)
                                    },
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isEquipped) KarachiSurface else KarachiDarkNavy
                                ),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isEquipped) themeColor else KarachiBorder
                                ),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(14.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                                ) {
                                    // Color swatch box
                                    Box(
                                        modifier = Modifier
                                            .size(42.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(item.primaryColorHex))
                                            .border(1.dp, KarachiBorder, RoundedCornerShape(8.dp))
                                    )

                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = item.name,
                                                style = MaterialTheme.typography.bodyMedium,
                                                color = TextPrimary,
                                                fontWeight = FontWeight.Bold
                                            )
                                            if (item.armorBonus > 0f) {
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = KarachiCrimson.copy(alpha = 0.2f),
                                                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiCrimson)
                                                ) {
                                                    Text(
                                                        "+${item.armorBonus.toInt()} ARMOR",
                                                        color = KarachiCrimson,
                                                        fontSize = 8.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Text(
                                            text = item.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondary,
                                            fontSize = 11.sp
                                        )

                                        Spacer(modifier = Modifier.height(4.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = "₨ ${item.pricePkr}",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = KarachiGold,
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = item.category.displayName,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = TextMuted,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }

                                    if (isEquipped) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = "Equipped",
                                            tint = themeColor,
                                            modifier = Modifier.size(24.dp)
                                        )
                                    } else {
                                        FilledTonalButton(
                                            onClick = { viewModel.equipClothingItem(item) },
                                            colors = ButtonDefaults.filledTonalButtonColors(containerColor = KarachiSurface),
                                            shape = RoundedCornerShape(6.dp),
                                            modifier = Modifier.testTag("equip_item_${item.id}_button")
                                        ) {
                                            Text("EQUIP", fontSize = 10.sp, color = TextPrimary)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    1 -> {
                        // Presets
                        item {
                            Text("DEFAULT CHARACTER PRESETS", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }

                        val defaultPresets = viewModel.getDefaultPresetsForProtagonist(activeCharacter.id)
                        items(defaultPresets) { preset ->
                            Card(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("preset_outfit_${preset.id}")
                                    .clickable { viewModel.equipOutfitPreset(preset) },
                                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(preset.name, style = MaterialTheme.typography.titleSmall, color = TextPrimary, fontWeight = FontWeight.Bold)
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = themeColor.copy(alpha = 0.2f),
                                            border = androidx.compose.foundation.BorderStroke(1.dp, themeColor)
                                        ) {
                                            Text(preset.category.displayName, color = themeColor, fontSize = 8.5.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Text("• Top: ${preset.upperBody.name}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                                    Text("• Bottom: ${preset.lowerBody.name}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                                    Text("• Shoes: ${preset.footwear.name}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
                                    preset.headwear?.let { Text("• Head: ${it.name}", style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp) }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = { viewModel.equipOutfitPreset(preset) },
                                        modifier = Modifier.fillMaxWidth().testTag("apply_preset_${preset.id}_button"),
                                        colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text("APPLY COMPLETE OUTFIT", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                                    }
                                }
                            }
                        }
                    }

                    2 -> {
                        // Saved Custom Outfits (Outfit 01-05)
                        item {
                            Text("PERSISTENT ROOM SAVED OUTFITS", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        }

                        if (customOutfits.isEmpty()) {
                            item {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    color = KarachiDarkNavy,
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
                                ) {
                                    Column(
                                        modifier = Modifier.padding(24.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Icon(Icons.Default.Checkroom, contentDescription = null, tint = TextMuted, modifier = Modifier.size(36.dp))
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text("No custom outfits saved yet.", color = TextSecondary, fontSize = 12.sp)
                                        Text("Mix pieces from 'Slot Pieces' and click 'SAVE OUTFIT' above.", color = TextMuted, fontSize = 10.sp)
                                    }
                                }
                            }
                        } else {
                            items(customOutfits) { saved ->
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(saved.outfitName, style = MaterialTheme.typography.titleSmall, color = KarachiGold, fontWeight = FontWeight.Bold)
                                            Text("Category: ${saved.outfitCategory}", color = TextSecondary, fontSize = 10.sp)
                                        }

                                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                            Button(
                                                onClick = { viewModel.loadCustomOutfitFromEntity(saved) },
                                                colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                                                shape = RoundedCornerShape(6.dp)
                                            ) {
                                                Text("EQUIP", color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                            }
                                            IconButton(
                                                onClick = { viewModel.deleteCustomOutfit(saved.id) }
                                            ) {
                                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = KarachiCrimson)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Save Outfit Dialog
        if (saveDialogVisible) {
            AlertDialog(
                onDismissRequest = { saveDialogVisible = false },
                containerColor = KarachiDarkNavy,
                title = { Text("SAVE CUSTOM OUTFIT", color = KarachiGold, fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("Enter a unique name for this outfit preset:", color = TextSecondary, fontSize = 12.sp)
                        OutlinedTextField(
                            value = newOutfitName,
                            onValueChange = { newOutfitName = it },
                            placeholder = { Text("e.g. Midnight Heist") },
                            modifier = Modifier.fillMaxWidth().testTag("outfit_name_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = themeColor,
                                unfocusedBorderColor = KarachiBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (newOutfitName.isNotBlank()) {
                                viewModel.saveCurrentOutfit(newOutfitName, newOutfitCategory)
                                saveDialogVisible = false
                                newOutfitName = ""
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = themeColor),
                        modifier = Modifier.testTag("confirm_save_outfit_button")
                    ) {
                        Text("SAVE TO DATABASE", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { saveDialogVisible = false }) {
                        Text("CANCEL", color = TextMuted)
                    }
                }
            )
        }
    }
}

@Composable
private fun EquippedOutfitCard(character: PlayableCharacterData) {
    val outfit = character.activeOutfit
    val themeColor = Color(character.themeColorHex)

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = KarachiSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, themeColor),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("ACTIVE WARDROBE PROFILE", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                    Text(outfit.name, style = MaterialTheme.typography.titleMedium, color = TextPrimary, fontWeight = FontWeight.Bold)
                }
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = themeColor.copy(alpha = 0.2f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, themeColor)
                ) {
                    Text(
                        outfit.category.displayName.uppercase(),
                        color = themeColor,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Equipped slots grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                EquippedSlotItem(label = "UPPER", name = outfit.upperBody.name, color = Color(outfit.upperBody.primaryColorHex))
                EquippedSlotItem(label = "LOWER", name = outfit.lowerBody.name, color = Color(outfit.lowerBody.primaryColorHex))
                EquippedSlotItem(label = "FEET", name = outfit.footwear.name, color = Color(outfit.footwear.primaryColorHex))
                EquippedSlotItem(label = "HEAD", name = outfit.headwear?.name ?: "None", color = outfit.headwear?.let { Color(it.primaryColorHex) } ?: TextMuted)
            }
        }
    }
}

@Composable
private fun EquippedSlotItem(label: String, name: String, color: Color) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = KarachiObsidian,
        border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
        modifier = Modifier.width(76.dp)
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(16.dp)
                    .clip(RoundedCornerShape(3.dp))
                    .background(color)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(label, fontSize = 7.5.sp, color = TextMuted, fontWeight = FontWeight.Bold)
            Text(name, fontSize = 8.sp, color = TextPrimary, maxLines = 1)
        }
    }
}
