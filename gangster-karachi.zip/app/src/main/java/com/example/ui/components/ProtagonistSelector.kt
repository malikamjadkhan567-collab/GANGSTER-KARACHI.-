package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Protagonist
import com.example.ui.theme.*

@Composable
fun ProtagonistSelector(
    protagonists: List<Protagonist>,
    activeProtagonist: Protagonist,
    onSelectProtagonist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp)
            .testTag("protagonist_selector_screen"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text(
                text = "PLAYABLE PROTAGONISTS // THREE STARTS",
                style = MaterialTheme.typography.titleMedium,
                color = KarachiGold,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "Each protagonist begins in their unique starting district and safehouse.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }

        items(protagonists.size) { index ->
            val p = protagonists[index]
            val isSelected = p.id == activeProtagonist.id
            val accentColor = Color(p.accentColorHex)

            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) KarachiDarkNavy else KarachiSurface
                ),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) accentColor else KarachiBorder
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelectProtagonist(p.id) }
                    .testTag("protagonist_card_${p.id}")
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(accentColor.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = accentColor)
                            }
                            Column {
                                Text(
                                    text = p.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = p.title,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = accentColor,
                                    fontSize = 11.sp
                                )
                            }
                        }

                        if (isSelected) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = accentColor
                            ) {
                                Text(
                                    text = "ACTIVE",
                                    color = KarachiObsidian,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }

                    Divider(color = KarachiBorder.copy(alpha = 0.5f))

                    Text(
                        text = p.biography,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        lineHeight = 16.sp,
                        fontSize = 11.sp
                    )

                    // Safehouse & District Row
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = KarachiObsidian,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Home, contentDescription = null, tint = KarachiGold, modifier = Modifier.size(14.dp))
                                Text(
                                    text = "Starting Safehouse: ${p.safehouseName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.sp
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Place, contentDescription = null, tint = KarachiCyan, modifier = Modifier.size(14.dp))
                                Text(
                                    text = "Starting District: ${p.startingDistrictName}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = KarachiCyan,
                                    fontSize = 11.sp
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Star, contentDescription = null, tint = KarachiEmerald, modifier = Modifier.size(14.dp))
                                Text(
                                    text = "Specialty: ${p.tacticalSpecialty}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }

                    // Reserved Future System tags
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text(
                            text = p.startingVehicleStatus,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFFFB74D),
                            fontSize = 9.sp
                        )
                        Text(
                            text = p.startingWeaponStatus,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFFEF9A9A),
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }
    }
}
