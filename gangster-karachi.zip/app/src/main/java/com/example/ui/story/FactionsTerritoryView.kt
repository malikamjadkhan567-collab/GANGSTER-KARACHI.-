package com.example.ui.story

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Faction
import com.example.data.model.FactionStanding
import com.example.ui.WorldViewModel
import com.example.ui.theme.*

@Composable
fun FactionsTerritoryView(
    viewModel: WorldViewModel,
    factions: List<Faction>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth().testTag("factions_header_card"),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "KARACHI METRO FACTIONS & UNDERWORLD SYNDICATES",
                        style = MaterialTheme.typography.titleMedium,
                        color = KarachiGold,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = "Dynamic Territory Control • Syndicate Respect Ratings (-100 to +100)",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextMuted
                    )
                }
            }
        }

        // Faction Cards
        items(factions) { faction ->
            val factionColor = Color(faction.colorHex)

            Card(
                modifier = Modifier.fillMaxWidth().testTag("faction_card_${faction.id}"),
                colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
                border = androidx.compose.foundation.BorderStroke(1.dp, factionColor),
                shape = RoundedCornerShape(10.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = factionColor.copy(alpha = 0.2f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, factionColor)
                                ) {
                                    Text(
                                        text = faction.shortCode,
                                        color = factionColor,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 10.sp,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                                Text(
                                    text = faction.name,
                                    style = MaterialTheme.typography.titleSmall,
                                    color = TextPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Text(
                                text = "Leader: ${faction.bossName}",
                                style = MaterialTheme.typography.labelSmall,
                                color = KarachiGold,
                                fontSize = 9.5.sp
                            )
                        }

                        // Standing Badge
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = when (faction.standing) {
                                FactionStanding.HONORED -> Color(0xFF10B981).copy(alpha = 0.2f)
                                FactionStanding.ALLIED -> KarachiCyan.copy(alpha = 0.2f)
                                FactionStanding.NEUTRAL -> TextMuted.copy(alpha = 0.2f)
                                FactionStanding.UNFRIENDLY -> Color(0xFFF97316).copy(alpha = 0.2f)
                                FactionStanding.HOSTILE -> KarachiCrimson.copy(alpha = 0.2f)
                            },
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                when (faction.standing) {
                                    FactionStanding.HONORED -> Color(0xFF10B981)
                                    FactionStanding.ALLIED -> KarachiCyan
                                    FactionStanding.NEUTRAL -> TextMuted
                                    FactionStanding.UNFRIENDLY -> Color(0xFFF97316)
                                    FactionStanding.HOSTILE -> KarachiCrimson
                                }
                            )
                        ) {
                            Text(
                                text = faction.standing.name,
                                color = when (faction.standing) {
                                    FactionStanding.HONORED -> Color(0xFF10B981)
                                    FactionStanding.ALLIED -> KarachiCyan
                                    FactionStanding.NEUTRAL -> TextSecondary
                                    FactionStanding.UNFRIENDLY -> Color(0xFFF97316)
                                    FactionStanding.HOSTILE -> KarachiCrimson
                                },
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = faction.description,
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary,
                        fontSize = 11.5.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Territory & Perk Row
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = KarachiObsidian,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("TERRITORY: ${faction.districtTerritory.uppercase()}", color = KarachiCyan, fontSize = 9.5.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(2.dp))
                            Text("PERK: ${faction.perkDescription}", color = TextPrimary, fontSize = 10.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Reputation Score Gauge (-100 to +100)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("REPUTATION RATING", style = MaterialTheme.typography.labelSmall, color = TextMuted)
                        Text(
                            text = "${if (faction.reputationScore > 0) "+" else ""}${faction.reputationScore} / 100",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (faction.reputationScore >= 0) Color(0xFF10B981) else KarachiCrimson,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    val normalizedScore = ((faction.reputationScore + 100) / 200f).coerceIn(0f, 1f)
                    LinearProgressIndicator(
                        progress = { normalizedScore },
                        modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp)),
                        color = if (faction.reputationScore >= 0) Color(0xFF10B981) else KarachiCrimson,
                        trackColor = KarachiObsidian
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Reputation Adjustment Actions
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.adjustFactionReputation(faction.id, -15) },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.padding(end = 8.dp)
                        ) {
                            Text("-15 HOSTILITY", color = KarachiCrimson, fontSize = 9.sp)
                        }
                        Button(
                            onClick = { viewModel.adjustFactionReputation(faction.id, +15) },
                            colors = ButtonDefaults.buttonColors(containerColor = factionColor),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("+15 RESPECT", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 9.sp)
                        }
                    }
                }
            }
        }
    }
}
