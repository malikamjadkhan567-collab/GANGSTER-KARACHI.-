package com.example.ui.components

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UE5CharacterArchitectureData
import com.example.ui.theme.*

@Composable
fun UE5CharacterArchitectureViewer(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var selectedFileIndex by remember { mutableIntStateOf(0) }

    val fileNames = listOf(
        "KarachiProtagonistCharacter.h",
        "KarachiCharacterSwitchSubsystem.h",
        "WardrobeComponent.h"
    )

    val fileContents = listOf(
        UE5CharacterArchitectureData.karachiCharacterHeader,
        UE5CharacterArchitectureData.characterSwitchSubsystemHeader,
        UE5CharacterArchitectureData.wardrobeComponentHeader
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(KarachiObsidian)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = KarachiDarkNavy),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "UE5 CHARACTER & WARDROBE C++",
                            style = MaterialTheme.typography.titleMedium,
                            color = KarachiGold,
                            fontWeight = FontWeight.ExtraBold,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Protagonist Base • Switch Subsystem • Modular Wardrobe",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted
                        )
                    }

                    IconButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            val clip = ClipData.newPlainText("UE5 Character Architecture", fileContents[selectedFileIndex])
                            clipboard.setPrimaryClip(clip)
                            Toast.makeText(context, "Copied ${fileNames[selectedFileIndex]} to clipboard", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("copy_character_cpp_button")
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy C++ Code", tint = KarachiCyan)
                    }
                }
            }
        }

        // File Selector Tabs
        ScrollableTabRow(
            selectedTabIndex = selectedFileIndex,
            containerColor = KarachiDarkNavy,
            contentColor = KarachiGold,
            edgePadding = 0.dp,
            divider = {}
        ) {
            fileNames.forEachIndexed { index, name ->
                Tab(
                    selected = selectedFileIndex == index,
                    onClick = { selectedFileIndex = index },
                    text = {
                        Text(
                            text = name,
                            fontSize = 11.sp,
                            fontWeight = if (selectedFileIndex == index) FontWeight.Bold else FontWeight.Normal,
                            fontFamily = FontFamily.Monospace,
                            color = if (selectedFileIndex == index) KarachiGold else TextSecondary
                        )
                    }
                )
            }
        }

        // Code Viewer
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f),
            color = Color(0xFF030712),
            shape = RoundedCornerShape(8.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(12.dp)
            ) {
                item {
                    Text(
                        text = fileContents[selectedFileIndex],
                        color = Color(0xFFE2E8F0),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.5.sp,
                        lineHeight = 16.sp,
                        modifier = Modifier.horizontalScroll(rememberScrollState())
                    )
                }
            }
        }
    }
}
