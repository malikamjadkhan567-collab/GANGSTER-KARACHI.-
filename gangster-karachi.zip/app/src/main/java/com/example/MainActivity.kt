package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.LandmarkCategory
import com.example.data.model.TimeOfDay
import com.example.ui.CameraMode
import com.example.ui.ViewLayer
import com.example.ui.WorldViewModel
import com.example.ui.character.*
import com.example.ui.combat.CombatSimulatorView
import com.example.ui.combat.PoliceDispatchView
import com.example.ui.combat.WeaponArmoryView
import com.example.ui.components.*
import com.example.ui.driving.DrivingSimulatorView
import com.example.ui.simulation.*
import com.example.ui.story.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {

    private val viewModel: WorldViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KarachiMetroApp(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KarachiMetroApp(viewModel: WorldViewModel) {
    val context = LocalContext.current
    var currentNavIndex by remember { mutableIntStateOf(0) } // 0: Map, 1: World Sim, 2: Story, 3: Characters, 4: Combat, 5: Vehicles, 6: UE5 C++
    var mapSubTabIndex by remember { mutableIntStateOf(0) } // 0: Map Canvas, 1: Districts
    var worldSubTabIndex by remember { mutableIntStateOf(0) } // 0: Clock/Weather, 1: Pedestrians, 2: Traffic, 3: Wildlife, 4: Events, 5: LOD, 6: Tests
    var storySubTabIndex by remember { mutableIntStateOf(0) } // 0: 30 Missions, 1: 5 Factions, 2: Endings
    var characterSubTabIndex by remember { mutableIntStateOf(0) } // 0: Switcher, 1: Wardrobe, 2: Grooming, 3: Animation, 4: Relationships, 5: Tests
    var combatSubTabIndex by remember { mutableIntStateOf(0) } // 0: Range, 1: Police Wanted, 2: Armory
    var vehicleSubTabIndex by remember { mutableIntStateOf(0) } // 0: Drive Sim, 1: Garage, 2: Fleet
    var ue5SubTabIndex by remember { mutableIntStateOf(5) } // 0: World, 1: Vehicles, 2: Combat, 3: Characters, 4: Story, 5: Simulation
    var showDistrictSheet by remember { mutableStateOf(false) }

    // World States (Prompt 01)
    val selectedDistrict by viewModel.selectedDistrict.collectAsStateWithLifecycle()
    val selectedLandmark by viewModel.selectedLandmark.collectAsStateWithLifecycle()
    val activeProtagonist by viewModel.activeProtagonist.collectAsStateWithLifecycle()
    val timeOfDay by viewModel.timeOfDay.collectAsStateWithLifecycle()
    val viewLayer by viewModel.viewLayer.collectAsStateWithLifecycle()
    val cameraMode by viewModel.cameraMode.collectAsStateWithLifecycle()
    val activeDataLayers by viewModel.activeDataLayers.collectAsStateWithLifecycle()
    val playerPos by viewModel.playerMapPos.collectAsStateWithLifecycle()
    val categoryFilter by viewModel.categoryFilter.collectAsStateWithLifecycle()

    // Vehicle States (Prompt 02)
    val selectedVehicle by viewModel.selectedVehicle.collectAsStateWithLifecycle()
    val garageVehicles by viewModel.garageVehicles.collectAsStateWithLifecycle()
    val drivingState by viewModel.drivingState.collectAsStateWithLifecycle()

    // Combat & Police States (Prompt 03)
    val selectedWeapon by viewModel.selectedWeapon.collectAsStateWithLifecycle()
    val aimState by viewModel.aimState.collectAsStateWithLifecycle()
    val playerStance by viewModel.playerStance.collectAsStateWithLifecycle()
    val stealthState by viewModel.stealthState.collectAsStateWithLifecycle()
    val crosshairSpread by viewModel.crosshairSpread.collectAsStateWithLifecycle()
    val selectedSurface by viewModel.selectedImpactSurface.collectAsStateWithLifecycle()
    val hitFeedback by viewModel.hitFeedback.collectAsStateWithLifecycle()
    val enemyTarget by viewModel.enemyTarget.collectAsStateWithLifecycle()
    val savedWeapons by viewModel.savedWeapons.collectAsStateWithLifecycle()
    val wantedLevel by viewModel.wantedLevel.collectAsStateWithLifecycle()
    val policeSearchPhase by viewModel.policeSearchPhase.collectAsStateWithLifecycle()
    val searchDecayProgress by viewModel.searchDecayProgress.collectAsStateWithLifecycle()
    val policeHeatPercentage by viewModel.policeHeatPercentage.collectAsStateWithLifecycle()
    val activePoliceUnits by viewModel.activePoliceUnits.collectAsStateWithLifecycle()
    val dispatchRadioLogs by viewModel.dispatchRadioLogs.collectAsStateWithLifecycle()

    // Character States (Prompt 04)
    val playableCharacters by viewModel.playableCharacters.collectAsStateWithLifecycle()
    val activeCharacterData by viewModel.activeCharacterData.collectAsStateWithLifecycle()
    val characterSwitchMode by viewModel.characterSwitchMode.collectAsStateWithLifecycle()
    val switchTransitionState by viewModel.switchTransitionState.collectAsStateWithLifecycle()
    val currentLocomotionMode by viewModel.currentLocomotionMode.collectAsStateWithLifecycle()
    val customOutfits by viewModel.customOutfits.collectAsStateWithLifecycle()
    val acceptanceTestLogs by viewModel.acceptanceTestLogs.collectAsStateWithLifecycle()
    val isTestingRunning by viewModel.isTestingRunning.collectAsStateWithLifecycle()

    // Story & Faction States (Prompt 05)
    val storyMissions by viewModel.storyMissions.collectAsStateWithLifecycle()
    val activeMission by viewModel.activeMission.collectAsStateWithLifecycle()
    val factions by viewModel.factions.collectAsStateWithLifecycle()

    // World Simulation States (Prompt 06)
    val gameClock by viewModel.gameClock.collectAsStateWithLifecycle()
    val environmentSnapshot by viewModel.environmentSnapshot.collectAsStateWithLifecycle()
    val pedestriansList by viewModel.pedestriansList.collectAsStateWithLifecycle()
    val trafficVehiclesList by viewModel.trafficVehiclesList.collectAsStateWithLifecycle()
    val wildlifeList by viewModel.wildlifeList.collectAsStateWithLifecycle()
    val dynamicWorldEvents by viewModel.dynamicWorldEvents.collectAsStateWithLifecycle()
    val simulationLODMetrics by viewModel.simulationLODMetrics.collectAsStateWithLifecycle()
    val trafficLightState by viewModel.trafficLightState.collectAsStateWithLifecycle()
    val selectedGraphicsPreset by viewModel.selectedGraphicsPreset.collectAsStateWithLifecycle()
    val simTestResults by viewModel.simTestResults.collectAsStateWithLifecycle()
    val isSimTestRunning by viewModel.isSimTestRunning.collectAsStateWithLifecycle()
    val simFeedbackMessage by viewModel.simFeedbackMessage.collectAsStateWithLifecycle()

    // Handle back button on sub-screens
    BackHandler(enabled = currentNavIndex != 0) {
        currentNavIndex = 0
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(KarachiObsidian),
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "GANGSTER KARACHI",
                                style = MaterialTheme.typography.titleMedium,
                                color = KarachiGold,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.sp
                            )
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (wantedLevel.stars > 0) KarachiCrimson.copy(alpha = 0.2f) else KarachiCyan.copy(alpha = 0.2f),
                                border = androidx.compose.foundation.BorderStroke(1.dp, if (wantedLevel.stars > 0) KarachiCrimson else KarachiCyan)
                            ) {
                                Text(
                                    text = if (wantedLevel.stars > 0) "★ ${wantedLevel.stars} WANTED" else "NEXT GEN",
                                    color = if (wantedLevel.stars > 0) KarachiCrimson else KarachiCyan,
                                    fontSize = 8.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "STORY • CHARACTERS • COMBAT • VEHICLES • WORLD",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextMuted,
                            fontSize = 8.sp
                        )
                    }
                },
                actions = {
                    // Quick Save Button
                    IconButton(
                        onClick = {
                            viewModel.saveGameState()
                            Toast.makeText(context, "Game state saved to Room Database", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("quick_save_icon_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Quick Save", tint = KarachiGold)
                    }

                    // Protagonist Quick Switcher Chip
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = KarachiSurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(activeCharacterData.themeColorHex)),
                        modifier = Modifier
                            .padding(end = 6.dp)
                            .clickable {
                                val currentIndex = playableCharacters.indexOfFirst { it.id == activeCharacterData.id }
                                val nextChar = playableCharacters[(currentIndex + 1) % playableCharacters.size]
                                viewModel.switchProtagonist(nextChar.id)
                            }
                            .testTag("topbar_protagonist_chip")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                Icons.Default.Person,
                                contentDescription = null,
                                tint = Color(activeCharacterData.themeColorHex),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = activeCharacterData.fullName.split(" ")[0].uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                color = TextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        }
                    }

                    // Cycle Time of Day Button
                    IconButton(
                        onClick = {
                            val nextTod = when (timeOfDay) {
                                TimeOfDay.DAWN -> TimeOfDay.NOON
                                TimeOfDay.NOON -> TimeOfDay.GOLDEN_HOUR
                                TimeOfDay.GOLDEN_HOUR -> TimeOfDay.TWILIGHT
                                TimeOfDay.TWILIGHT -> TimeOfDay.MIDNIGHT
                                TimeOfDay.MIDNIGHT -> TimeOfDay.DAWN
                            }
                            viewModel.setTimeOfDay(nextTod)
                        },
                        modifier = Modifier.testTag("cycle_tod_button")
                    ) {
                        val icon = when (timeOfDay) {
                            TimeOfDay.DAWN -> Icons.Default.WbTwilight
                            TimeOfDay.NOON -> Icons.Default.WbSunny
                            TimeOfDay.GOLDEN_HOUR -> Icons.Default.BrightnessMedium
                            TimeOfDay.TWILIGHT -> Icons.Default.NightsStay
                            TimeOfDay.MIDNIGHT -> Icons.Default.Bedtime
                        }
                        Icon(icon, contentDescription = "Cycle Time of Day", tint = KarachiGold)
                    }

                    // Layer Switcher Menu
                    var showLayerMenu by remember { mutableStateOf(false) }
                    Box {
                        IconButton(
                            onClick = { showLayerMenu = true },
                            modifier = Modifier.testTag("layer_menu_button")
                        ) {
                            Icon(Icons.Default.Layers, contentDescription = "Layers", tint = KarachiCyan)
                        }
                        DropdownMenu(
                            expanded = showLayerMenu,
                            onDismissRequest = { showLayerMenu = false },
                            modifier = Modifier.background(KarachiDarkNavy)
                        ) {
                            ViewLayer.values().forEach { layer ->
                                DropdownMenuItem(
                                    text = {
                                        Text(
                                            layer.title,
                                            color = if (layer == viewLayer) KarachiGold else TextPrimary,
                                            fontWeight = if (layer == viewLayer) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    onClick = {
                                        viewModel.setViewLayer(layer)
                                        showLayerMenu = false
                                    }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = KarachiObsidian,
                    titleContentColor = TextPrimary
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = KarachiDarkNavy,
                contentColor = KarachiGold,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("main_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = currentNavIndex == 0,
                    onClick = { currentNavIndex = 0 },
                    icon = { Icon(Icons.Default.Map, contentDescription = "Map") },
                    label = { Text("Map", fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarachiObsidian,
                        selectedTextColor = KarachiGold,
                        indicatorColor = KarachiGold,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = currentNavIndex == 1,
                    onClick = { currentNavIndex = 1 },
                    icon = { Icon(Icons.Default.AutoStories, contentDescription = "Story") },
                    label = { Text("Story", fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarachiObsidian,
                        selectedTextColor = KarachiGold,
                        indicatorColor = KarachiGold,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = currentNavIndex == 2,
                    onClick = { currentNavIndex = 2 },
                    icon = { Icon(Icons.Default.AccountCircle, contentDescription = "Characters") },
                    label = { Text("Characters", fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarachiObsidian,
                        selectedTextColor = KarachiGold,
                        indicatorColor = KarachiGold,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = currentNavIndex == 3,
                    onClick = { currentNavIndex = 3 },
                    icon = { Icon(Icons.Default.Adjust, contentDescription = "Combat") },
                    label = { Text("Combat", fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarachiObsidian,
                        selectedTextColor = KarachiGold,
                        indicatorColor = KarachiGold,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = currentNavIndex == 4,
                    onClick = { currentNavIndex = 4 },
                    icon = { Icon(Icons.Default.DriveEta, contentDescription = "Vehicles") },
                    label = { Text("Vehicles", fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarachiObsidian,
                        selectedTextColor = KarachiGold,
                        indicatorColor = KarachiGold,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
                NavigationBarItem(
                    selected = currentNavIndex == 5,
                    onClick = { currentNavIndex = 5 },
                    icon = { Icon(Icons.Default.Code, contentDescription = "UE5 C++") },
                    label = { Text("UE5 C++", fontSize = 9.sp) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = KarachiObsidian,
                        selectedTextColor = KarachiGold,
                        indicatorColor = KarachiGold,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    )
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentNavIndex) {
                0 -> {
                    // TAB 0: Open-World Map Engine (Prompt 01)
                    Column(modifier = Modifier.fillMaxSize()) {
                        TabRow(
                            selectedTabIndex = mapSubTabIndex,
                            containerColor = KarachiDarkNavy,
                            contentColor = KarachiGold
                        ) {
                            Tab(
                                selected = mapSubTabIndex == 0,
                                onClick = { mapSubTabIndex = 0 },
                                text = { Text("Canvas Map & Partition", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = mapSubTabIndex == 1,
                                onClick = { mapSubTabIndex = 1 },
                                text = { Text("15 Districts Directory", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                            )
                        }

                        if (mapSubTabIndex == 0) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(KarachiObsidian)
                                    .padding(horizontal = 12.dp, vertical = 6.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                FilterChip(
                                    selected = categoryFilter == null,
                                    onClick = { viewModel.setCategoryFilter(null) },
                                    label = { Text("All Pins", fontSize = 10.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = KarachiGold,
                                        selectedLabelColor = KarachiObsidian
                                    )
                                )
                                LandmarkCategory.values().forEach { cat ->
                                    FilterChip(
                                        selected = categoryFilter == cat,
                                        onClick = {
                                            viewModel.setCategoryFilter(if (categoryFilter == cat) null else cat)
                                        },
                                        label = { Text(cat.title.split(" ")[0], fontSize = 10.sp) },
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = KarachiCyan,
                                            selectedLabelColor = KarachiObsidian
                                        )
                                    )
                                }
                            }

                            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                                KarachiMapCanvas(
                                    districts = viewModel.districts,
                                    landmarks = viewModel.landmarks,
                                    selectedDistrict = selectedDistrict,
                                    selectedLandmark = selectedLandmark,
                                    activeProtagonist = activeProtagonist,
                                    playerPos = playerPos,
                                    timeOfDay = timeOfDay,
                                    viewLayer = viewLayer,
                                    cameraMode = cameraMode,
                                    activeDataLayers = activeDataLayers,
                                    categoryFilter = categoryFilter,
                                    onDistrictClick = { district ->
                                        viewModel.selectDistrict(district.id)
                                        showDistrictSheet = true
                                    },
                                    onLandmarkClick = { landmark ->
                                        viewModel.selectLandmark(landmark)
                                        showDistrictSheet = true
                                    },
                                    onMapTap = { normX, normY ->
                                        viewModel.setPlayerPos(normX, normY)
                                    }
                                )

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = KarachiDarkNavy.copy(alpha = 0.90f),
                                    border = androidx.compose.foundation.BorderStroke(1.dp, KarachiBorder),
                                    modifier = Modifier
                                        .align(Alignment.TopCenter)
                                        .padding(top = 10.dp)
                                        .clickable { showDistrictSheet = true }
                                        .testTag("district_quick_banner")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(10.dp)
                                                .clip(RoundedCornerShape(2.dp))
                                                .background(Color(selectedDistrict.colorHex))
                                        )
                                        Text(
                                            text = selectedDistrict.name.uppercase(),
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimary,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                        Text(
                                            text = "• ${selectedDistrict.biome.displayName.split(" ")[0]}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = KarachiCyan,
                                            fontSize = 11.sp
                                        )
                                        Icon(Icons.Default.Info, contentDescription = "Details", tint = KarachiGold, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }

                            if (showDistrictSheet) {
                                DistrictDetailSheet(
                                    district = selectedDistrict,
                                    landmarks = viewModel.getLandmarksByDistrict(selectedDistrict.id),
                                    activeProtagonist = activeProtagonist,
                                    onFastTravel = {
                                        viewModel.setPlayerPos(selectedDistrict.mapCoordsX, selectedDistrict.mapCoordsY)
                                        showDistrictSheet = false
                                    },
                                    onAddWaypoint = { title, note ->
                                        viewModel.addCustomMarker(
                                            title = title,
                                            note = note,
                                            x = selectedDistrict.mapCoordsX,
                                            y = selectedDistrict.mapCoordsY,
                                            districtName = selectedDistrict.name
                                        )
                                    },
                                    onSelectLandmark = { lm ->
                                        viewModel.selectLandmark(lm)
                                    },
                                    onDismiss = { showDistrictSheet = false }
                                )
                            }
                        } else {
                            DistrictsListView(
                                districts = viewModel.districts,
                                selectedDistrict = selectedDistrict,
                                onSelectDistrict = { d ->
                                    viewModel.selectDistrict(d.id)
                                    mapSubTabIndex = 0
                                    showDistrictSheet = true
                                }
                            )
                        }
                    }
                }

                1 -> {
                    // TAB 1: STORY MISSIONS, FACTIONS & CLIMACTIC ENDINGS (Prompt 05)
                    if (activeMission != null) {
                        ActiveMissionPlayerView(
                            viewModel = viewModel,
                            mission = activeMission!!,
                            onBackToList = { viewModel.clearActiveMission() }
                        )
                    } else {
                        Column(modifier = Modifier.fillMaxSize()) {
                            TabRow(
                                selectedTabIndex = storySubTabIndex,
                                containerColor = KarachiDarkNavy,
                                contentColor = KarachiGold
                            ) {
                                Tab(
                                    selected = storySubTabIndex == 0,
                                    onClick = { storySubTabIndex = 0 },
                                    text = { Text("30 Missions", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                )
                                Tab(
                                    selected = storySubTabIndex == 1,
                                    onClick = { storySubTabIndex = 1 },
                                    text = { Text("5 Factions", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                )
                                Tab(
                                    selected = storySubTabIndex == 2,
                                    onClick = { storySubTabIndex = 2 },
                                    text = { Text("Endings", fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                                )
                            }

                            when (storySubTabIndex) {
                                0 -> {
                                    StoryMissionsListView(
                                        viewModel = viewModel,
                                        missions = storyMissions,
                                        activeMission = activeMission,
                                        onSelectMission = { mission ->
                                            viewModel.selectStoryMission(mission)
                                        }
                                    )
                                }
                                1 -> {
                                    FactionsTerritoryView(
                                        viewModel = viewModel,
                                        factions = factions
                                    )
                                }
                                2 -> {
                                    BranchingEndingsView(
                                        viewModel = viewModel
                                    )
                                }
                            }
                        }
                    }
                }

                2 -> {
                    // TAB 2: THREE PLAYABLE PROTAGONISTS, WARDROBE & ANIMATION (Prompt 04)
                    Column(modifier = Modifier.fillMaxSize()) {
                        ScrollableTabRow(
                            selectedTabIndex = characterSubTabIndex,
                            containerColor = KarachiDarkNavy,
                            contentColor = KarachiGold,
                            edgePadding = 8.dp,
                            divider = {}
                        ) {
                            Tab(
                                selected = characterSubTabIndex == 0,
                                onClick = { characterSubTabIndex = 0 },
                                text = { Text("PROTAGONISTS", fontSize = 10.5.sp, fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = characterSubTabIndex == 1,
                                onClick = { characterSubTabIndex = 1 },
                                text = { Text("WARDROBE", fontSize = 10.5.sp, fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = characterSubTabIndex == 2,
                                onClick = { characterSubTabIndex = 2 },
                                text = { Text("GROOMING", fontSize = 10.5.sp, fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = characterSubTabIndex == 3,
                                onClick = { characterSubTabIndex = 3 },
                                text = { Text("ANIMATION", fontSize = 10.5.sp, fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = characterSubTabIndex == 4,
                                onClick = { characterSubTabIndex = 4 },
                                text = { Text("RELATIONSHIPS", fontSize = 10.5.sp, fontWeight = FontWeight.Bold) }
                            )
                            Tab(
                                selected = characterSubTabIndex == 5,
                                onClick = { characterSubTabIndex = 5 },
                                text = { Text("15 ACCEPTANCE TESTS", fontSize = 10.5.sp, fontWeight = FontWeight.Bold, color = KarachiCyan) }
                            )
                        }

                        when (characterSubTabIndex) {
                            0 -> {
                                CharacterSwitcherView(
                                    viewModel = viewModel,
                                    characters = playableCharacters,
                                    activeCharacter = activeCharacterData,
                                    switchMode = characterSwitchMode,
                                    transitionState = switchTransitionState,
                                    onSwitchRequested = { targetId ->
                                        viewModel.switchProtagonist(targetId)
                                    }
                                )
                            }
                            1 -> {
                                WardrobeStudioView(
                                    viewModel = viewModel,
                                    activeCharacter = activeCharacterData,
                                    customOutfits = customOutfits
                                )
                            }
                            2 -> {
                                AppearanceCustomizerView(
                                    viewModel = viewModel,
                                    activeCharacter = activeCharacterData
                                )
                            }
                            3 -> {
                                CharacterAnimationView(
                                    viewModel = viewModel,
                                    activeCharacter = activeCharacterData,
                                    currentLocomotionMode = currentLocomotionMode
                                )
                            }
                            4 -> {
                                CharacterRelationshipsView(
                                    viewModel = viewModel,
                                    activeCharacter = activeCharacterData
                                )
                            }
                            5 -> {
                                AcceptanceTestRunnerView(
                                    viewModel = viewModel,
                                    testLogs = acceptanceTestLogs,
                                    isRunning = isTestingRunning
                                )
                            }
                        }
                    }
                }

                3 -> {
                    // TAB 3: COMBAT, WEAPONS & POLICE WANTED (Prompt 03)
                    Column(modifier = Modifier.fillMaxSize()) {
                        TabRow(
                            selectedTabIndex = combatSubTabIndex,
                            containerColor = KarachiDarkNavy,
                            contentColor = KarachiGold
                        ) {
                            Tab(
                                selected = combatSubTabIndex == 0,
                                onClick = { combatSubTabIndex = 0 },
                                text = { Text("Shooting Range", fontSize = 11.sp) }
                            )
                            Tab(
                                selected = combatSubTabIndex == 1,
                                onClick = { combatSubTabIndex = 1 },
                                text = {
                                    Text(
                                        text = if (wantedLevel.stars > 0) "Police (★${wantedLevel.stars})" else "Police Wanted",
                                        color = if (wantedLevel.stars > 0) KarachiCrimson else TextPrimary,
                                        fontSize = 11.sp
                                    )
                                }
                            )
                            Tab(
                                selected = combatSubTabIndex == 2,
                                onClick = { combatSubTabIndex = 2 },
                                text = { Text("Armory Fleet", fontSize = 11.sp) }
                            )
                        }

                        when (combatSubTabIndex) {
                            0 -> {
                                CombatSimulatorView(
                                    selectedWeapon = selectedWeapon,
                                    aimState = aimState,
                                    playerStance = playerStance,
                                    stealthState = stealthState,
                                    crosshairSpread = crosshairSpread,
                                    selectedSurface = selectedSurface,
                                    hitFeedback = hitFeedback,
                                    enemyTarget = enemyTarget,
                                    onFireWeapon = { viewModel.fireWeapon() },
                                    onReloadWeapon = { viewModel.reloadWeapon() },
                                    onAimStateChange = { viewModel.setAimState(it) },
                                    onStanceChange = { viewModel.setPlayerStance(it) },
                                    onSurfaceChange = { viewModel.setImpactSurface(it) },
                                    onMeleeAttack = { viewModel.executeMeleeAttack(it) },
                                    onSilentTakedown = { viewModel.executeSilentTakedown() },
                                    onResetTarget = { viewModel.resetEnemyTarget() },
                                    onToggleAttachment = { viewModel.toggleAttachment(it) },
                                    onOpenArmory = { combatSubTabIndex = 2 }
                                )
                            }
                            1 -> {
                                PoliceDispatchView(
                                    wantedLevel = wantedLevel,
                                    policeSearchPhase = policeSearchPhase,
                                    searchDecayProgress = searchDecayProgress,
                                    policeHeatPercentage = policeHeatPercentage,
                                    activePoliceUnits = activePoliceUnits,
                                    dispatchRadioLogs = dispatchRadioLogs,
                                    currentDistrictName = selectedDistrict.name,
                                    onReportCrime = { viewModel.reportCrime(it) },
                                    onSetWantedStars = { viewModel.setWantedStarsDirect(it) },
                                    onBreakVisualContact = { viewModel.breakVisualContact() },
                                    onClearWanted = { viewModel.clearWantedLevel() }
                                )
                            }
                            2 -> {
                                WeaponArmoryView(
                                    weapons = viewModel.allWeapons,
                                    selectedWeapon = selectedWeapon,
                                    activeProtagonist = activeProtagonist,
                                    savedWeapons = savedWeapons,
                                    onSelectWeapon = { viewModel.selectWeapon(it.id) },
                                    onSaveToInventory = { wep, owner -> viewModel.saveWeaponToInventory(wep, owner) },
                                    onDeleteSavedWeapon = { entity -> viewModel.deleteSavedWeapon(entity) },
                                    onEquipToRange = {
                                        viewModel.selectWeapon(it.id)
                                        combatSubTabIndex = 0
                                    }
                                )
                            }
                        }
                    }
                }

                4 -> {
                    // TAB 4: VEHICLES & DRIVING (Prompt 02)
                    Column(modifier = Modifier.fillMaxSize()) {
                        TabRow(
                            selectedTabIndex = vehicleSubTabIndex,
                            containerColor = KarachiDarkNavy,
                            contentColor = KarachiGold
                        ) {
                            Tab(
                                selected = vehicleSubTabIndex == 0,
                                onClick = { vehicleSubTabIndex = 0 },
                                text = { Text("Drive Sim", fontSize = 11.sp) }
                            )
                            Tab(
                                selected = vehicleSubTabIndex == 1,
                                onClick = { vehicleSubTabIndex = 1 },
                                text = { Text("Garage", fontSize = 11.sp) }
                            )
                            Tab(
                                selected = vehicleSubTabIndex == 2,
                                onClick = { vehicleSubTabIndex = 2 },
                                text = { Text("Vehicle Fleet", fontSize = 11.sp) }
                            )
                        }

                        when (vehicleSubTabIndex) {
                            0 -> {
                                DrivingSimulatorView(
                                    vehicle = selectedVehicle,
                                    drivingState = drivingState,
                                    onThrottleChange = { viewModel.setThrottle(it) },
                                    onBrakeChange = { viewModel.setBrake(it) },
                                    onSteeringChange = { viewModel.setSteering(it) },
                                    onHandbrakeChange = { viewModel.setHandbrake(it) },
                                    onSurfaceChange = { viewModel.setSurface(it) },
                                    onToggleAssist = { viewModel.toggleAssist(it) },
                                    onCycleCamera = { viewModel.cycleCameraPerspective() },
                                    onToggleLights = { viewModel.toggleHeadlights() },
                                    onToggleSiren = { viewModel.toggleSiren() },
                                    onHornPress = { viewModel.setHorn(it) },
                                    onCollisionTrigger = { viewModel.triggerCollision(it) },
                                    onRepairVehicle = { viewModel.repairVehicle() },
                                    onOpenGarage = { vehicleSubTabIndex = 1 }
                                )
                            }
                            1 -> {
                                GarageCustomizerView(
                                    vehicle = selectedVehicle,
                                    activeProtagonist = activeProtagonist,
                                    garageVehicles = garageVehicles,
                                    onSaveToGarage = { veh, owner -> viewModel.saveVehicleToGarage(veh, owner) },
                                    onDeleteFromGarage = { entity -> viewModel.removeGarageVehicle(entity) },
                                    onSelectVehicle = { vehId -> viewModel.selectVehicle(vehId) },
                                    onBackToSimulator = { vehicleSubTabIndex = 0 }
                                )
                            }
                            2 -> {
                                VehicleCatalogView(
                                    vehicles = viewModel.allVehicles,
                                    selectedVehicle = selectedVehicle,
                                    onSelectVehicle = { veh -> viewModel.selectVehicle(veh.id) },
                                    onStartDrive = { veh ->
                                        viewModel.selectVehicle(veh.id)
                                        vehicleSubTabIndex = 0
                                    }
                                )
                            }
                        }
                    }
                }

                5 -> {
                    // TAB 5: UNREAL ENGINE 5 C++ ARCHITECTURE (Prompts 01, 02, 03, 04, and 05)
                    Column(modifier = Modifier.fillMaxSize()) {
                        ScrollableTabRow(
                            selectedTabIndex = ue5SubTabIndex,
                            containerColor = KarachiDarkNavy,
                            contentColor = KarachiGold,
                            edgePadding = 8.dp,
                            divider = {}
                        ) {
                            Tab(
                                selected = ue5SubTabIndex == 0,
                                onClick = { ue5SubTabIndex = 0 },
                                text = { Text("P01: World", fontSize = 10.sp) }
                            )
                            Tab(
                                selected = ue5SubTabIndex == 1,
                                onClick = { ue5SubTabIndex = 1 },
                                text = { Text("P02: Vehicles", fontSize = 10.sp) }
                            )
                            Tab(
                                selected = ue5SubTabIndex == 2,
                                onClick = { ue5SubTabIndex = 2 },
                                text = { Text("P03: Combat", fontSize = 10.sp) }
                            )
                            Tab(
                                selected = ue5SubTabIndex == 3,
                                onClick = { ue5SubTabIndex = 3 },
                                text = { Text("P04: Characters", fontSize = 10.sp) }
                            )
                            Tab(
                                selected = ue5SubTabIndex == 4,
                                onClick = { ue5SubTabIndex = 4 },
                                text = { Text("P05: Story/Missions", fontSize = 10.sp, color = KarachiGold) }
                            )
                        }
                        when (ue5SubTabIndex) {
                            0 -> UE5ArchitectureViewer()
                            1 -> UE5VehicleArchitectureViewer()
                            2 -> UE5CombatArchitectureViewer()
                            3 -> UE5CharacterArchitectureViewer()
                            4 -> UE5StoryArchitectureViewer()
                        }
                    }
                }
            }
        }
    }
}
