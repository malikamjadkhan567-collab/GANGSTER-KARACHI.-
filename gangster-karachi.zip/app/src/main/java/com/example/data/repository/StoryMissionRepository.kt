package com.example.data.repository

import com.example.data.local.FactionReputationEntity
import com.example.data.local.MissionProgressEntity
import com.example.data.local.WorldDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class StoryMissionRepository(private val worldDao: WorldDao) {

    // ==========================================================================
    // 5 KARACHI METRO FACTIONS
    // ==========================================================================
    val allFactions: List<Faction> = listOf(
        Faction(
            id = "faction_lsk",
            name = "Lyari Street Kings",
            shortCode = "LSK",
            districtTerritory = "Lyari Blocks & Saddar",
            description = "Grassroots youth network of street racers, rooftop parkour runners, and neighborhood couriers loyal to Ayan's family.",
            colorHex = 0xFF00E5FF,
            reputationScore = 75,
            standing = FactionStanding.ALLIED,
            bossName = "Mama Qadir (The Old Guard)",
            perkDescription = "Immediate backup motorcycle escort & street informant alerts on police checkpoints."
        ),
        Faction(
            id = "faction_kps",
            name = "Kemari Port Syndicate",
            shortCode = "KPS",
            districtTerritory = "Port District & Industrial Zone",
            description = "Heavily armed maritime logistics cartel controlling dock gantries, customs warehouses, and sea-freight contraband.",
            colorHex = 0xFFFF4444,
            reputationScore = 60,
            standing = FactionStanding.ALLIED,
            bossName = "Malik Jahangir (The Harbor King)",
            perkDescription = "Access to heavy military weapons, armored pickups, and deep-water boat safehouses."
        ),
        Faction(
            id = "faction_ccg",
            name = "Clifton Capital Group",
            shortCode = "CCG",
            districtTerritory = "Defence Gardens & Clifton Heights",
            description = "Multi-billion rupee corporate enterprise masking money laundering, private security contracting, and political bribery.",
            colorHex = 0xFFFFB703,
            reputationScore = 50,
            standing = FactionStanding.NEUTRAL,
            bossName = "Suleman Qureshi (Chairman)",
            perkDescription = "High-speed encrypted police dispatch interception, corporate helicopter access, and Swiss accounts."
        ),
        Faction(
            id = "faction_orc",
            name = "Orangi Ridge Cartel",
            shortCode = "ORC",
            districtTerritory = "Orangi District & Northern Hills",
            description = "Cut-throat hillside chop-shop syndicates running arms fabrication, illegal scrap distribution, and ruthless debt collection.",
            colorHex = 0xFF9333EA,
            reputationScore = -40,
            standing = FactionStanding.HOSTILE,
            bossName = "Shera Pukhtun (The Ridge Warlord)",
            perkDescription = "Custom engine nitrous tuning & black market ammunition bulk supply."
        ),
        Faction(
            id = "faction_stru",
            name = "Sindh Tactical Response Unit (STRU)",
            shortCode = "STRU",
            districtTerritory = "Metro Airport, Outer Highway & Cantonment",
            description = "Elite paramilitary law-enforcement division equipped with BearCat SWAT vans, helicopter snipers, and highway spike units.",
            colorHex = 0xFF3B82F6,
            reputationScore = -85,
            standing = FactionStanding.HOSTILE,
            bossName = "DIG Kamran Tariq (Task Force Chief)",
            perkDescription = "High-threat pursuit units deployed whenever Wanted Level exceeds 3 stars."
        )
    )

    // ==========================================================================
    // 30 STORY MISSIONS (Acts I, II, III, and IV)
    // ==========================================================================
    val allMissions: List<StoryMission> = listOf(
        // ACT I: MISSIONS 01 - 08
        StoryMission(
            id = "m01",
            act = StoryAct.ACT_I,
            missionNumber = 1,
            title = "Lyari Midnight Run",
            summary = "Ayan must deliver an encrypted flash drive across the rooftops of Lyari Blocks while shaking off aggressive local precinct beat cops.",
            protagonistIds = listOf("ayan"),
            districtId = "lyari_blocks",
            districtName = "Lyari Blocks",
            worldCoordsX = 250f,
            worldCoordsY = 580f,
            rewardCashPkr = 45000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 15,
            unlockedVehicleId = "bike_yamaha_r6",
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Bhai, scene garam hai! Galiyan block hain, mujhe bike se nikalna hoga!", "Brother, the heat is on! The alleyways are blocked, I have to break out on the bike!", 0xFF00E5FF, 3200L, "Agitated"),
                DialogueLine("Mama Qadir", "faction_boss", "Ayan beta, Saddar ki taraf mat jana. Wahan Kamran ke bande khare hain.", "Son, don't head towards Saddar. Kamran's tactical officers are stationed there.", 0xFF00E5FF, 3500L, "Warning")
            ),
            objectives = listOf(
                MissionObjective("Sprint to Ayan's tuned sports bike", isCompleted = false, goldCondition = "Reach bike under 45s"),
                MissionObjective("Escape the 1-star police patrol perimeter", isCompleted = false, goldCondition = "Take zero vehicle damage"),
                MissionObjective("Deliver encrypted drive to Lyari Safehouse", isCompleted = false)
            ),
            status = MissionStatus.AVAILABLE
        ),

        StoryMission(
            id = "m02",
            act = StoryAct.ACT_I,
            missionNumber = 2,
            title = "Container 47",
            summary = "Shahroz inspects a flagged shipping container in Port District carrying military grade hardware, only to walk into a rival syndicate ambush.",
            protagonistIds = listOf("shahroz"),
            districtId = "port_district",
            districtName = "Port District",
            worldCoordsX = 380f,
            worldCoordsY = 780f,
            rewardCashPkr = 75000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 20,
            unlockedWeaponId = "ar_ak47",
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "Container ka seal toota hua hai. Yahan goli chalne wali hai.", "The container seal is broken. Blood is about to spill here.", 0xFFFF4444, 3000L, "Tactical"),
                DialogueLine("Harbor Guard", "faction_boss", "Malik Sahab! Gantry number 3 pe armed gaadiyan aa gayi hain!", "Boss! Armed pickups just pulled into Gantry 3!", 0xFFFF4444, 2800L, "Alarmed")
            ),
            objectives = listOf(
                MissionObjective("Breach Container 47 at Gantry 3", isCompleted = false),
                MissionObjective("Eliminate 8 ambushing Orangi Ridge gunmen", isCompleted = false, goldCondition = "Achieve 5 headshots"),
                MissionObjective("Secure heavy arms shipment into port warehouse", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m03",
            act = StoryAct.ACT_I,
            missionNumber = 3,
            title = "Cantonment Cleaners",
            summary = "Daniyal infiltrates a rival commercial high-rise in Defence Gardens to wipe offshore bank accounts before an anti-corruption raid.",
            protagonistIds = listOf("daniyal"),
            districtId = "defence_gardens",
            districtName = "Defence Gardens",
            worldCoordsX = 620f,
            worldCoordsY = 450f,
            rewardCashPkr = 120000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 25,
            unlockedWeaponId = "wep_karachi_mptac",
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "Audit team 10 minute mein pahunch rahi hai. Server room ka bypass ready hai.", "The audit team arrives in 10 minutes. The server bypass is primed.", 0xFFFFB703, 3400L, "Confident"),
                DialogueLine("Security Lead", "structural", "Sir, penthouse elevator locked down kar di gayi hai.", "Sir, the penthouse elevator has been locked down.", 0xFF94A3B8, 2500L, "Neutral")
            ),
            objectives = listOf(
                MissionObjective("Access 24th floor server vault silently", isCompleted = false, goldCondition = "No alarms triggered"),
                MissionObjective("Deploy malware decryptor to offshore accounts", isCompleted = false),
                MissionObjective("Exfiltrate via underground luxury car garage", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m04",
            act = StoryAct.ACT_I,
            missionNumber = 4,
            title = "Tariq Road Shakeup",
            summary = "Ayan and Shahroz cross paths for the first time during an extortion shootout inside the bustling night markets of Tariq Bazaar.",
            protagonistIds = listOf("ayan", "shahroz"),
            districtId = "tariq_bazaar",
            districtName = "Tariq Bazaar",
            worldCoordsX = 540f,
            worldCoordsY = 380f,
            rewardCashPkr = 95000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 20,
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Aap yahan kya kar rahe ho Malik Sahab? Yeh hamara mohalla hai!", "What are you doing here Malik Sahab? This is our neighborhood!", 0xFF00E5FF, 3200L, "Questioning"),
                DialogueLine("Shahroz", "shahroz", "Chup kar ke cover le ladke. Yeh log business nahi, jaan lene aaye hain.", "Get down and take cover kid. These guys didn't come to negotiate, they came to kill.", 0xFFFF4444, 3800L, "Commanding")
            ),
            objectives = listOf(
                MissionObjective("Defend market shopfronts against Orangi enforcers", isCompleted = false),
                MissionObjective("Cover Shahroz while reloading heavy ordnance", isCompleted = false),
                MissionObjective("Pursue fleeing cartel boss on sport motorcycle", isCompleted = false, goldCondition = "Take down target under 2 mins")
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m05",
            act = StoryAct.ACT_I,
            missionNumber = 5,
            title = "Dockland Narcotics Raid",
            summary = "Shahroz leads an armed raid against an unauthorized heroin shipment docked in the Old Town fishing canals.",
            protagonistIds = listOf("shahroz"),
            districtId = "old_town",
            districtName = "Old Town",
            worldCoordsX = 420f,
            worldCoordsY = 620f,
            rewardCashPkr = 110000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 25,
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "Karachi Port pe mera naam chalta hai. Tumhara maal samundar mein jayega.", "My name rules Karachi Port. Your shipment is going into the sea.", 0xFFFF4444, 3500L, "Intimidating")
            ),
            objectives = listOf(
                MissionObjective("Infiltrate wooden fishing trawler docks", isCompleted = false),
                MissionObjective("Detonate contraband storage cargo", isCompleted = false),
                MissionObjective("Evade arriving maritime police patrol boat", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m06",
            act = StoryAct.ACT_I,
            missionNumber = 6,
            title = "Penthouse Blackmail",
            summary = "Daniyal bugges a high-ranking minister's seaside villa in Clifton Heights to secure commercial port import licenses.",
            protagonistIds = listOf("daniyal"),
            districtId = "clifton_heights",
            districtName = "Clifton Heights",
            worldCoordsX = 720f,
            worldCoordsY = 560f,
            rewardCashPkr = 160000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 30,
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "In logon ko lagta hai paisa taqat hai. Asli taqat information hai.", "These people think money is power. Real power is information.", 0xFFFFB703, 3400L, "Cold")
            ),
            objectives = listOf(
                MissionObjective("Infiltrate coastal cliffside estate", isCompleted = false, goldCondition = "Zero civilian casualties"),
                MissionObjective("Plant listening bug in executive study", isCompleted = false),
                MissionObjective("Exfiltrate on offshore luxury speedboat", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m07",
            act = StoryAct.ACT_I,
            missionNumber = 7,
            title = "Orangi Chop-Shop Ambush",
            summary = "Ayan retrieves a stolen custom tuner car from the fortified hillside scrap yards of Orangi District.",
            protagonistIds = listOf("ayan"),
            districtId = "orangi_district",
            districtName = "Orangi District",
            worldCoordsX = 310f,
            worldCoordsY = 250f,
            rewardCashPkr = 80000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 20,
            unlockedVehicleId = "veh_khyber_rspec",
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Meri gaadi ko haath lagaya toh Orangi ke pahaad se neeche phekunga!", "Touch my car and I will throw you off the Orangi hills!", 0xFF00E5FF, 3200L, "Furious")
            ),
            objectives = listOf(
                MissionObjective("Parkour across scrap yard crane rooftops", isCompleted = false),
                MissionObjective("Recover tuned sports coupe", isCompleted = false),
                MissionObjective("Escape through narrow hillside alleys without crashing", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m08",
            act = StoryAct.ACT_I,
            missionNumber = 8,
            title = "The Ocean Drive Alliance",
            summary = "The pivotal meeting: Ayan, Shahroz, and Daniyal meet at a private beach pavilion on Ocean Drive to forge a secret triad alliance against the Karachi oligarchs.",
            protagonistIds = listOf("ayan", "shahroz", "daniyal"),
            districtId = "ocean_drive",
            districtName = "Ocean Drive",
            worldCoordsX = 680f,
            worldCoordsY = 720f,
            rewardCashPkr = 200000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 35,
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "Hum teeno alag alag larenge toh ek ek karke maare jayenge. Together, we take this city.", "If we fight separately, they will eliminate us one by one. Together, we take this city.", 0xFFFFB703, 4000L, "Persuasive"),
                DialogueLine("Shahroz", "shahroz", "Mujhe paisa nahi chahiye Daniyal. Mujhe port ka control chahiye.", "I don't need your money Daniyal. I need absolute control of the port.", 0xFFFF4444, 3600L, "Stern"),
                DialogueLine("Ayan", "ayan", "Aur mere Lyari ke logon ko koi tang nahi karega. Done deal.", "And nobody touches my people in Lyari. Done deal.", 0xFF00E5FF, 3000L, "Decisive")
            ),
            objectives = listOf(
                MissionObjective("Rendezvous at Ocean Drive Beach Boardwalk", isCompleted = false),
                MissionObjective("Repel an unexpected ambush by corrupt STRU taskforce", isCompleted = false),
                MissionObjective("Switch between all 3 protagonists to eliminate snipers & drive getaway convoy", isCompleted = false, goldCondition = "All 3 characters health > 50%")
            ),
            status = MissionStatus.LOCKED
        ),

        // ACT II: MISSIONS 09 - 16
        StoryMission(
            id = "m09",
            act = StoryAct.ACT_II,
            missionNumber = 9,
            title = "Saddar Diamond Exchange",
            summary = "The triad pulls off their first coordinated heist on a high-security diamond brokerage in Saddar Central.",
            protagonistIds = listOf("ayan", "daniyal"),
            districtId = "saddar_central",
            districtName = "Saddar Central",
            worldCoordsX = 480f,
            worldCoordsY = 480f,
            rewardCashPkr = 350000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 30,
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "Laser grid disabled hai Ayan. You have 90 seconds to crack the vault.", "Laser grid is down Ayan. You have 90 seconds to crack the vault.", 0xFFFFB703, 3200L, "Tactical"),
                DialogueLine("Ayan", "ayan", "90 seconds bohot hain boss. Watch this!", "90 seconds is plenty boss. Watch this!", 0xFF00E5FF, 2500L, "Confident")
            ),
            objectives = listOf(
                MissionObjective("Disable CCTV mainframe from exterior rooftop", isCompleted = false),
                MissionObjective("Infiltrate basement vault using laser cutter", isCompleted = false),
                MissionObjective("Escape through bustling Saddar bus terminal", isCompleted = false)
            ),
            status = MissionStatus.LOCKED,
            heistPrepType = "TACTICAL_INFILTRATION"
        ),

        StoryMission(
            id = "m10",
            act = StoryAct.ACT_II,
            missionNumber = 10,
            title = "Outer Highway Interception",
            summary = "High-speed highway takedown: Intercept a heavily armored bullion transport rolling down the Outer Highway at 140 km/h.",
            protagonistIds = listOf("shahroz", "ayan"),
            districtId = "outer_highway",
            districtName = "Outer Highway",
            worldCoordsX = 510f,
            worldCoordsY = 880f,
            rewardCashPkr = 450000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 35,
            unlockedVehicleId = "suv_landcruiser_v8",
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "Ayan, gaadi ko truck ke right side pe la. Main tires pe rocket marta hoon!", "Ayan, pull up alongside the right flank. I'm taking out the tires with the launcher!", 0xFFFF4444, 3800L, "Urgent"),
                DialogueLine("Ayan", "ayan", "Pakka grip rakhna Malik Sahab! Drift mar raha hoon!", "Hold on tight Malik Sahab! Initiating drift maneuver!", 0xFF00E5FF, 2800L, "Excited")
            ),
            objectives = listOf(
                MissionObjective("Match speed with armored convoy on Outer Highway", isCompleted = false),
                MissionObjective("Shoot out convoy escort cruisers", isCompleted = false),
                MissionObjective("Hook tow cable and haul bullion trailer to salvage yard", isCompleted = false, goldCondition = "Complete under 3:30")
            ),
            status = MissionStatus.LOCKED,
            heistPrepType = "HEAVY_ASSAULT"
        ),

        StoryMission(
            id = "m11",
            act = StoryAct.ACT_II,
            missionNumber = 11,
            title = "Gantry 7 Sniper Overwatch",
            summary = "Shahroz provides sniper overwatch from towering harbor cranes while Ayan plants tracking beacons on cartel freighters.",
            protagonistIds = listOf("shahroz", "ayan"),
            districtId = "port_district",
            districtName = "Port District",
            worldCoordsX = 380f,
            worldCoordsY = 780f,
            rewardCashPkr = 280000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 25,
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "Clear hai ladke. Agle container pe jump kar.", "All clear kid. Leap to the next container stack.", 0xFFFF4444, 2500L, "Focused")
            ),
            objectives = listOf(
                MissionObjective("Climb crane to 85m sniper platform", isCompleted = false),
                MissionObjective("Eliminate 10 patrolling guards without alerting ship crew", isCompleted = false, goldCondition = "All headshots"),
                MissionObjective("Plant GPS tracker on flagship cargo freighter", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m12",
            act = StoryAct.ACT_II,
            missionNumber = 12,
            title = "Defence Offshore Launder",
            summary = "Daniyal outsmarts federal auditors at the Marina Club by routing millions through automated cryptocurrency relay rigs.",
            protagonistIds = listOf("daniyal"),
            districtId = "defence_gardens",
            districtName = "Defence Gardens",
            worldCoordsX = 620f,
            worldCoordsY = 450f,
            rewardCashPkr = 500000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 35,
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "Paisa hawa ki tarah hota hai. Pakadne ki koshish karoge toh nikal jayega.", "Money is like air. Try to grip it too tightly and it slips away.", 0xFFFFB703, 3500L, "Confident")
            ),
            objectives = listOf(
                MissionObjective("Attend Marina Club executive gala in tuxedo", isCompleted = false),
                MissionObjective("Hack governor's personal tablet device", isCompleted = false),
                MissionObjective("Authorize transfer of 50M PKR offshore", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m13",
            act = StoryAct.ACT_II,
            missionNumber = 13,
            title = "Lyari Rooftop Evacuation",
            summary = "A sudden 3-star police sweep hits Lyari; Ayan must guide civilians and contraband out through rooftop clotheslines and water tanks.",
            protagonistIds = listOf("ayan"),
            districtId = "lyari_blocks",
            districtName = "Lyari Blocks",
            worldCoordsX = 250f,
            worldCoordsY = 580f,
            rewardCashPkr = 180000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 30,
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Chopper aasmaan mein ghoom raha hai! Chhaton se nikalna hoga!", "Police chopper circling overhead! We have to move via the rooftops!", 0xFF00E5FF, 3200L, "Urgent")
            ),
            objectives = listOf(
                MissionObjective("Parkour across 6 building rooftops", isCompleted = false),
                MissionObjective("Disable police searchlight generator", isCompleted = false),
                MissionObjective("Lead convoy to underground storm drain sanctuary", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m14",
            act = StoryAct.ACT_II,
            missionNumber = 14,
            title = "Hawk's Ridge Ambush",
            summary = "Cartel warlord Shera Pukhtun sets an explosive trap in the Northern Hills; Shahroz fights through rock quarries.",
            protagonistIds = listOf("shahroz"),
            districtId = "northern_hills",
            districtName = "Northern Hills",
            worldCoordsX = 720f,
            worldCoordsY = 180f,
            rewardCashPkr = 320000L,
            rewardFactionId = "faction_orc",
            rewardFactionPoints = -30,
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "Shera ne galat aadmi pe nishana lagaya hai. Ab yeh quarry uski qabar banegi.", "Shera targeted the wrong man. This quarry will become his grave.", 0xFFFF4444, 3800L, "Fierce")
            ),
            objectives = listOf(
                MissionObjective("Survive quarry rock-slide ambush", isCompleted = false),
                MissionObjective("Destroy 3 cartel technical machine-gun trucks", isCompleted = false),
                MissionObjective("Eliminate Shera's second-in-command", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m15",
            act = StoryAct.ACT_II,
            missionNumber = 15,
            title = "Subterranean Infiltration",
            summary = "Ayan and Daniyal infiltrate the city's central water filtration tunnels directly beneath Downtown to tap state communications.",
            protagonistIds = listOf("ayan", "daniyal"),
            districtId = "downtown",
            districtName = "Downtown",
            worldCoordsX = 490f,
            worldCoordsY = 410f,
            rewardCashPkr = 290000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 25,
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Gutter ki badboo se sar phat raha hai Daniyal bhai!", "The sewer stench is splitting my head Daniyal!", 0xFF00E5FF, 2800L, "Disgusted"),
                DialogueLine("Daniyal", "daniyal", "Focus on the 200 million waiting on the other side Ayan.", "Focus on the 200 million waiting on the other side Ayan.", 0xFFFFB703, 3000L, "Calm")
            ),
            objectives = listOf(
                MissionObjective("Navigate underground floodway on motorized dinghy", isCompleted = false),
                MissionObjective("Bypass electrical junction box with technical tool", isCompleted = false),
                MissionObjective("Plant tap into DIG police server conduit", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m16",
            act = StoryAct.ACT_II,
            missionNumber = 16,
            title = "The Central Bank Heist",
            summary = "The climax of Act II: A full-scale triad heist on the State Vault in Saddar Central. All 3 protagonists must coordinate simultaneously.",
            protagonistIds = listOf("ayan", "shahroz", "daniyal"),
            districtId = "saddar_central",
            districtName = "Saddar Central",
            worldCoordsX = 480f,
            worldCoordsY = 480f,
            rewardCashPkr = 1200000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 50,
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "Main lobby hold kar raha hoon! Daniyal, vault kholo!", "I'm holding the main lobby! Daniyal, pop the vault doors!", 0xFFFF4444, 3200L, "Shouting"),
                DialogueLine("Daniyal", "daniyal", "Thermal charge armed! 10 seconds to breach!", "Thermal charge armed! 10 seconds to breach!", 0xFFFFB703, 2800L, "Focused"),
                DialogueLine("Ayan", "ayan", "Getaway van ready hai! SWAT cruisers aa rahi hain!", "Getaway van is running! SWAT cruisers approaching!", 0xFF00E5FF, 2900L, "Urgent")
            ),
            objectives = listOf(
                MissionObjective("Shahroz: Hold lobby against 15 police assault waves", isCompleted = false),
                MissionObjective("Daniyal: Crack subterranean diamond safe locks", isCompleted = false),
                MissionObjective("Ayan: Drive getaway van through 4-star roadblocks to port bunker", isCompleted = false, goldCondition = "Zero squad deaths, complete under 5 mins")
            ),
            status = MissionStatus.LOCKED,
            heistPrepType = "GRAND_HEIST"
        ),

        // ACT III: MISSIONS 17 - 24
        StoryMission(
            id = "m17",
            act = StoryAct.ACT_III,
            missionNumber = 17,
            title = "The Syndicate Split",
            summary = "Following the bank heist, greed and outside pressure fracture the alliance. Ayan discovers a traitor planting evidence in Lyari.",
            protagonistIds = listOf("ayan"),
            districtId = "lyari_blocks",
            districtName = "Lyari Blocks",
            worldCoordsX = 250f,
            worldCoordsY = 580f,
            rewardCashPkr = 220000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 25,
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Hum mein se kisi ne police ko tip di hai... Aur main pata laga ke rahoonga.", "One of us tipped off the police... and I will uncover who did it.", 0xFF00E5FF, 3600L, "Suspicious")
            ),
            objectives = listOf(
                MissionObjective("Interrogate corrupt precinct lieutenant in alley", isCompleted = false),
                MissionObjective("Recover marked bearer bonds from compromised locker", isCompleted = false),
                MissionObjective("Confront informant before he boards ferry", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m18",
            act = StoryAct.ACT_III,
            missionNumber = 18,
            title = "Smuggler's Cove Gunfight",
            summary = "Shahroz's port safehouse comes under heavy rocket bombardment by rogue maritime mercenaries.",
            protagonistIds = listOf("shahroz"),
            districtId = "fishing_village",
            districtName = "Fishing Village",
            worldCoordsX = 220f,
            worldCoordsY = 820f,
            rewardCashPkr = 350000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 30,
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "In logon ne meri zameen pe aag lagayi hai. Koi zinda wapas nahi jayega.", "They set fire to my home soil. Not one of them leaves alive.", 0xFFFF4444, 3800L, "Wrathful")
            ),
            objectives = listOf(
                MissionObjective("Repel amphibious mercenary assault on beachhead", isCompleted = false),
                MissionObjective("Destroy 2 offshore patrol gunboats with RPG", isCompleted = false),
                MissionObjective("Secure harbor communications mast", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m19",
            act = StoryAct.ACT_III,
            missionNumber = 19,
            title = "Textile Mill Standoff",
            summary = "Daniyal is trapped inside an abandoned industrial textile mill surrounded by cartel assassins; Ayan and Shahroz mount a tactical rescue.",
            protagonistIds = listOf("ayan", "shahroz"),
            districtId = "industrial_zone",
            districtName = "Industrial Zone",
            worldCoordsX = 420f,
            worldCoordsY = 320f,
            rewardCashPkr = 400000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 35,
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "I'm pinned down behind the cotton looms! Heavy fire from rafters!", "I'm pinned down behind the cotton looms! Heavy fire from rafters!", 0xFFFFB703, 3000L, "Desperate"),
                DialogueLine("Shahroz", "shahroz", "Hold on Daniyal! Ham darwaza tod ke andar aa rahe hain!", "Hold on Daniyal! We are breaching the factory gates!", 0xFFFF4444, 3200L, "Roaring")
            ),
            objectives = listOf(
                MissionObjective("Ayan: Infiltrate skylight and snipe mill catwalk guards", isCompleted = false),
                MissionObjective("Shahroz: Ram entrance gates with armored truck", isCompleted = false),
                MissionObjective("Extract wounded Daniyal to safehouse clinic", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m20",
            act = StoryAct.ACT_III,
            missionNumber = 20,
            title = "Marina Yacht Interrogation",
            summary = "Daniyal recovers and uses advanced hacking rigs on a luxury yacht anchored off Clifton to reveal the corrupt DIG's master plan.",
            protagonistIds = listOf("daniyal"),
            districtId = "clifton_heights",
            districtName = "Clifton Heights",
            worldCoordsX = 720f,
            worldCoordsY = 560f,
            rewardCashPkr = 450000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 30,
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "DIG Kamran port par curfew laga raha hai taake sara gold khud le sake.", "DIG Kamran is declaring curfew on the port so he can seize all the gold himself.", 0xFFFFB703, 3800L, "Revealing")
            ),
            objectives = listOf(
                MissionObjective("Board mega-yacht silently from underwater scuba route", isCompleted = false),
                MissionObjective("Extract encrypted hard drive from yacht captain study", isCompleted = false),
                MissionObjective("Escape before yacht security helicopter arrives", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m21",
            act = StoryAct.ACT_III,
            missionNumber = 21,
            title = "Metro Airport Runway Chase",
            summary = "Ayan chases an oligarch's private Learjet down the active runway of Metro Airport on his racing bike to prevent evidence from leaving.",
            protagonistIds = listOf("ayan"),
            districtId = "metro_airport",
            districtName = "Metro Airport",
            worldCoordsX = 780f,
            worldCoordsY = 320f,
            rewardCashPkr = 550000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 40,
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Yeh jahaz take-off nahi karega! Main landing gear tod doonga!", "This jet is not taking off! I will shoot out the landing gear!", 0xFF00E5FF, 3400L, "Determined")
            ),
            objectives = listOf(
                MissionObjective("Breach perimeter fence and match jet takeoff speed (240 km/h)", isCompleted = false),
                MissionObjective("Disable left landing gear hydraulics", isCompleted = false),
                MissionObjective("Recover digital blackmail manifests from wreckage", isCompleted = false, goldCondition = "Catch jet before runway threshold")
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m22",
            act = StoryAct.ACT_III,
            missionNumber = 22,
            title = "Greenbelt Jungle Lab",
            summary = "Shahroz and Ayan destroy the Orangi cartel's main chemical weapon manufacturing hub hidden in the dense forests of the Greenbelt.",
            protagonistIds = listOf("shahroz", "ayan"),
            districtId = "greenbelt",
            districtName = "Greenbelt",
            worldCoordsX = 350f,
            worldCoordsY = 120f,
            rewardCashPkr = 480000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 35,
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "Poora jungle aag ki lapet mein hoga. Sab kuch jala do.", "The whole canopy will burn. Incinerate everything.", 0xFFFF4444, 3200L, "Cold")
            ),
            objectives = listOf(
                MissionObjective("Infiltrate forest canopy perimeter silently", isCompleted = false),
                MissionObjective("Plant 4 C4 thermite charges on processing tanks", isCompleted = false),
                MissionObjective("Detonate and escape on off-road dirt bikes", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m23",
            act = StoryAct.ACT_III,
            missionNumber = 23,
            title = "Citywide 5-Star Curfew",
            summary = "The state declares full emergency lockdown across Karachi Metro. The triad must navigate through martial roadblocks and gunships.",
            protagonistIds = listOf("ayan", "shahroz", "daniyal"),
            districtId = "downtown",
            districtName = "Downtown",
            worldCoordsX = 490f,
            worldCoordsY = 410f,
            rewardCashPkr = 600000L,
            rewardFactionId = "faction_stru",
            rewardFactionPoints = -50,
            dialogueScript = listOf(
                DialogueLine("Radio Dispatch", "structural", "All units, Code Red martial protocol active. Kill on sight authorized.", "All units, Code Red martial protocol active. Kill on sight authorized.", 0xFF3B82F6, 3200L, "Automated"),
                DialogueLine("Ayan", "ayan", "Sari city band hai! Hum kahan jayenge?!", "The entire city is sealed! Where do we go?!", 0xFF00E5FF, 2800L, "Panicked"),
                DialogueLine("Shahroz", "shahroz", "Port ki taraf. Mere container bunker mein aao!", "Towards the port. Fall back to my container bunker!", 0xFFFF4444, 3000L, "Steely")
            ),
            objectives = listOf(
                MissionObjective("Survive 5-star wanted level across 3 districts", isCompleted = false),
                MissionObjective("Evade STRU dual helicopter searchlights", isCompleted = false),
                MissionObjective("Regroup all three protagonists in Port Salvage Bunker", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m24",
            act = StoryAct.ACT_III,
            missionNumber = 24,
            title = "Brothers on the Edge",
            summary = "In the bunker under siege, old grievances flare up. A tense dialogue standoff tests whether the triad will survive or tear each other apart.",
            protagonistIds = listOf("ayan", "shahroz", "daniyal"),
            districtId = "port_district",
            districtName = "Port District",
            worldCoordsX = 380f,
            worldCoordsY = 780f,
            rewardCashPkr = 250000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 20,
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Daniyal! Tune hume fasaya hai! Teri corporate deal ke chakkar mein police aayi!", "Daniyal! You set us up! The police came because of your corporate deal!", 0xFF00E5FF, 3600L, "Furious"),
                DialogueLine("Daniyal", "daniyal", "Use your brain Ayan! Agar main fasana chahta toh main khud yahan tumhare saath phansa hota?!", "Use your brain Ayan! If I wanted to betray you would I be trapped here with you?!", 0xFFFFB703, 4000L, "Defensive"),
                DialogueLine("Shahroz", "shahroz", "BOHOT HO GAYA! Bandookein neeche karo dono! Kal subah hum aakhri heist karenge. Ya toh sab bachenge, ya koi nahi.", "ENOUGH! Lower your weapons, both of you! Tomorrow at dawn we pull the final heist. Either we all walk away, or none of us do.", 0xFFFF4444, 5000L, "Roaring")
            ),
            objectives = listOf(
                MissionObjective("Complete dialogue choices to calm tensions", isCompleted = false),
                MissionObjective("Repel preliminary reconnaissance probe at bunker gates", isCompleted = false),
                MissionObjective("Finalize strategy for the Grand Port Heist", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        // ACT IV: MISSIONS 25 - 30 (THE GRAND HEIST & CLIMACTIC ENDINGS)
        StoryMission(
            id = "m25",
            act = StoryAct.ACT_IV,
            missionNumber = 25,
            title = "Operation Storm Harbor: Prep",
            summary = "Heist Preparation: Steal two high-speed offshore hydrofoils and military grade electronic EMP disruptors.",
            protagonistIds = listOf("ayan", "daniyal"),
            districtId = "fishing_village",
            districtName = "Fishing Village",
            worldCoordsX = 220f,
            worldCoordsY = 820f,
            rewardCashPkr = 500000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 30,
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "EMP device port radar ko 6 minute ke liye blackout kar dega.", "The EMP device will blackout the port radar for exactly 6 minutes.", 0xFFFFB703, 3400L, "Tactical")
            ),
            objectives = listOf(
                MissionObjective("Secure 2 hydrofoil interceptor speedboats", isCompleted = false),
                MissionObjective("Steal EMP military grade ordnance from naval armory", isCompleted = false)
            ),
            status = MissionStatus.LOCKED,
            heistPrepType = "HEIST_PREPARATION"
        ),

        StoryMission(
            id = "m26",
            act = StoryAct.ACT_IV,
            missionNumber = 26,
            title = "Gantry Crane Sabotage",
            summary = "Daniyal hacks the automated harbor container control system, reprogramming gantry cranes into defensive barricades.",
            protagonistIds = listOf("daniyal"),
            districtId = "port_district",
            districtName = "Port District",
            worldCoordsX = 380f,
            worldCoordsY = 780f,
            rewardCashPkr = 450000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 25,
            dialogueScript = listOf(
                DialogueLine("Daniyal", "daniyal", "Terminal central mainframe hijacked. Cranes are now our shields.", "Terminal central mainframe hijacked. Cranes are now our shields.", 0xFFFFB703, 3200L, "Confident")
            ),
            objectives = listOf(
                MissionObjective("Infiltrate Harbor Master automated control tower", isCompleted = false),
                MissionObjective("Override crane safety protocols to drop shipping containers as chokepoints", isCompleted = false)
            ),
            status = MissionStatus.LOCKED,
            heistPrepType = "HEIST_PREPARATION"
        ),

        StoryMission(
            id = "m27",
            act = StoryAct.ACT_IV,
            missionNumber = 27,
            title = "The 500 Million Gold Terminal",
            summary = "The Grand Heist begins: Breach the sovereign gold reserve containers arriving at Terminal 4 under cover of a coastal thunderstorm.",
            protagonistIds = listOf("ayan", "shahroz", "daniyal"),
            districtId = "port_district",
            districtName = "Port District",
            worldCoordsX = 380f,
            worldCoordsY = 780f,
            rewardCashPkr = 2500000L,
            rewardFactionId = "faction_kps",
            rewardFactionPoints = 60,
            unlockedVehicleId = "supercar_ferrari_f8",
            unlockedWeaponId = "heavy_rpg7",
            dialogueScript = listOf(
                DialogueLine("Shahroz", "shahroz", "Storm shuru ho chuka hai! Containers todna shuru karo!", "The storm has hit! Start cutting through the containers!", 0xFFFF4444, 3400L, "Urgent"),
                DialogueLine("Ayan", "ayan", "Gold bars secure hain! Heavy loader mein daal raha hoon!", "Gold bars secured! Loading into the heavy container truck!", 0xFF00E5FF, 3200L, "Ecstatic")
            ),
            objectives = listOf(
                MissionObjective("Shahroz: Blast security gate with rocket launcher", isCompleted = false),
                MissionObjective("Daniyal: Activate EMP blackout and disable alarms", isCompleted = false),
                MissionObjective("Ayan: Drive container hauler loaded with 500M bullion", isCompleted = false)
            ),
            status = MissionStatus.LOCKED,
            heistPrepType = "GRAND_HEIST"
        ),

        StoryMission(
            id = "m28",
            act = StoryAct.ACT_IV,
            missionNumber = 28,
            title = "The Triple Cross Ultimatum",
            summary = "As the triad secures the gold, DIG Kamran Tariq and oligarch brokers contact each protagonist separately with lucrative betrayal offers.",
            protagonistIds = listOf("ayan", "shahroz", "daniyal"),
            districtId = "clifton_heights",
            districtName = "Clifton Heights",
            worldCoordsX = 720f,
            worldCoordsY = 560f,
            rewardCashPkr = 1000000L,
            rewardFactionId = "faction_ccg",
            rewardFactionPoints = 20,
            dialogueScript = listOf(
                DialogueLine("DIG Kamran", "structural", "Shahroz, agar tum Ayan aur Daniyal ko surrender kar do, toh port tumhara permanent hoga.", "Shahroz, surrender Ayan and Daniyal, and the port is permanently yours.", 0xFF3B82F6, 4200L, "Manipulative"),
                DialogueLine("Shahroz", "shahroz", "Kamran... tune galat aadmi se deal karne ki koshish ki.", "Kamran... you tried to cut a deal with the wrong man.", 0xFFFF4444, 3800L, "Threatening")
            ),
            objectives = listOf(
                MissionObjective("Review incoming secret phone offers from oligarchs", isCompleted = false),
                MissionObjective("Choose your alliance posture (Loyalty or Individual Ambition)", isCompleted = false),
                MissionObjective("Regroup at the Hawk's Ridge vantage summit", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m29",
            act = StoryAct.ACT_IV,
            missionNumber = 29,
            title = "Point of No Return",
            summary = "The triad prepares for the decisive confrontation. The player locks in their chosen branching path that determines the fate of Karachi.",
            protagonistIds = listOf("ayan", "shahroz", "daniyal"),
            districtId = "northern_hills",
            districtName = "Northern Hills",
            worldCoordsX = 720f,
            worldCoordsY = 180f,
            rewardCashPkr = 1500000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 30,
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Karachi hamara shehar hai. Aaj raat faisla hoga ke yeh kiska hai.", "Karachi is our city. Tonight it is decided who it truly belongs to.", 0xFF00E5FF, 3600L, "Steely"),
                DialogueLine("Daniyal", "daniyal", "Let's finish this. On our own terms.", "Let's finish this. On our own terms.", 0xFFFFB703, 2600L, "Confident")
            ),
            objectives = listOf(
                MissionObjective("Equip maximum tier combat weaponry & armor", isCompleted = false),
                MissionObjective("Select final branching ending path", isCompleted = false),
                MissionObjective("Commence the final metropolitan offensive", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        ),

        StoryMission(
            id = "m30",
            act = StoryAct.ACT_IV,
            missionNumber = 30,
            title = "Karachi Sunset: The Final Reckoning",
            summary = "The ultimate climax of GANGSTER KARACHI — NEXT GEN. The final battle on the Clifton Shoreline, deciding who rules the open world.",
            protagonistIds = listOf("ayan", "shahroz", "daniyal"),
            districtId = "clifton_heights",
            districtName = "Clifton Heights",
            worldCoordsX = 720f,
            worldCoordsY = 560f,
            rewardCashPkr = 10000000L,
            rewardFactionId = "faction_lsk",
            rewardFactionPoints = 100,
            dialogueScript = listOf(
                DialogueLine("Ayan", "ayan", "Lyari se Clifton tak... ab koi hume nahi rok sakta!", "From Lyari to Clifton... nobody can stop us now!", 0xFF00E5FF, 3400L, "Triumphant"),
                DialogueLine("Shahroz", "shahroz", "Hukumat hamari hai. Karachi Metro hamari hai.", "The power is ours. Karachi Metro belongs to us.", 0xFFFF4444, 3600L, "Commanding"),
                DialogueLine("Daniyal", "daniyal", "Gentlemen, welcome to the new era of Karachi.", "Gentlemen, welcome to the new era of Karachi.", 0xFFFFB703, 3200L, "Smooth")
            ),
            objectives = listOf(
                MissionObjective("Defeat DIG Kamran's final elite BearCat convoy", isCompleted = false, goldCondition = "Destroy boss chopper with heavy sniper"),
                MissionObjective("Secure the 500 Million bullion transport", isCompleted = false),
                MissionObjective("Watch the Karachi Sunset cinematic finale", isCompleted = false)
            ),
            status = MissionStatus.LOCKED
        )
    )

    // ==========================================================================
    // ROOM PERSISTENCE FOR MISSIONS & FACTIONS
    // ==========================================================================
    fun getAllMissionProgress(): Flow<List<MissionProgressEntity>> {
        return worldDao.getAllMissionProgress()
    }

    suspend fun saveMissionStatus(missionId: String, status: MissionStatus, rating: String = "GOLD") {
        worldDao.saveMissionProgress(
            MissionProgressEntity(
                missionId = missionId,
                status = status.name,
                scoreRating = rating,
                completedTimestamp = System.currentTimeMillis()
            )
        )
    }

    fun getAllFactionReputations(): Flow<List<FactionReputationEntity>> {
        return worldDao.getAllFactionReputations()
    }

    suspend fun updateFactionReputation(factionId: String, scoreDelta: Int) {
        val faction = allFactions.find { it.id == factionId } ?: return
        val newScore = (faction.reputationScore + scoreDelta).coerceIn(-100, 100)
        faction.reputationScore = newScore
        val standing = when {
            newScore >= 70 -> FactionStanding.HONORED
            newScore >= 30 -> FactionStanding.ALLIED
            newScore >= -20 -> FactionStanding.NEUTRAL
            newScore >= -60 -> FactionStanding.UNFRIENDLY
            else -> FactionStanding.HOSTILE
        }
        worldDao.saveFactionReputation(
            FactionReputationEntity(
                factionId = factionId,
                reputationScore = newScore,
                standingLevel = standing.name
            )
        )
    }
}
