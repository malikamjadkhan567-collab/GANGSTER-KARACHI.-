package com.example.data.model

data class Protagonist(
    val id: String,
    val name: String,
    val title: String,
    val startingDistrictId: String,
    val startingDistrictName: String,
    val safehouseName: String,
    val safehouseTier: InteriorTier,
    val spawnCoordsX: Float,
    val spawnCoordsY: Float,
    val biography: String,
    val tacticalSpecialty: String,
    val startingVehicleStatus: String, // [NOT IMPLEMENTED - Reserved for Prompt 02]
    val startingWeaponStatus: String,  // [NOT IMPLEMENTED - Reserved for Prompt 03]
    val accentColorHex: Long
)
