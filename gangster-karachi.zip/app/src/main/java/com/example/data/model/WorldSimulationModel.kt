package com.example.data.model

import androidx.compose.ui.graphics.Color

// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// MASTER PROMPT 06: World Time, Weather, Day/Night, Lighting, Water, NPCs,
// Traffic, Wildlife & Living World Simulation
// ==============================================================================

/**
 * 10 distinct phases of the Karachi day/night cycle
 */
enum class DayNightPhase(
    val displayName: String,
    val startHour: Float,
    val endHour: Float,
    val ambientLux: Float,
    val skyTintHex: Long,
    val sunAngleDegrees: Float,
    val streetLightsOn: Boolean
) {
    PRE_DAWN("Pre-Dawn (Fajr Call)", 4.0f, 5.5f, 50f, 0xFF14192B, -12f, true),
    DAWN("Dawn / Sunrise", 5.5f, 6.5f, 500f, 0xFF5D4057, 4f, true),
    MORNING("Morning Rush", 6.5f, 10.0f, 25000f, 0xFF87CEEB, 25f, false),
    MIDDAY("Midday Sun", 10.0f, 14.0f, 90000f, 0xFF4FA4E2, 75f, false),
    AFTERNOON("Afternoon Heat", 14.0f, 17.0f, 60000f, 0xFF6DB3F2, 45f, false),
    GOLDEN_HOUR("Golden Hour (Asr)", 17.0f, 18.5f, 15000f, 0xFFE08D43, 15f, false),
    SUNSET("Sunset (Maghrib)", 18.5f, 19.5f, 2000f, 0xFF9E3D31, -2f, true),
    EVENING("Karachi Evening Lights", 19.5f, 21.5f, 300f, 0xFF1E2238, -18f, true),
    NIGHT("Night Buzz (Bazaars)", 21.5f, 24.0f, 80f, 0xFF0E1322, -45f, true),
    LATE_NIGHT("Late Night (Sehri / Silence)", 0.0f, 4.0f, 30f, 0xFF080C16, -70f, true);

    companion object {
        fun fromHour(hour: Float): DayNightPhase {
            val h = if (hour >= 24f) hour % 24f else if (hour < 0f) (hour % 24f) + 24f else hour
            return values().firstOrNull {
                if (it.startHour > it.endHour) {
                    // Spans midnight (e.g., NIGHT 21.5 to 24.0 or LATE_NIGHT 0.0 to 4.0)
                    h >= it.startHour || h < it.endHour
                } else {
                    h >= it.startHour && h < it.endHour
                }
            } ?: NIGHT
        }
    }
}

/**
 * 10 distinct dynamic weather states for Karachi Metro
 */
enum class WeatherType(
    val displayName: String,
    val baseRainIntensity: Float,
    val baseFogDensity: Float,
    val baseWindSpeedKmh: Float,
    val roadGripMultiplier: Float,
    val visibilityMeters: Float,
    val npcUmbrellaProbability: Float,
    val audioProfile: String
) {
    CLEAR("Clear Arabian Sky", 0.0f, 0.0f, 12f, 1.0f, 5000f, 0.0f, "ambient_city_clear"),
    PARTLY_CLOUDY("Partly Cloudy", 0.0f, 0.05f, 18f, 1.0f, 4500f, 0.0f, "ambient_city_breeze"),
    CLOUDY("Cloudy Skies", 0.0f, 0.15f, 22f, 0.98f, 3500f, 0.05f, "ambient_wind_moderate"),
    OVERCAST("Heavy Overcast", 0.05f, 0.25f, 30f, 0.95f, 2800f, 0.15f, "ambient_distant_rumble"),
    LIGHT_RAIN("Light Monsoon Drizzle", 0.35f, 0.30f, 28f, 0.85f, 2000f, 0.70f, "rain_light_tarmac"),
    HEAVY_RAIN("Heavy Monsoon Torrent", 0.85f, 0.60f, 48f, 0.68f, 900f, 0.95f, "rain_heavy_downpour"),
    STORM("Severe Cyclone Storm", 1.0f, 0.80f, 75f, 0.52f, 400f, 0.98f, "storm_thunder_lightning"),
    FOG("Dense Sea Mist / Smog", 0.0f, 0.90f, 8f, 0.90f, 200f, 0.0f, "fog_harbor_horns"),
    DUSTY_HAZY("Dry Dust Storm (Loo)", 0.0f, 0.55f, 52f, 0.82f, 800f, 0.10f, "wind_dust_whistle"),
    WINDY("Coastal High Gale", 0.0f, 0.10f, 62f, 0.92f, 3800f, 0.0f, "wind_gale_gusts")
}

/**
 * Calendar and Simulation Clock
 */
data class GameClock(
    val dayNumber: Int = 14,
    val hour: Int = 18,
    val minute: Int = 30,
    val second: Int = 0,
    val dayOfWeek: String = "Friday (Jumma)",
    val season: String = "Summer Monsoon Season",
    val timeSpeedMultiplier: Float = 1.0f, // 1 real sec = x game secs
    val isPaused: Boolean = false
) {
    val formattedTime: String
        get() = String.format("%02d:%02d", hour, minute)

    val decimalHour: Float
        get() = hour + (minute / 60.0f) + (second / 3600.0f)

    val currentPhase: DayNightPhase
        get() = DayNightPhase.fromHour(decimalHour)
}

/**
 * Real-time Environmental Snapshot
 */
data class EnvironmentSnapshot(
    val weatherType: WeatherType = WeatherType.CLEAR,
    val transitionProgress: Float = 1.0f, // 0.0 (transitioning) to 1.0 (settled)
    val rainIntensity: Float = 0.0f,
    val wetRoadFactor: Float = 0.0f,
    val puddleCoverage: Float = 0.0f,
    val fogDensity: Float = 0.0f,
    val visibilityMeters: Float = 5000f,
    val windSpeedKmh: Float = 15f,
    val windBearingDegrees: Float = 225f, // SW coastal monsoon wind
    val cloudCover: Float = 0.2f,
    val lightningActive: Boolean = false,
    val lightningFlashIntensity: Float = 0.0f,
    val ambientTempCelsius: Float = 34f,
    val humidityPercentage: Float = 72f,
    val waveHeightMeters: Float = 0.8f,
    val streetLightsActive: Boolean = false,
    val buildingWindowLitPercentage: Float = 45f
)

/**
 * Pedestrian AI State & Data
 */
enum class PedestrianActionState(val displayName: String, val isPanicked: Boolean) {
    IDLE("Idle / Waiting", false),
    WALKING("Walking Along Pavement", false),
    RUNNING("Jogging / In Hurry", false),
    SHOPPING("Browsing Bazaar Stall", false),
    EATING("Eating Street Chai / Biryani", false),
    TALKING("Conversing in Roman Urdu", false),
    WORKING("Dockland / Mechanic Work", false),
    DRIVING("Operating Rickshaw / Car", false),
    WAITING("Waiting for Bus / Chingchi", false),
    USING_PHONE("Browsing Mobile / Calling", false),
    RELAXING("Resting at Sea View Bench", false),
    GOING_HOME("Commuting Back Home", false),
    SEEKING_SHELTER("Seeking Rain Canopy Shelter", false),
    FLEEING("Fleeing Gunfire in Terror", true),
    INVESTIGATING("Looking at Accident", false),
    REACTING_TO_CRIME("Hands Raised / Surrendering", true)
}

data class PedestrianAgent(
    val id: String,
    val name: String,
    val districtId: String,
    val worldPosX: Float,
    val worldPosY: Float,
    val state: PedestrianActionState,
    val dialogueSnippet: String,
    val hasUmbrella: Boolean,
    val outfitStyle: String, // Traditional Shalwar Kameez, Western Jeans, Formal Office, Dock Worker
    val fearLevel: Float = 0.0f, // 0.0 (calm) to 1.0 (hysteria)
    val perceptionDistanceMeters: Float = 35f,
    val lodLevel: Int = 0 // 0=Near (full physics), 1=Med, 2=Far
)

/**
 * Traffic AI Vehicle & Lane State
 */
enum class TrafficLightState(val label: String, val colorHex: Long) {
    GREEN("Green (Go)", 0xFF00E676),
    YELLOW("Yellow (Caution)", 0xFFFFD600),
    RED("Red (Stop)", 0xFFFF1744),
    EMERGENCY_CLEAR("Priority Emergency Flashing", 0xFF00B0FF)
}

enum class TrafficVehicleType(
    val title: String,
    val defaultSpeedKmh: Float,
    val maxPassengers: Int
) {
    CHINGCHI_RICKSHAW("Qingqi / Auto-Rickshaw", 38f, 6),
    YELLOW_CAB("Karachi Yellow Taxi", 48f, 4),
    METRO_W11_BUS("W-11 Decorated Minibus", 42f, 35),
    SUZUKI_BOLAN_HIROOF("Suzuki Bolan Van", 45f, 8),
    COROLLA_SEDAN("Executive Sedan", 55f, 4),
    HEAVY_BEDFORD_TRUCK("Bedford Floral Cargo Truck", 35f, 2),
    HONDA_125_BIKE("Honda CD 70 / 125 Bike", 50f, 2),
    EDHI_AMBULANCE("Edhi Emergency Ambulance", 75f, 3),
    POLICE_MOBILE("Sindh Police Mobile", 70f, 4)
}

data class TrafficVehicleAgent(
    val id: String,
    val type: TrafficVehicleType,
    val laneName: String,
    val currentSpeedKmh: Float,
    val targetSpeedKmh: Float,
    val isBraking: Boolean,
    val isYieldingToEmergency: Boolean,
    val headlightsOn: Boolean,
    val indicatorsLeft: Boolean,
    val indicatorsRight: Boolean,
    val distanceToFrontVehicleMeters: Float,
    val lodLevel: Int = 0
)

/**
 * Wildlife in Karachi Metro
 */
enum class WildlifeSpecies(
    val commonName: String,
    val habitat: String,
    val canFly: Boolean
) {
    SEAGULL("Arabian Coastal Seagull", "Clifton Beach & Kemari Port", true),
    STRAY_CAT("Karachi Street Alley Cat", "Residential Bazaars & Saddar", false),
    STRAY_DOG("Territorial Desi Dog", "Industrial Docks & Orangi Ridge", false),
    ROCK_PIGEON("City Square Pigeon", "Downtown Towers & Market Plazas", true),
    SEA_TURTLE("Green Sea Turtle", "Hawke's Bay & Sandspit Coast", false),
    MANGROVE_FISH("Mudskipper & Inshore Fish", "Kemari Creek & Mangrove Swamps", false)
}

data class WildlifeAgent(
    val id: String,
    val species: WildlifeSpecies,
    val worldPosX: Float,
    val worldPosY: Float,
    val behaviorState: String, // Feeding, Perched, Soaring, Scavenging, Resting, Fleeing
    val reactionToHuman: String
)

/**
 * Dynamic World Events occurring outside of missions
 */
enum class WorldEventCategory {
    ACCIDENT,
    CRIME_PURSUIT,
    STREET_DISPUTE,
    CIVIL_EMERGENCY,
    ENVIRONMENTAL_HAZARD,
    VIP_ESCORT
}

data class DynamicWorldEvent(
    val id: String,
    val title: String,
    val category: WorldEventCategory,
    val districtName: String,
    val description: String,
    val romanUrduAmbientCall: String,
    val severityLevel: Int, // 1 to 5
    val policeInvolved: Boolean,
    val trafficRerouting: Boolean,
    val playerRewardCashPkr: Int,
    val coordinates: Pair<Float, Float>,
    val isActive: Boolean = true
)

/**
 * Simulation Level of Detail (LOD) Metrics
 */
data class SimulationLODMetrics(
    val level0NearCount: Int, // Full mesh + full physics (<50m)
    val level1MediumCount: Int, // Simplified behavior (50-250m)
    val level2FarCount: Int, // Statistical approximation (250-1000m)
    val level3BackgroundCount: Int, // State only (>1000m)
    val totalActivePedestrians: Int,
    val totalActiveVehicles: Int,
    val activeWildlifeCount: Int,
    val currentFpsTarget: Int = 60,
    val simulationTickTimeMs: Float = 2.1f
)
