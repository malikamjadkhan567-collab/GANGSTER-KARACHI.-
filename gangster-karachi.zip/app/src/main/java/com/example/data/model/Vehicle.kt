package com.example.data.model

enum class VehicleCategory(val displayName: String) {
    SPORTS("Sports & Tuners"),
    SUPERCAR("Exotics & Hypercars"),
    MUSCLE("Muscle & High Torque"),
    SUV("SUVs & 4x4 Off-Road"),
    PICKUP("Pickups & Heavy Duty"),
    MOTORCYCLE("Motorcycles & Scooters"),
    BOAT("Marine & Boats"),
    AIRCRAFT("Helicopters & Aircraft"),
    CIVILIAN("Civilian & Transit"),
    EMERGENCY("Emergency & Police")
}

enum class Drivetrain(val label: String) {
    FWD("Front-Wheel Drive"),
    RWD("Rear-Wheel Drive"),
    AWD("All-Wheel Drive"),
    FOUR_BY_FOUR("4x4 High/Low Transfer"),
    WATER_JET("Marine Impeller / Propeller"),
    AERO_ROTOR("Helicopter Turboshaft Rotor")
}

enum class RoadSurface(val label: String, val gripFactor: Float, val dragFactor: Float) {
    DRY_ASPHALT("Dry Asphalt (Karachi Highways)", 1.0f, 1.0f),
    WET_ASPHALT("Wet Rain Asphalt (Reduced Traction)", 0.65f, 1.15f),
    BEACH_SAND("Beach Sand (Ocean Drive Sea View)", 0.50f, 1.45f),
    DIRT_GRAVEL("Dirt & Gravel (Northern Hills / Greenbelt)", 0.60f, 1.25f),
    MUD_COASTAL("Coastal Mud & Inlets (Fishing Village)", 0.40f, 1.60f),
    WATER_OPEN("Open Sea Surface (Arabian Sea)", 0.85f, 1.30f)
}

enum class PaintFinish(val label: String) {
    GLOSS("High-Gloss Clearcoat"),
    METALLIC("Metallic Flake"),
    MATTE("Matte Stealth"),
    SATIN("Satin Pearl"),
    CHROME("Reflective Chrome")
}

data class VehiclePhysicsSpecs(
    val massKg: Float,
    val horsepower: Int,
    val torqueNm: Int,
    val topSpeedKmh: Int,
    val acceleration0To100: Float, // seconds
    val brakeForceKn: Float,
    val gearCount: Int,
    val drivetrain: Drivetrain,
    val dragCoefficient: Float,
    val suspensionTravelCm: Float,
    val suspensionStiffness: Float,
    val baseTireGrip: Float,
    val steeringAngleDeg: Float
)

data class VehicleDamageModel(
    var bodyScratchPct: Float = 0f,
    var bodyDentPct: Float = 0f,
    var glassCracked: Boolean = false,
    var engineHealthPct: Float = 100f,
    var transmissionHealthPct: Float = 100f,
    var brakeHealthPct: Float = 100f,
    var leftHeadlightWorking: Boolean = true,
    var rightHeadlightWorking: Boolean = true,
    var tireBlowoutFrontLeft: Boolean = false,
    var tireBlowoutFrontRight: Boolean = false,
    var tireBlowoutRearLeft: Boolean = false,
    var tireBlowoutRearRight: Boolean = false
)

data class VehicleCustomization(
    var paintColorHex: Long = 0xFFFFB800,
    var finish: PaintFinish = PaintFinish.METALLIC,
    var windowTintPct: Int = 30,
    var spoilerStage: Int = 0, // 0 = None, 1 = Lip, 2 = GT Wing, 3 = Carbon Fiber
    var wheelStyleIndex: Int = 0,
    var engineTuneStage: Int = 0, // 0 = Stock, 1 = ECU Remap, 2 = Forged Internals, 3 = Twin Turbo
    var turboInstalled: Boolean = false,
    var sportSuspension: Boolean = false,
    var raceBrakes: Boolean = false,
    var sportTires: Boolean = false,
    var armorPlating: Boolean = false,
    var underglowColorHex: Long? = null
)

data class VehicleEconomyData(
    val purchasePricePkr: Long,
    val sellPricePkr: Long,
    val repairBaseCostPkr: Long,
    val insuranceCostPkr: Long,
    val rarityTier: String // COMMON, STREET, EXOTIC, BLACK_MARKET
)

data class Vehicle(
    val id: String,
    val name: String,
    val manufacturer: String,
    val category: VehicleCategory,
    val categorySubtitle: String,
    val description: String,
    val protagonistAffinity: String, // "Ayan Khan", "Shahroz Malik", "Daniyal Qureshi", or "Universal"
    val defaultDistrictSpawn: String,
    val physics: VehiclePhysicsSpecs,
    val damage: VehicleDamageModel = VehicleDamageModel(),
    var customization: VehicleCustomization = VehicleCustomization(),
    val economy: VehicleEconomyData,
    val interiorDetail: String,
    val audioProfile: String,
    val isHeroVehicle: Boolean = false
)
