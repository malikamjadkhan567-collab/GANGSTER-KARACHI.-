package com.example.data.model

object UE5ArchitectureData {

    val karachiTypesHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiMetroWorld / Public / KarachiTypes.h
// Description: Core USTRUCT and UENUM definitions for World Foundation
// Engine Target: Unreal Engine 5.4+ (Nanite + Lumen + World Partition)
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "KarachiTypes.generated.h"

UENUM(BlueprintType)
enum class EKarachiBiomeType : uint8
{
    Coastal UMETA(DisplayName = "Coastal Shore & Marina"),
    LuxurySuburb UMETA(DisplayName = "Luxury Gated Suburb"),
    CoastalSkyline UMETA(DisplayName = "Coastal High-Rise Skyline"),
    DenseUrban UMETA(DisplayName = "Dense Commercial & Transit"),
    MarketBazaar UMETA(DisplayName = "High-Density Traditional Bazaar"),
    OldTown UMETA(DisplayName = "Heritage Masonry & Colonial"),
    WorkingClass UMETA(DisplayName = "Dense Working-Class Residential"),
    HillsideUrban UMETA(DisplayName = "Hillside Informal Urban"),
    HeavyIndustrial UMETA(DisplayName = "Heavy Industrial & Manufacturing"),
    PortDocklands UMETA(DisplayName = "Deepwater Cargo Port"),
    AirportTransit UMETA(DisplayName = "International Airport Hub"),
    MountainHighlands UMETA(DisplayName = "Mountain Ridge & Switchbacks"),
    NatureReserve UMETA(DisplayName = "Greenbelt Nature Reserve"),
    FishingSettlement UMETA(DisplayName = "Rustic Coastal Stilt Village")
};

UENUM(BlueprintType)
enum class EInteriorTier : uint8
{
    Tier1_Hero UMETA(DisplayName = "Tier 1 — Hero Interior (Fully Detailed)"),
    Tier2_Gameplay UMETA(DisplayName = "Tier 2 — Gameplay Interior (Functional Modular)"),
    Tier3_Background UMETA(DisplayName = "Tier 3 — Exterior Only (Parallax Cubemaps)")
};

UENUM(BlueprintType)
enum class EProtagonistID : uint8
{
    Ayan UMETA(DisplayName = "Ayan Khan (Lyari / Saddar)"),
    Shahroz UMETA(DisplayName = "Shahroz Malik (Port / Industrial)"),
    Daniyal UMETA(DisplayName = "Daniyal Qureshi (Defence / Clifton)")
};

USTRUCT(BlueprintType)
struct KARACHIMETROWORLD_API FDistrictData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "District Metadata")
    FName DistrictID;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "District Metadata")
    FText DisplayName;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "District Metadata")
    EKarachiBiomeType Biome;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Demographics")
    float PopulationDensityScalar; // 0.0 - 1.0 for World AI Spawner

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Demographics")
    float TrafficDensityScalar;    // 0.0 - 1.0 for Future Vehicle AI (Prompt 02)

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Architecture")
    FString ArchitectureStyle;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Security")
    int32 PoliceSecurityTier;      // 0 = Low, 4 = Garrisoned

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Environment")
    FVector2D WorldCenterCoord;     // In UE5 World Coordinate cm

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Environment")
    float DistrictRadiusCm;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "World Partition")
    FName PrimaryDataLayer;
};

USTRUCT(BlueprintType)
struct KARACHIMETROWORLD_API FProtagonistSpawnPoint
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn")
    EProtagonistID Protagonist;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn")
    FTransform SafehouseTransform;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn")
    FName DistrictID;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn")
    EInteriorTier SafehouseInteriorTier;
};
""".trimIndent()

    val karachiWorldSubsystemHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiMetroWorld / Public / KarachiWorldSubsystem.h
// Description: UWorldSubsystem orchestrating World Partition, streaming, and districts
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "KarachiTypes.h"
#include "KarachiWorldSubsystem.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnDistrictChangedSignature, FName, NewDistrictID, FName, PreviousDistrictID);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnProtagonistSpawnedSignature, EProtagonistID, ActiveProtagonist);

UCLASS()
class KARACHIMETROWORLD_API UKarachiWorldSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    UKarachiWorldSubsystem();

    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    virtual void Deinitialize() override;

    // District Queries
    UFUNCTION(BlueprintCallable, Category = "Karachi World|Districts")
    bool GetDistrictData(FName DistrictID, FDistrictData& OutData) const;

    UFUNCTION(BlueprintCallable, Category = "Karachi World|Districts")
    FName GetDistrictAtLocation(const FVector& WorldLocation) const;

    // Protagonist Starting Systems
    UFUNCTION(BlueprintCallable, Category = "Karachi World|Protagonists")
    bool SpawnProtagonistAtSafehouse(EProtagonistID Protagonist);

    // Dynamic Time of Day / Lumen Lighting Profile Hooks
    UFUNCTION(BlueprintCallable, Category = "Karachi World|Lighting")
    void SetWorldTimeOfDay(float NormalizedTimeOfDay); // 0.0 - 1.0 (24h)

    UPROPERTY(BlueprintAssignable, Category = "Karachi World|Events")
    FOnDistrictChangedSignature OnDistrictChanged;

    UPROPERTY(BlueprintAssignable, Category = "Karachi World|Events")
    FOnProtagonistSpawnedSignature OnProtagonistSpawned;

private:
    UPROPERTY()
    TMap<FName, FDistrictData> RegisteredDistricts;

    UPROPERTY()
    TMap<EProtagonistID, FProtagonistSpawnPoint> ProtagonistSpawns;

    FName CurrentPlayerDistrict;
    void RegisterDefaultDistricts();
    void SetupProtagonistSpawns();
};
""".trimIndent()

    val karachiWorldSubsystemCpp = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiMetroWorld / Private / KarachiWorldSubsystem.cpp
// Implementation of UKarachiWorldSubsystem
// ==============================================================================

#include "KarachiWorldSubsystem.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"

UKarachiWorldSubsystem::UKarachiWorldSubsystem()
{
}

void UKarachiWorldSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
    Super::Initialize(Collection);
    RegisterDefaultDistricts();
    SetupProtagonistSpawns();
    UE_LOG(LogTemp, Log, TEXT("[Gangster Karachi] KarachiWorldSubsystem initialized. Registered 15 districts."));
}

void UKarachiWorldSubsystem::Deinitialize()
{
    RegisteredDistricts.Empty();
    ProtagonistSpawns.Empty();
    Super::Deinitialize();
}

void UKarachiWorldSubsystem::RegisterDefaultDistricts()
{
    // Populates 15 seamless Karachi Metro districts with World Partition coords
    auto AddDistrict = [this](FName ID, const TCHAR* Name, EKarachiBiomeType Biome, float Pop, float Traf, FVector2D Center, float Radius)
    {
        FDistrictData D;
        D.DistrictID = ID;
        D.DisplayName = FText::FromString(Name);
        D.Biome = Biome;
        D.PopulationDensityScalar = Pop;
        D.TrafficDensityScalar = Traf;
        D.WorldCenterCoord = Center;
        D.DistrictRadiusCm = Radius;
        D.PrimaryDataLayer = FName(*FString::Printf(TEXT("DataLayer_%s"), *ID.ToString()));
        RegisteredDistricts.Add(ID, D);
    };

    AddDistrict(TEXT("downtown"), TEXT("Downtown"), EKarachiBiomeType::DenseUrban, 0.95f, 0.98f, FVector2D(520000.f, 440000.f), 120000.f);
    AddDistrict(TEXT("defence_gardens"), TEXT("Defence Gardens"), EKarachiBiomeType::LuxurySuburb, 0.40f, 0.45f, FVector2D(680000.f, 580000.f), 140000.f);
    AddDistrict(TEXT("clifton_heights"), TEXT("Clifton Heights"), EKarachiBiomeType::CoastalSkyline, 0.75f, 0.70f, FVector2D(480000.f, 660000.f), 110000.f);
    AddDistrict(TEXT("ocean_drive"), TEXT("Ocean Drive"), EKarachiBiomeType::Coastal, 0.85f, 0.80f, FVector2D(380000.f, 780000.f), 160000.f);
    AddDistrict(TEXT("saddar_central"), TEXT("Saddar Central"), EKarachiBiomeType::DenseUrban, 1.00f, 1.00f, FVector2D(440000.f, 420000.f), 90000.f);
    AddDistrict(TEXT("tariq_bazaar"), TEXT("Tariq Bazaar"), EKarachiBiomeType::MarketBazaar, 0.90f, 0.85f, FVector2D(580000.f, 480000.f), 80000.f);
    AddDistrict(TEXT("old_town"), TEXT("Old Town"), EKarachiBiomeType::OldTown, 0.80f, 0.60f, FVector2D(360000.f, 460000.f), 85000.f);
    AddDistrict(TEXT("lyari_blocks"), TEXT("Lyari Blocks"), EKarachiBiomeType::WorkingClass, 1.00f, 0.75f, FVector2D(320000.f, 380000.f), 95000.f);
    AddDistrict(TEXT("orangi_district"), TEXT("Orangi District"), EKarachiBiomeType::HillsideUrban, 0.95f, 0.70f, FVector2D(280000.f, 240000.f), 120000.f);
    AddDistrict(TEXT("industrial_zone"), TEXT("Industrial Zone"), EKarachiBiomeType::HeavyIndustrial, 0.30f, 0.90f, FVector2D(220000.f, 540000.f), 130000.f);
    AddDistrict(TEXT("port_district"), TEXT("Port District"), EKarachiBiomeType::PortDocklands, 0.25f, 0.85f, FVector2D(160000.f, 680000.f), 150000.f);
    AddDistrict(TEXT("metro_airport"), TEXT("Metro Airport"), EKarachiBiomeType::AirportTransit, 0.65f, 0.75f, FVector2D(760000.f, 320000.f), 150000.f);
    AddDistrict(TEXT("northern_hills"), TEXT("Northern Hills"), EKarachiBiomeType::MountainHighlands, 0.15f, 0.20f, FVector2D(460000.f, 120000.f), 180000.f);
    AddDistrict(TEXT("greenbelt"), TEXT("Greenbelt"), EKarachiBiomeType::NatureReserve, 0.10f, 0.10f, FVector2D(720000.f, 180000.f), 140000.f);
    AddDistrict(TEXT("fishing_village"), TEXT("Fishing Village"), EKarachiBiomeType::FishingSettlement, 0.20f, 0.15f, FVector2D(120000.f, 820000.f), 90000.f);
}

void UKarachiWorldSubsystem::SetupProtagonistSpawns()
{
    // Ayan starting point (Lyari Blocks rooftop flat)
    FProtagonistSpawnPoint SpawnAyan;
    SpawnAyan.Protagonist = EProtagonistID::Ayan;
    SpawnAyan.DistrictID = TEXT("lyari_blocks");
    SpawnAyan.SafehouseTransform = FTransform(FRotator(0.f, 45.f, 0.f), FVector(310000.f, 390000.f, 1800.f));
    SpawnAyan.SafehouseInteriorTier = EInteriorTier::Tier1_Hero;
    ProtagonistSpawns.Add(EProtagonistID::Ayan, SpawnAyan);

    // Shahroz starting point (Port District salvage yard)
    FProtagonistSpawnPoint SpawnShahroz;
    SpawnShahroz.Protagonist = EProtagonistID::Shahroz;
    SpawnShahroz.DistrictID = TEXT("port_district");
    SpawnShahroz.SafehouseTransform = FTransform(FRotator(0.f, 180.f, 0.f), FVector(170000.f, 670000.f, 250.f));
    SpawnShahroz.SafehouseInteriorTier = EInteriorTier::Tier1_Hero;
    ProtagonistSpawns.Add(EProtagonistID::Shahroz, SpawnShahroz);

    // Daniyal starting point (Defence Gardens luxury villa)
    FProtagonistSpawnPoint SpawnDaniyal;
    SpawnDaniyal.Protagonist = EProtagonistID::Daniyal;
    SpawnDaniyal.DistrictID = TEXT("defence_gardens");
    SpawnDaniyal.SafehouseTransform = FTransform(FRotator(0.f, 90.f, 0.f), FVector(700000.f, 600000.f, 600.f));
    SpawnDaniyal.SafehouseInteriorTier = EInteriorTier::Tier1_Hero;
    ProtagonistSpawns.Add(EProtagonistID::Daniyal, SpawnDaniyal);
}

bool UKarachiWorldSubsystem::GetDistrictData(FName DistrictID, FDistrictData& OutData) const
{
    if (const FDistrictData* Found = RegisteredDistricts.Find(DistrictID))
    {
        OutData = *Found;
        return true;
    }
    return false;
}

FName UKarachiWorldSubsystem::GetDistrictAtLocation(const FVector& WorldLocation) const
{
    const FVector2D Loc2D(WorldLocation.X, WorldLocation.Y);
    for (const auto& Pair : RegisteredDistricts)
    {
        if (FVector2D::DistSquared(Loc2D, Pair.Value.WorldCenterCoord) <= FMath::Square(Pair.Value.DistrictRadiusCm))
        {
            return Pair.Key;
        }
    }
    return TEXT("outer_highway");
}

bool UKarachiWorldSubsystem::SpawnProtagonistAtSafehouse(EProtagonistID Protagonist)
{
    if (const FProtagonistSpawnPoint* Spawn = ProtagonistSpawns.Find(Protagonist))
    {
        APawn* PlayerPawn = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);
        if (PlayerPawn)
        {
            PlayerPawn->SetActorTransform(Spawn->SafehouseTransform, false, nullptr, ETeleportType::TeleportPhysics);
            OnProtagonistSpawned.Broadcast(Protagonist);
            return true;
        }
    }
    return false;
}

void UKarachiWorldSubsystem::SetWorldTimeOfDay(float NormalizedTimeOfDay)
{
    // Hooks into Lumen PostProcess and DirectionalLight Sun angle
    // In production, drives SkyAtmosphere, DirectionalLight and Lumen Indirect Bounce
}
""".trimIndent()
}
