package com.example.data.model

enum class WantedLevel(val stars: Int, val title: String, val policeResponseDesc: String) {
    LEVEL_0(0, "Clear Record", "No active police pursuit or warrants."),
    LEVEL_1(1, "Local Response", "1–2 nearby foot patrol and municipal beat officers investigate incident area."),
    LEVEL_2(2, "Active Pursuit", "Multiple patrol cruisers dispatched, siren units establish visual and pursuit."),
    LEVEL_3(3, "City Response", "High patrol density, tactical highway roadblocks, coordinated perimeter search."),
    LEVEL_4(4, "Special Response", "Armored tactical SWAT units deployed, road spike strips, helicopter air support en-route."),
    LEVEL_5(5, "Maximum Response", "Full metropolitan emergency lockdown, dual air support, elite marksmen, lethal force authorization.")
}

enum class CrimeType(val label: String, val baseHeatIncrease: Float, val starThreshold: Int) {
    VEHICLE_THEFT("Grand Vehicle Theft", 15f, 1),
    ASSAULT_CIVILIAN("Civilian Street Assault", 10f, 1),
    WEAPON_DISCHARGE("Illegal Firearm Discharge", 20f, 1),
    OFFICER_ATTACK("Assault on Law Enforcement Officer", 45f, 2),
    OFFICER_DOWN("Officer Down / Severe Tactical Threat", 80f, 3),
    RESTRICTED_ENTRY("Military / Bank Vault Trespass", 35f, 2),
    EXPLOSION_ATTACK("Public Explosive Ordnance Detonation", 100f, 4)
}

enum class PoliceSearchPhase {
    ALL_CLEAR,            // Pursuit completely called off / clear record
    IN_SIGHT,             // Police maintain direct visual line-of-sight
    LOST_SIGHT_LKP,       // Visual lost; units rushing to Last Known Position
    EXPANDING_GRID_SEARCH,// Establishing radius search around LKP
    DECAY_COOLDOWN,       // Search expiring; radar flashing yellow
    EVADED                // Pursuit completely called off
}

data class CrimeEvent(
    val id: String,
    val type: CrimeType,
    val districtId: String,
    val posX: Float,
    val posY: Float,
    val witnessesPresent: Boolean,
    val reportedToDispatch: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)

enum class PoliceUnitType(val displayName: String, val maxSpeedKmh: Float) {
    FOOT_OFFICER("Metro Beat Officer", 22f),
    PATROL_CRUISER("Pursuit Patrol Sedan", 210f),
    MOTORCYCLE_UNIT("Police Interceptor 750", 230f),
    SWAT_VAN("Armored Tactical Tactical Van", 160f),
    POLICE_HELICOPTER("Metro Air Support Sky-Hawk", 270f)
}

data class PoliceUnitInstance(
    val id: String,
    val type: PoliceUnitType,
    val callsign: String,
    var posX: Float,
    var posY: Float,
    var state: String = "PATROL" // PATROL, RESPONDING, PURSUIT, SEARCHING
)

enum class EnemyArchetype(val title: String, val combatStyle: String) {
    STREET_FIGHTER("Lyari Street Fighter", "Aggressive close-quarters rush, pistol hip-fire and vicious melee counters."),
    DEFENSIVE_GUARD("Cantonment Security Guard", "Holds fortified choke points, utilizes low/high cover, calls for backup."),
    TACTICAL_OPERATOR("Syndicate Tactical Operator", "Suppressive automatic fire, coordinated flanking maneuvers, smoke throwables."),
    HEAVY_ENFORCER("Docklands Heavy Enforcer", "High armor ballistic vest, slow unrelenting advance with 12-gauge shotgun or LMG.")
}

data class EnemyCombatTarget(
    val id: String,
    val name: String,
    val archetype: EnemyArchetype,
    var health: Float = 100f,
    var maxHealth: Float = 100f,
    var armor: Float = 50f,
    var isAlive: Boolean = true,
    var isAlerted: Boolean = false,
    var posX: Float = 0.5f,
    var posY: Float = 0.5f
)

data class RadioDispatchTransmission(
    val id: String,
    val timestampMs: Long,
    val senderCallsign: String,
    val messageText: String,
    val priorityLevel: Int
)
