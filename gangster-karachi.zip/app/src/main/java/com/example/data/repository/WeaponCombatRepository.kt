package com.example.data.repository

import com.example.data.local.SavedWeaponEntity
import com.example.data.local.WorldDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlin.math.*

class WeaponCombatRepository(private val worldDao: WorldDao) {

    val allWeapons: List<Weapon> = listOf(
        // PISTOLS
        Weapon(
            id = "wep_pk9_viper",
            name = "PK-9 Viper Compact",
            manufacturer = "Karachi Arms Labs",
            category = WeaponCategory.PISTOL,
            defaultSlot = WeaponSlot.SECONDARY,
            firingMode = FiringMode.SEMI_AUTO,
            baseDamage = 34f,
            effectiveRangeMeters = 35f,
            fireRateRpm = 450,
            magazineCapacity = 15,
            reloadTimeSec = 1.4f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 1.8f, horizontalDriftDeg = 0.5f, recoverySpeed = 8.5f, bloomSpreadDeg = 1.2f),
            ammoType = AmmoType.AMMO_9MM,
            weightKg = 0.85f,
            rarityTier = "STREET",
            description = "A compact polymer-frame 9mm handgun designed for concealed urban carry in Lyari alleyways. Swift draw time and snappy recovery.",
            protagonistAffinity = "Ayan Khan"
        ),
        Weapon(
            id = "wep_indus_p17",
            name = "Indus P-17 Service",
            manufacturer = "Indus Defense Industries",
            category = WeaponCategory.PISTOL,
            defaultSlot = WeaponSlot.SECONDARY,
            firingMode = FiringMode.SEMI_AUTO,
            baseDamage = 38f,
            effectiveRangeMeters = 50f,
            fireRateRpm = 400,
            magazineCapacity = 17,
            reloadTimeSec = 1.6f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 2.0f, horizontalDriftDeg = 0.4f, recoverySpeed = 9.0f, bloomSpreadDeg = 1.0f),
            ammoType = AmmoType.AMMO_9MM,
            weightKg = 0.95f,
            rarityTier = "MILITARY",
            description = "Standard issue service sidearm of the Metro Police Department. Renowned for unjamming reliability under salty coastal air.",
            protagonistAffinity = "Universal"
        ),
        Weapon(
            id = "wep_khyber_magnum",
            name = "Khyber Magnum .44",
            manufacturer = "Khyber Ordnance Works",
            category = WeaponCategory.PISTOL,
            defaultSlot = WeaponSlot.SECONDARY,
            firingMode = FiringMode.SEMI_AUTO,
            baseDamage = 78f,
            effectiveRangeMeters = 60f,
            fireRateRpm = 180,
            magazineCapacity = 6,
            reloadTimeSec = 2.4f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 6.5f, horizontalDriftDeg = 1.8f, recoverySpeed = 5.0f, bloomSpreadDeg = 2.4f),
            ammoType = AmmoType.AMMO_44MAG,
            weightKg = 1.45f,
            rarityTier = "BLACK_MARKET",
            description = "Heavy stainless-steel hand cannon chambered in .44 Magnum. Extreme kinetic knockdown capable of cracking vehicle engine blocks.",
            protagonistAffinity = "Shahroz Malik"
        ),

        // SUBMACHINE GUNS
        Weapon(
            id = "wep_lyari_striker",
            name = "Lyari Striker 9",
            manufacturer = "Underground Custom Machinists",
            category = WeaponCategory.SMG,
            defaultSlot = WeaponSlot.SECONDARY,
            firingMode = FiringMode.FULL_AUTO,
            baseDamage = 28f,
            effectiveRangeMeters = 45f,
            fireRateRpm = 950,
            magazineCapacity = 32,
            reloadTimeSec = 1.8f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 1.6f, horizontalDriftDeg = 0.9f, recoverySpeed = 11.0f, bloomSpreadDeg = 1.8f),
            ammoType = AmmoType.AMMO_9MM,
            weightKg = 2.1f,
            rarityTier = "STREET",
            description = "A rapid-cycling 9mm SMG favored by Ayan for high-speed hit-and-run tactics and vehicle drive-by engagements.",
            protagonistAffinity = "Ayan Khan"
        ),
        Weapon(
            id = "wep_karachi_mptac",
            name = "Karachi MP-Tac Suppressed",
            manufacturer = "Karachi Arms Labs",
            category = WeaponCategory.SMG,
            defaultSlot = WeaponSlot.PRIMARY,
            firingMode = FiringMode.FULL_AUTO,
            baseDamage = 32f,
            effectiveRangeMeters = 70f,
            fireRateRpm = 800,
            magazineCapacity = 30,
            reloadTimeSec = 1.9f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 1.3f, horizontalDriftDeg = 0.4f, recoverySpeed = 12.0f, bloomSpreadDeg = 0.9f),
            ammoType = AmmoType.AMMO_9MM,
            weightKg = 2.6f,
            rarityTier = "MILITARY",
            description = "Internally suppressed tactical submachine gun. Delivers whisper-quiet covert neutralization during infiltration contracts.",
            protagonistAffinity = "Daniyal Qureshi"
        ),

        // ASSAULT RIFLES
        Weapon(
            id = "wep_bolan_ak74",
            name = "Bolan AK-74M Heavy",
            manufacturer = "Bolan Heavy Works",
            category = WeaponCategory.ASSAULT_RIFLE,
            defaultSlot = WeaponSlot.PRIMARY,
            firingMode = FiringMode.FULL_AUTO,
            baseDamage = 56f,
            effectiveRangeMeters = 160f,
            fireRateRpm = 650,
            magazineCapacity = 30,
            reloadTimeSec = 2.2f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 3.4f, horizontalDriftDeg = 1.2f, recoverySpeed = 7.0f, bloomSpreadDeg = 2.1f),
            ammoType = AmmoType.AMMO_762SOVIET,
            weightKg = 3.6f,
            rarityTier = "MILITARY",
            description = "Shahroz's battle-tested automatic rifle. Crushing penetration through barricades and light vehicle doors in the Industrial Zone.",
            protagonistAffinity = "Shahroz Malik"
        ),
        Weapon(
            id = "wep_sultan_m4",
            name = "Sultan M4 Carbine Spec-Ops",
            manufacturer = "Sultan Defense Corp",
            category = WeaponCategory.ASSAULT_RIFLE,
            defaultSlot = WeaponSlot.PRIMARY,
            firingMode = FiringMode.FULL_AUTO,
            baseDamage = 46f,
            effectiveRangeMeters = 180f,
            fireRateRpm = 780,
            magazineCapacity = 30,
            reloadTimeSec = 2.0f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 2.2f, horizontalDriftDeg = 0.6f, recoverySpeed = 9.5f, bloomSpreadDeg = 1.3f),
            ammoType = AmmoType.AMMO_556NATO,
            weightKg = 3.2f,
            rarityTier = "MILITARY",
            description = "Versatile 5.56mm assault carbine featuring quad Picatinny rails for optics, laser designators, and angled foregrips.",
            protagonistAffinity = "Universal"
        ),
        Weapon(
            id = "wep_sindh_tar21",
            name = "Sindh TAR-21 Tactical Bullpup",
            manufacturer = "Cantonment Armory",
            category = WeaponCategory.ASSAULT_RIFLE,
            defaultSlot = WeaponSlot.PRIMARY,
            firingMode = FiringMode.BURST_3,
            baseDamage = 50f,
            effectiveRangeMeters = 200f,
            fireRateRpm = 750,
            magazineCapacity = 30,
            reloadTimeSec = 2.1f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 1.9f, horizontalDriftDeg = 0.5f, recoverySpeed = 10.5f, bloomSpreadDeg = 0.9f),
            ammoType = AmmoType.AMMO_556NATO,
            weightKg = 3.4f,
            rarityTier = "BLACK_MARKET",
            description = "Compact bullpup configuration offering exceptional mid-range precision and rapid cornering in tight Defence Gardens estates.",
            protagonistAffinity = "Daniyal Qureshi"
        ),

        // SHOTGUNS
        Weapon(
            id = "wep_shera_12g",
            name = "Shera 12G Enforcer Pump",
            manufacturer = "Bolan Heavy Works",
            category = WeaponCategory.SHOTGUN,
            defaultSlot = WeaponSlot.PRIMARY,
            firingMode = FiringMode.PUMP_ACTION,
            baseDamage = 110f,
            effectiveRangeMeters = 22f,
            fireRateRpm = 70,
            magazineCapacity = 8,
            reloadTimeSec = 3.5f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 7.5f, horizontalDriftDeg = 1.5f, recoverySpeed = 4.0f, bloomSpreadDeg = 5.0f),
            ammoType = AmmoType.AMMO_12GAUGE,
            weightKg = 3.5f,
            rarityTier = "STREET",
            description = "Short-barreled tactical pump shotgun with door-breaching muzzle brake. Uncontested devastating point-blank stopping power.",
            protagonistAffinity = "Shahroz Malik"
        ),
        Weapon(
            id = "wep_orangi_riot12",
            name = "Orangi Riot-12 Auto Shotgun",
            manufacturer = "Orangi Workshop Syndicate",
            category = WeaponCategory.SHOTGUN,
            defaultSlot = WeaponSlot.PRIMARY,
            firingMode = FiringMode.FULL_AUTO,
            baseDamage = 92f,
            effectiveRangeMeters = 28f,
            fireRateRpm = 240,
            magazineCapacity = 10,
            reloadTimeSec = 2.8f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 5.8f, horizontalDriftDeg = 2.0f, recoverySpeed = 6.0f, bloomSpreadDeg = 4.2f),
            ammoType = AmmoType.AMMO_12GAUGE,
            weightKg = 4.2f,
            rarityTier = "BLACK_MARKET",
            description = "Semi-automatic gas-operated shotgun equipped with a 10-round detachable box magazine for overwhelming crowd clearing.",
            protagonistAffinity = "Universal"
        ),

        // MARKSMAN & SNIPER RIFLES
        Weapon(
            id = "wep_margalla_308",
            name = "Margalla Hunter .308",
            manufacturer = "Northern Highland Rifles",
            category = WeaponCategory.MARKSMAN_SNIPER,
            defaultSlot = WeaponSlot.PRIMARY,
            firingMode = FiringMode.BOLT_ACTION,
            baseDamage = 125f,
            effectiveRangeMeters = 350f,
            fireRateRpm = 45,
            magazineCapacity = 5,
            reloadTimeSec = 2.9f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 5.2f, horizontalDriftDeg = 0.8f, recoverySpeed = 3.5f, bloomSpreadDeg = 0.3f),
            ammoType = AmmoType.AMMO_308WIN,
            weightKg = 4.6f,
            rarityTier = "MILITARY",
            description = "Precision bolt-action rifle tuned for high-velocity mountain wind shooting across Northern Hills ridges and checkpoints.",
            protagonistAffinity = "Universal"
        ),
        Weapon(
            id = "wep_falcon_shadow50",
            name = "Falcon Shadow-50 Anti-Material",
            manufacturer = "Falcon Dynamics",
            category = WeaponCategory.MARKSMAN_SNIPER,
            defaultSlot = WeaponSlot.HEAVY,
            firingMode = FiringMode.SEMI_AUTO,
            baseDamage = 260f,
            effectiveRangeMeters = 600f,
            fireRateRpm = 90,
            magazineCapacity = 5,
            reloadTimeSec = 3.8f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 9.0f, horizontalDriftDeg = 2.2f, recoverySpeed = 2.8f, bloomSpreadDeg = 0.1f),
            ammoType = AmmoType.AMMO_50BMG,
            weightKg = 11.2f,
            rarityTier = "BLACK_MARKET",
            description = "Massive semi-automatic .50 BMG rifle. Capable of disabling police helicopter rotors and piercing armored convoy limousines from Clifton penthouses.",
            protagonistAffinity = "Daniyal Qureshi"
        ),

        // HEAVY ORDNANCE
        Weapon(
            id = "wep_bolan_rpg",
            name = "Bolan RPG-X Rocket Launcher",
            manufacturer = "Bolan Heavy Works",
            category = WeaponCategory.HEAVY,
            defaultSlot = WeaponSlot.HEAVY,
            firingMode = FiringMode.SEMI_AUTO,
            baseDamage = 450f,
            effectiveRangeMeters = 250f,
            fireRateRpm = 15,
            magazineCapacity = 1,
            reloadTimeSec = 4.5f,
            recoil = WeaponRecoilProfile(verticalKickDeg = 8.0f, horizontalDriftDeg = 3.0f, recoverySpeed = 2.0f, bloomSpreadDeg = 1.0f),
            ammoType = AmmoType.AMMO_ROCKET,
            weightKg = 7.0f,
            rarityTier = "BLACK_MARKET",
            description = "Single-tube shoulder-launched shaped-charge rocket. Devastates armored SWAT trucks and barricaded port warehouses.",
            protagonistAffinity = "Shahroz Malik"
        ),

        // MELEE WEAPONS
        Weapon(
            id = "wep_boxing_wraps",
            name = "Lyari Fighter Knuckle Wraps",
            manufacturer = "Lyari Boxing Club",
            category = WeaponCategory.MELEE,
            defaultSlot = WeaponSlot.MELEE,
            firingMode = FiringMode.MELEE_SWING,
            baseDamage = 45f,
            effectiveRangeMeters = 1.8f,
            fireRateRpm = 140,
            magazineCapacity = 1,
            reloadTimeSec = 0f,
            recoil = WeaponRecoilProfile(0f, 0f, 10f, 0f),
            ammoType = AmmoType.AMMO_NONE,
            weightKg = 0.2f,
            rarityTier = "STREET",
            description = "Ayan's reinforced canvas boxing wraps. Enables lightning three-hit combos, quick slips, and silent rear neck-break takedowns.",
            protagonistAffinity = "Ayan Khan"
        ),
        Weapon(
            id = "wep_heavy_spanner",
            name = "Heavy Iron Workshop Spanner",
            manufacturer = "Port Marine Tools",
            category = WeaponCategory.MELEE,
            defaultSlot = WeaponSlot.MELEE,
            firingMode = FiringMode.MELEE_SWING,
            baseDamage = 75f,
            effectiveRangeMeters = 2.2f,
            fireRateRpm = 65,
            magazineCapacity = 1,
            reloadTimeSec = 0f,
            recoil = WeaponRecoilProfile(0f, 0f, 6f, 0f),
            ammoType = AmmoType.AMMO_NONE,
            weightKg = 2.8f,
            rarityTier = "STREET",
            description = "A massive forged iron industrial wrench. Staggering blunt force that knocks enemies to the floor in a single heavy blow.",
            protagonistAffinity = "Shahroz Malik"
        ),
        Weapon(
            id = "wep_tactical_tanto",
            name = "Carbon-Composite Combat Tanto",
            manufacturer = "Falcon Dynamics",
            category = WeaponCategory.MELEE,
            defaultSlot = WeaponSlot.MELEE,
            firingMode = FiringMode.MELEE_SWING,
            baseDamage = 60f,
            effectiveRangeMeters = 1.9f,
            fireRateRpm = 110,
            magazineCapacity = 1,
            reloadTimeSec = 0f,
            recoil = WeaponRecoilProfile(0f, 0f, 9f, 0f),
            ammoType = AmmoType.AMMO_NONE,
            weightKg = 0.4f,
            rarityTier = "BLACK_MARKET",
            description = "Razor-edged tactical knife with non-reflective matte coating. Ideal for instant silent sentry assassinations from behind cover.",
            protagonistAffinity = "Daniyal Qureshi"
        )
    )

    fun getWeaponById(id: String): Weapon? = allWeapons.find { it.id == id }

    fun getWeaponsByCategory(category: WeaponCategory): List<Weapon> =
        allWeapons.filter { it.category == category }

    // Room Database persistence
    fun getAllSavedWeapons(): Flow<List<SavedWeaponEntity>> = worldDao.getAllSavedWeapons()

    fun getWeaponsByOwner(ownerId: String): Flow<List<SavedWeaponEntity>> =
        worldDao.getWeaponsByOwner(ownerId)

    suspend fun saveWeaponToInventory(entity: SavedWeaponEntity): Long =
        worldDao.insertSavedWeapon(entity)

    suspend fun deleteSavedWeapon(entity: SavedWeaponEntity) =
        worldDao.deleteSavedWeapon(entity)

    suspend fun deleteSavedWeaponById(id: Long) =
        worldDao.deleteSavedWeaponById(id)
}
