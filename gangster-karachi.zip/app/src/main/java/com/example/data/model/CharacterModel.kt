package com.example.data.model

import androidx.compose.ui.graphics.Color

// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// MASTER PROMPT 04: Three Playable Protagonists, Character Data Architecture
// ==============================================================================

data class CharacterStats(
    val health: Float = 100f,
    val maxHealth: Float = 100f,
    val stamina: Float = 100f,
    val maxStamina: Float = 100f,
    val strength: Int,        // Melee damage, heavy weapon recoil control, carrying capacity
    val agility: Int,         // Movement speed, parkour vaulting, dodge recovery
    val driving: Int,         // Vehicle handling, drift recovery, high-speed traction
    val shooting: Int,        // Recoil management, reload speed, stability
    val stealth: Int,         // Sound suppression, crouching speed, enemy detection delay
    val endurance: Int,       // Damage reduction, sprint duration, recovery rate
    val accuracy: Int,        // Reticle bloom reduction, sniper sway suppression
    val technicalSkill: Int,  // Electronic bypass, drone control, vehicle tuning, hacking
    val socialSkill: Int      // Negotiation, cantonment access, faction persuasion
)

enum class ClothingSlot(val displayName: String) {
    UPPER_BODY("Upper Body"),
    LOWER_BODY("Lower Body"),
    FOOTWEAR("Footwear"),
    HEADWEAR("Headwear"),
    EYEWEAR("Eyewear"),
    WRISTWEAR("Wristwear"),
    ACCESSORY("Accessories")
}

enum class OutfitCategory(val displayName: String) {
    CASUAL("Casual Streetwear"),
    FORMAL("Executive Formal"),
    STREET("Underground Street"),
    TACTICAL("Covert Tactical"),
    WEATHER("Coastal / Storm"),
    CUSTOM("Custom Preset")
}

data class ClothingItem(
    val id: String,
    val name: String,
    val slot: ClothingSlot,
    val category: OutfitCategory,
    val description: String,
    val pricePkr: Long,
    val primaryColorHex: Long,
    val secondaryColorHex: Long = 0xFF1E293B,
    val warmthFactor: Float = 0.5f,
    val armorBonus: Float = 0f,
    val styleAffiliation: String = "Neutral"
)

data class CustomOutfit(
    val id: String,
    val protagonistId: String,
    val name: String,
    val category: OutfitCategory,
    val upperBody: ClothingItem,
    val lowerBody: ClothingItem,
    val footwear: ClothingItem,
    val headwear: ClothingItem? = null,
    val eyewear: ClothingItem? = null,
    val wristwear: ClothingItem? = null,
    val accessory: ClothingItem? = null
)

data class FaceCustomization(
    val presetId: Int = 1,
    val skinToneIndex: Int = 1,
    val hairstyleId: String = "hair_fade",
    val hairColorHex: Long = 0xFF1A1A1A,
    val facialHairId: String = "beard_stubble",
    val eyeColorHex: Long = 0xFF3D2314,
    val scarId: String = "none",
    val eyewearId: String = "none",
    val accessoryId: String = "none"
)

enum class LocomotionMode(val title: String, val speedKmh: Float) {
    IDLE("Idle / Guard Stance", 0f),
    WALK("Casual Walk", 5f),
    JOG("Tactical Jog", 14f),
    SPRINT("Full Sprint", 26f),
    CROUCH("Low Profile Crouch", 7f),
    SLIDE("Slide / Evasion", 18f),
    VAULT("Parkour Vault", 16f),
    COVER_PEEK("Taking Cover", 0f),
    AIM_STANCE("Braced Aim", 4f),
    VEHICLE_DRIVING("Seated Driving", 0f)
}

data class MovementProfile(
    val protagonistId: String,
    val sprintSpeedMultiplier: Float,
    val vaultSpeedSeconds: Float,
    val meleeKnockbackMultiplier: Float,
    val adsTransitionSeconds: Float,
    val recoilDampingFactor: Float,
    val signatureMovementStyle: String
)

data class ProtagonistRelationship(
    val targetProtagonistId: String,
    val targetName: String,
    val trustScore: Int,      // 0 - 100
    val respectScore: Int,    // 0 - 100
    val loyaltyScore: Int,    // 0 - 100
    val hostilityScore: Int,  // 0 - 100
    val relationshipStatus: String,
    val narrativeNotes: String
)

enum class CharacterSwitchMode {
    CINEMATIC_SKY_CAMERA, // Camera pulls up into high-altitude drone view, pans across Karachi Metro, dives into target
    FAST_SWITCH           // Instant camera snap with motion blur
}

enum class SwitchTransitionState {
    IDLE,
    PULL_UP_CAMERA,
    MAP_PAN_OVERVIEW,
    DIVE_INTO_TARGET,
    COMPLETED
}

data class PlayableCharacterData(
    val id: String,                         // "ayan", "shahroz", "daniyal"
    val fullName: String,
    val alias: String,
    val age: Int,
    val title: String,
    val bio: String,
    val homeDistrictId: String,
    val homeDistrictName: String,
    val currentDistrictId: String,
    val currentDistrictName: String,
    val safehouseName: String,
    val safehouseDescription: String,
    val worldPosX: Float,
    val worldPosY: Float,
    val worldRotationZ: Float = 0f,
    val cashBalancePkr: Long,
    val baseStats: CharacterStats,
    val currentStats: CharacterStats,
    val movementProfile: MovementProfile,
    val activeOutfit: CustomOutfit,
    val appearance: FaceCustomization,
    val relationships: List<ProtagonistRelationship>,
    val assignedVehicleId: String,
    val equippedPrimaryWeaponId: String,
    val equippedSecondaryWeaponId: String,
    val portraitDrawableResName: String,
    val themeColorHex: Long
)
