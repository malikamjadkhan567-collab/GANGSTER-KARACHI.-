package com.example.data.repository

import com.example.data.local.DiscoveredDistrictEntity
import com.example.data.local.SavedMarkerEntity
import com.example.data.local.WorldDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

class WorldRepository(private val worldDao: WorldDao) {

    val allDistricts: List<District> = listOf(
        District(
            id = "downtown",
            name = "Downtown",
            biome = BiomeType.DENSE_URBAN,
            populationDensity = "Very High (85,000 / km²)",
            trafficDensity = "Extreme Multi-Level Grid",
            architectureStyle = "Modern Glass & Steel Skyscraper Canyon, Brutalist Civic Halls",
            securityLevel = SecurityLevel.GARRISONED,
            weatherProfile = "Urban Heat Island, Evening Sea Breeze",
            mapCoordsX = 0.52f,
            mapCoordsY = 0.44f,
            radius = 0.11f,
            description = "The civic and financial nerve center of Karachi Metro. Massive glass-curtain towers house multinational banks, high-stakes finance corporations, and municipal authorities connected by elevated skyways.",
            heroBuildings = listOf("Karachi Commercial Bank Central Tower (Tier 1)", "Metro Police Headquarters (Tier 1)", "National Sports Stadium (Tier 1)"),
            gameplayInteriors = listOf("Metro General Hospital", "Civic Center Underground Parking", "Central Substation"),
            factionZones = listOf("Municipal Government", "Cantonment High Command", "Corporate Securities"),
            missionZones = listOf("Central Bank Vault Infiltration Sector", "Executive High-Rise Extraction Zone", "Subway Line Construction Sabotage"),
            navigationFeatures = listOf("8-Lane Central Boulevard", "Elevated Metro Skybridge", "Underground Utility Spine"),
            colorHex = 0xFFFFD700
        ),
        District(
            id = "defence_gardens",
            name = "Defence Gardens",
            biome = BiomeType.LUXURY_SUBURB,
            populationDensity = "Medium (18,000 / km²)",
            trafficDensity = "Medium (Luxury Sedans & SUVs)",
            architectureStyle = "Contemporary Luxury Mansions, Landscaped Palm Medians, Private Compounds",
            securityLevel = SecurityLevel.HIGH,
            weatherProfile = "Moderate Coastal Inversion, Low Humidity",
            mapCoordsX = 0.68f,
            mapCoordsY = 0.58f,
            radius = 0.12f,
            description = "A sprawling, high-security affluent enclave modeled after premier residential cantonments. Features manicured villas, private tennis clubs, boutique shopping plazas, and heavily guarded perimeter gates.",
            heroBuildings = listOf("Daniyal's Gated Compound Villa (Tier 1)", "Defence Galleria Luxury Mall (Tier 1)", "Royal Palms Country Club (Tier 1)"),
            gameplayInteriors = listOf("Boutique Pharmacy", "Private Bank Vault", "Executive Garage Workshop"),
            factionZones = listOf("Private Armed Security Guild", "Elite Dynasty Cartels", "Diplomatic Consulates"),
            missionZones = listOf("Villa Safe Infiltration", "Luxury Vehicle Heist Corridor", "VIP Blackmail Exchange Point"),
            navigationFeatures = listOf("Wide Tree-Lined Boulevards", "Gated Security Checkpoints", "Private Helipad Nodes"),
            colorHex = 0xFFFFC107
        ),
        District(
            id = "clifton_heights",
            name = "Clifton Heights",
            biome = BiomeType.COASTAL_SKYLINE,
            populationDensity = "High (62,000 / km²)",
            trafficDensity = "High (Sports Cars, Luxury Rides)",
            architectureStyle = "Curved Coastal High-Rises, 5-Star Beachfront Hotels, Glass Penthouses",
            securityLevel = SecurityLevel.HIGH,
            weatherProfile = "Coastal Marine Mist, Golden Hour Reflected Sunlight",
            mapCoordsX = 0.48f,
            mapCoordsY = 0.66f,
            radius = 0.10f,
            description = "The premier coastal luxury district towering over the Arabian Sea. Renowned for its iconic sunset skyline, rooftop infinity pools, upscale seaside dining, and illuminated nighttime glass towers.",
            heroBuildings = listOf("The Velvet Mirage Luxury Club (Tier 1)", "Grand Pearl Coastal Palace Hotel (Tier 1)", "Ocean Vista Penthouse Towers (Tier 1)"),
            gameplayInteriors = listOf("Clifton South Precinct", "Rooftop Lounge & Bar", "Subterranean Valet Garage"),
            factionZones = listOf("International Syndicate Expatriates", "High-Stakes VIP Gamblers"),
            missionZones = listOf("Rooftop Penthouse Sniping Post", "Luxury Hotel Suite Hostage Extraction", "Casino Cash Transit Ambush"),
            navigationFeatures = listOf("Curved Coastal Freeway", "Inter-Tower Skywalk Bridges", "Beachfront Promenade"),
            colorHex = 0xFF00E5FF
        ),
        District(
            id = "ocean_drive",
            name = "Ocean Drive",
            biome = BiomeType.COASTAL,
            populationDensity = "Very High Beach Crowds",
            trafficDensity = "High Coastal Traffic & Cruisers",
            architectureStyle = "Beach Boardwalk, Open Pavilions, Marine Docks, Lighthouse Tower",
            securityLevel = SecurityLevel.MEDIUM,
            weatherProfile = "High Humidity, Salt Mist, Dynamic Ocean Waves & Shoreline Foam",
            mapCoordsX = 0.38f,
            mapCoordsY = 0.78f,
            radius = 0.14f,
            description = "The bustling beachfront of Karachi Metro stretching along miles of golden sand. Hosts the famous Sea View boardwalk, beach horse rides, seafood pavilions, luxury yacht marina, and coastal pier.",
            heroBuildings = listOf("Sea View Historic Lighthouse (Tier 1)", "Marina Yacht Basin Club (Tier 1)"),
            gameplayInteriors = listOf("Ocean Drive Seafood Pavilion", "Boardwalk Retro Arcade", "Jet Ski Rental Docks"),
            factionZones = listOf("Coastal Smuggling Rings", "Waterfront Merchants"),
            missionZones = listOf("Offshore Speedboat Pursuit", "Boardwalk Night Ambush", "Lighthouse Tactical Lookout"),
            navigationFeatures = listOf("Multi-Lane Coastal Highway", "Wide Pedestrian Boardwalk", "Sandy Beach Off-Road Corridors"),
            colorHex = 0xFF00B4D8
        ),
        District(
            id = "saddar_central",
            name = "Saddar Central",
            biome = BiomeType.DENSE_URBAN,
            populationDensity = "Extreme (110,000 / km²)",
            trafficDensity = "Extreme Congestion (Buses, Rickshaws, Minibuses)",
            architectureStyle = "Historic Indo-Saracenic Stonework Mixed with Dense Commercial Low-Rises",
            securityLevel = SecurityLevel.MEDIUM,
            weatherProfile = "Dense Urban Smog, High Ambient Noise & Street Heat",
            mapCoordsX = 0.44f,
            mapCoordsY = 0.42f,
            radius = 0.09f,
            description = "The beating commercial heart of Karachi Metro. Packed with electronics markets, bus interchanges, tea stalls, hawkers, and bustling alleys where street life never sleeps.",
            heroBuildings = listOf("Empress Grand Bazaar (Tier 1)", "Holy Family Trauma Center (Tier 1)"),
            gameplayInteriors = listOf("Saddar Central Bus Terminal", "Electronics Grey-Market Arcades", "Chai Khana Gathering Hub"),
            factionZones = listOf("Bazaar Traders Union", "Street Hawker Syndicate", "Underground Loan Brokers"),
            missionZones = listOf("Crowded Bazaar Foot Chase", "Gold Transit Courier Interception", "Bus Depot Stash Bust"),
            navigationFeatures = listOf("Dense Interconnected Alleys", "Overhead Footbridges", "Narrow Grid Streets"),
            colorHex = 0xFFFFA726
        ),
        District(
            id = "tariq_bazaar",
            name = "Tariq Bazaar",
            biome = BiomeType.MARKET_BAZAAR,
            populationDensity = "Very High (95,000 / km²)",
            trafficDensity = "High (Pedestrians & Commercial Vans)",
            architectureStyle = "Multi-Storey Fashion Malls, Bridal Boutiques, Neon Fabric Awnings",
            securityLevel = SecurityLevel.LOW,
            weatherProfile = "Sheltered Heat, Warm Night Breeze",
            mapCoordsX = 0.58f,
            mapCoordsY = 0.48f,
            radius = 0.08f,
            description = "Karachi Metro's premier fashion and retail district. Lined with hundreds of textile stores, bridal ateliers, jewelry arcades, and street vendors selling snacks and tea.",
            heroBuildings = listOf("Tariq Fashion Emporium (Tier 1)"),
            gameplayInteriors = listOf("Diamond Merchant Vault", "Rooftop Garment Workshop", "Boutique Alley Passage"),
            factionZones = listOf("Merchant Protection Racket", "Jewelry Smuggling Network"),
            missionZones = listOf("Jewelry Display Smash & Grab", "Boutique Rooftop Parkour Escape"),
            navigationFeatures = listOf("Pedestrianized Walkways", "Narrow Commercial Lanes", "Rooftop Sky Corridors"),
            colorHex = 0xFFFF7043
        ),
        District(
            id = "old_town",
            name = "Old Town",
            biome = BiomeType.OLD_TOWN,
            populationDensity = "High (78,000 / km²)",
            trafficDensity = "Medium-Low (Narrow Streets)",
            architectureStyle = "Colonial Sandstone Buildings, Carved Teak Jharokas, Heritage Clocktowers",
            securityLevel = SecurityLevel.LOW,
            weatherProfile = "Dry Urban Heat, Shadows cast by High Stonework",
            mapCoordsX = 0.36f,
            mapCoordsY = 0.46f,
            radius = 0.08f,
            description = "The historical root of Karachi Metro. Ancient stone facades, ornate balconies, centuries-old spice markets, and labyrinthine alleys that offer escape from pursuing police.",
            heroBuildings = listOf("Old Town Clocktower Plaza (Tier 1)", "Central Fire Station No. 1 (Tier 1)"),
            gameplayInteriors = listOf("Antique & Gold Souk", "Heritage Tea House", "Historic Masonry Basement"),
            factionZones = listOf("Traditional Clan Elders", "Heritage District Smugglers"),
            missionZones = listOf("Clocktower Sniper Defense", "Spice Market Smoke Escape", "Antiquities Courier Heist"),
            navigationFeatures = listOf("Cobblestone Lanes", "Arched Covered Tunnels", "Labyrinthine Alleys"),
            colorHex = 0xFFD7CCC8
        ),
        District(
            id = "lyari_blocks",
            name = "Lyari Blocks",
            biome = BiomeType.WORKING_CLASS,
            populationDensity = "Extreme (120,000 / km²)",
            trafficDensity = "Medium (Motorcycles, Delivery Vans)",
            architectureStyle = "Dense Concrete Multi-Level Tenements, Interconnected Flat Rooftops",
            securityLevel = SecurityLevel.MINIMAL,
            weatherProfile = "Warm Coastal Air, Ambient Dust & Charcoal Smoke",
            mapCoordsX = 0.32f,
            mapCoordsY = 0.38f,
            radius = 0.09f,
            description = "The fierce working-class soul of Karachi Metro. Renowned for its boxing clubs, football passion, vibrant street art, and unbroken rooftop pathways that form an aerial highway.",
            heroBuildings = listOf("Ayan's Rooftop Flat & Boxing Loft (Tier 1)", "Lyari Peoples Football Arena (Tier 1)"),
            gameplayInteriors = listOf("Underground Boxing Ring", "Lyari Community Outpost", "Alley Auto-Tuning Den"),
            factionZones = listOf("Lyari Hawks Brotherhood", "Neighborhood Defense Youth"),
            missionZones = listOf("Ayan's Starting Awakening", "Rooftop Gang Turf Skirmish", "Police Raid Alley Evasion"),
            navigationFeatures = listOf("Interconnected Rooftop Bridges", "Narrow Bike Lanes", "Storm Drain Access Points"),
            colorHex = 0xFFFF5722
        ),
        District(
            id = "orangi_district",
            name = "Orangi District",
            biome = BiomeType.HILLSIDE_URBAN,
            populationDensity = "Extreme Sprawl",
            trafficDensity = "High (Rickshaws, Scooters, Minibuses)",
            architectureStyle = "Hillside Cement Block Homes, Overhead Wire Web, Rooftop Water Tanks",
            securityLevel = SecurityLevel.MINIMAL,
            weatherProfile = "Elevated Dusty Wind, Scorching Midday Sun",
            mapCoordsX = 0.28f,
            mapCoordsY = 0.24f,
            radius = 0.11f,
            description = "A massive self-built hillside metropolis. Slopes are blanketed in brick and concrete dwellings, informal cottage manufacturing workshops, and vast network of utility lines.",
            heroBuildings = listOf("Hilltop Water Tank Comm Post (Tier 1)"),
            gameplayInteriors = listOf("Hillside Welding Workshop", "Makeshift Clinic", "Underground Water Tank Vault"),
            factionZones = listOf("Hillside Cartel", "Independent Water Tanker Barons"),
            missionZones = listOf("Water Tanker Hijacking", "Hillside Slum Ambush", "Communications Wiretap Raid"),
            navigationFeatures = listOf("Steep Hillside Stairs", "Winding Terraced Roads", "Overhead Cable Transits"),
            colorHex = 0xFFE64A19
        ),
        District(
            id = "industrial_zone",
            name = "Industrial Zone",
            biome = BiomeType.HEAVY_INDUSTRIAL,
            populationDensity = "Low Residential / High Shift Workers",
            trafficDensity = "Very High (Heavy Freight Trucks & Tankers)",
            architectureStyle = "Corrugated Steel Hangars, Chemical Refineries, High Smoke Stacks, Rail Spurs",
            securityLevel = SecurityLevel.MEDIUM,
            weatherProfile = "Chemical Smog, Diesel Exhaust, Acidic Night Haze",
            mapCoordsX = 0.22f,
            mapCoordsY = 0.54f,
            radius = 0.12f,
            description = "The industrial muscle of Karachi Metro. Massive manufacturing plants, steel fabrication yards, chemical holding tanks, and freight rail terminals humming around the clock.",
            heroBuildings = listOf("Shershah Auto Salvage Depot (Tier 1)", "Metro Thermal Power Plant (Tier 1)"),
            gameplayInteriors = listOf("Industrial Hazmat & Rescue Station", "Abandoned Textile Mill", "Heavy Truck Repair Depot"),
            factionZones = listOf("Industrial Scrap Syndicate", "Chemical Transport Brotherhood"),
            missionZones = listOf("Heavy Factory Sabotage", "Cargo Train Hijack", "Scrap Yard Gang Showdown"),
            navigationFeatures = listOf("Heavy-Duty Truck Highways", "Rail Yard Crossings", "Elevated Pipeline Catwalks"),
            colorHex = 0xFF78909C
        ),
        District(
            id = "port_district",
            name = "Port District",
            biome = BiomeType.PORT_DOCKLANDS,
            populationDensity = "Low (Dockworkers & Security Patrols)",
            trafficDensity = "Extreme Heavy Haul (Container Lorries & Cranes)",
            architectureStyle = "Towering Rail Gantry Cranes, Multi-Tier Shipping Containers, Deepwater Docks",
            securityLevel = SecurityLevel.GARRISONED,
            weatherProfile = "Salty Coastal Spray, Dense Marine Fog, Industrial Lighting Reflections",
            mapCoordsX = 0.16f,
            mapCoordsY = 0.68f,
            radius = 0.13f,
            description = "The colossal deepwater shipping harbor where international freighters dock. Miles of multi-colored shipping container labyrinths, massive gantry cranes, and guarded customs compounds.",
            heroBuildings = listOf("Shahroz's Salvage Yard & Workshop (Tier 1)", "Port Customs & Security HQ (Tier 1)", "Karachi Deepwater Terminal (Tier 1)"),
            gameplayInteriors = listOf("Container Yard Office", "Drydock Maintenance Shed", "Cargo Hold of Container Vessel"),
            factionZones = listOf("Shahroz's Dockworker Guild", "International Smuggling Cartel", "Port Maritime Guard"),
            missionZones = listOf("Shahroz's Starting Awakening", "Midnight Container Smuggling Interception", "Gantry Crane Sniper Elimination"),
            navigationFeatures = listOf("Multi-Tier Container Climbing Routes", "Port Highway Corridors", "Deepwater Ship Access Ramps"),
            colorHex = 0xFF546E7A
        ),
        District(
            id = "metro_airport",
            name = "Metro International Airport",
            biome = BiomeType.AIRPORT_TRANSIT,
            populationDensity = "High Transient Travelers",
            trafficDensity = "High Expressway & Airport Shuttles",
            architectureStyle = "Futuristic Cantilever Glass Terminal, 4km Runway, Control Tower",
            securityLevel = SecurityLevel.GARRISONED,
            weatherProfile = "Open Windy Tarmac, Clear Horizon Line",
            mapCoordsX = 0.76f,
            mapCoordsY = 0.32f,
            radius = 0.13f,
            description = "The premier aviation hub connecting Karachi Metro to global capitals. Features dual parallel runways, massive passenger concourses, private jet aprons, and cargo hangars.",
            heroBuildings = listOf("Metro Airport Passenger Terminal (Tier 1)", "Air Traffic Control Tower (Tier 1)", "VIP Private Jet Hangar (Tier 1)"),
            gameplayInteriors = listOf("Cargo Customs Depot", "Airport Police Holding Cell", "Underground Baggage Sorting Hub"),
            factionZones = listOf("Federal Aviation Security", "Airport Smuggling Contingent"),
            missionZones = listOf("VIP Private Jet Tarmac Escape", "Runway High-Speed Interception", "Control Tower Communications Sabotage"),
            navigationFeatures = listOf("Expressway Cloverleaf Ramps", "High-Speed Runway Service Tracks", "Underground Baggage Tunnels"),
            colorHex = 0xFF81D4FA
        ),
        District(
            id = "northern_hills",
            name = "Northern Hills",
            biome = BiomeType.MOUNTAIN_HIGHLANDS,
            populationDensity = "Sparse (Scattered settlements)",
            trafficDensity = "Low (Off-road 4x4s, Long-haul Trucks)",
            architectureStyle = "Carved Limestone Cliffs, Concrete Switchbacks, Highway Tunnels, Abandoned Mines",
            securityLevel = SecurityLevel.MINIMAL,
            weatherProfile = "Dry Mountain Winds, Chilly Night Air, Starry Skies",
            mapCoordsX = 0.46f,
            mapCoordsY = 0.12f,
            radius = 0.14f,
            description = "Rugged mountain ridges framing the northern border of Karachi Metro. Steep hairpin roads carve through limestone canyons with secret quarries and sweeping city overlooks.",
            heroBuildings = listOf("Hawk's Ridge Panoramic Viewpoint (Tier 1)", "Abandoned Limestone Quarry Bunker (Tier 1)"),
            gameplayInteriors = listOf("Northern Expressway Mountain Tunnel", "Mountain Hermit Shrine", "Illegal Arms Cache Cave"),
            factionZones = listOf("Highland Smugglers", "Desert Bandits"),
            missionZones = listOf("Mountain Switchback Vehicle Ambush", "Quarry Stash Extraction", "Cliffside Helicopter Defense"),
            navigationFeatures = listOf("Hairpin Switchback Roads", "Mountain Tunnels", "Rocky Dirt Trails"),
            colorHex = 0xFF8D6E63
        ),
        District(
            id = "greenbelt",
            name = "Greenbelt",
            biome = BiomeType.NATURE_RESERVE,
            populationDensity = "Very Low (Rangers & Rural Villagers)",
            trafficDensity = "Minimal (Dirt Roads, Tractors)",
            architectureStyle = "Dense Acacia Woods, River Crossing Bridges, Wildlife Corridors",
            securityLevel = SecurityLevel.MINIMAL,
            weatherProfile = "Humid Forest Microclimate, Morning River Dew",
            mapCoordsX = 0.72f,
            mapCoordsY = 0.18f,
            radius = 0.12f,
            description = "A sweeping natural oasis of dense vegetation, river bends, and wildlife areas contrasting sharply with the concrete city. Features dirt trails, wooden bridges, and secluded outposts.",
            heroBuildings = listOf("Forestry Ranger Outpost (Tier 1)"),
            gameplayInteriors = listOf("River Crossing Waystation", "Abandoned Eco-Lodge", "Secluded Smuggler's Cabin"),
            factionZones = listOf("Poachers & Wildwood Raiders", "Forest Ranger Militia"),
            missionZones = listOf("Riverboat Pursuit", "Forest Clearing Covert Drop", "Wilderness Survival Evasion"),
            navigationFeatures = listOf("Dirt Off-Road Trails", "Wooden River Bridges", "Riverboat Navigable Waterways"),
            colorHex = 0xFF4CAF50
        ),
        District(
            id = "fishing_village",
            name = "Fishing Village",
            biome = BiomeType.FISHING_SETTLEMENT,
            populationDensity = "Low Coastal Community",
            trafficDensity = "Minimal (Boats, Mopeds, Bicycles)",
            architectureStyle = "Weathered Wooden Stilt Houses, Boat Slipways, Fish Drying Racks",
            securityLevel = SecurityLevel.MINIMAL,
            weatherProfile = "Brisk Tidal Winds, Morning Brine Haze",
            mapCoordsX = 0.12f,
            mapCoordsY = 0.82f,
            radius = 0.08f,
            description = "A traditional fishing settlement on the mangrove inlets of Karachi Metro. Weathered stilt homes line shallow waters where wooden wooden dhows deliver the day's catch.",
            heroBuildings = listOf("Village Headman's Stilt Hall (Tier 1)"),
            gameplayInteriors = listOf("Fish Auction Pier", "Smuggler's Cove Hidden Jetty", "Boat Repair Slip"),
            factionZones = listOf("Coastal Fisherman Brotherhood", "Creek Contraband Runners"),
            missionZones = listOf("Mangrove Creek Speedboat Evasion", "Fish Market Stash Hand-off"),
            navigationFeatures = listOf("Wooden Boardwalk Paths", "Mangrove Boat Channels", "Tidal Mudflat Crossings"),
            colorHex = 0xFF26A69A
        )
    )

    val allLandmarks: List<Landmark> = listOf(
        // Emergency
        Landmark("lm_police_hq", "Metro Police Central Headquarters", "downtown", LandmarkCategory.EMERGENCY, InteriorTier.TIER_1_HERO, 0.54f, 0.42f, "High-security compound with tactical armory, detention cells, and helipad.", "shield"),
        Landmark("lm_general_hosp", "Karachi Metro General Hospital", "downtown", LandmarkCategory.EMERGENCY, InteriorTier.TIER_1_HERO, 0.50f, 0.46f, "Premier medical center with emergency ER trauma bays and rooftop medical helipad.", "local_hospital"),
        Landmark("lm_clifton_precinct", "Clifton South Precinct", "clifton_heights", LandmarkCategory.EMERGENCY, InteriorTier.TIER_2_GAMEPLAY, 0.46f, 0.64f, "Tactical coastal police substation with swift interception cruisers.", "security"),
        Landmark("lm_fire_station_1", "Central Fire & Rescue Station No. 1", "old_town", LandmarkCategory.EMERGENCY, InteriorTier.TIER_2_GAMEPLAY, 0.35f, 0.48f, "Historic red-brick firehouse equipped with heavy pump engines.", "fire_truck"),
        Landmark("lm_port_security", "Port Maritime Security Command", "port_district", LandmarkCategory.EMERGENCY, InteriorTier.TIER_1_HERO, 0.18f, 0.65f, "Fortified coastal base with harbor patrol gunboats and customs checkpoints.", "local_police"),
        Landmark("lm_ind_hazmat", "Industrial Hazmat & Emergency Rescue", "industrial_zone", LandmarkCategory.EMERGENCY, InteriorTier.TIER_2_GAMEPLAY, 0.24f, 0.52f, "Specialized chemical emergency response unit with heavy equipment.", "warning"),

        // Commerce
        Landmark("lm_bank_vault", "Commercial Bank Central Tower & Vault", "downtown", LandmarkCategory.COMMERCE, InteriorTier.TIER_1_HERO, 0.53f, 0.45f, "Massive 60-storey skyscraper housing subterranean multi-tier safe vaults.", "account_balance"),
        Landmark("lm_defence_mall", "Defence Galleria Luxury Mall", "defence_gardens", LandmarkCategory.COMMERCE, InteriorTier.TIER_1_HERO, 0.66f, 0.56f, "Ultra-luxury retail atrium with high-end designer stores and multi-level parking.", "storefront"),
        Landmark("lm_empress_bazaar", "Empress Grand Bazaar", "saddar_central", LandmarkCategory.COMMERCE, InteriorTier.TIER_1_HERO, 0.43f, 0.41f, "Victorian gothic market hall packed with spices, dry fruits, and gold trading stalls.", "shopping_bag"),
        Landmark("lm_tariq_emporium", "Tariq Fashion Emporium", "tariq_bazaar", LandmarkCategory.COMMERCE, InteriorTier.TIER_1_HERO, 0.59f, 0.47f, "Six floors of bridal wear, imported fabrics, and gemstone jewelers.", "shopping_basket"),
        Landmark("lm_shershah_salvage", "Shershah Auto Salvage & Scrap Depot", "industrial_zone", LandmarkCategory.COMMERCE, InteriorTier.TIER_2_GAMEPLAY, 0.20f, 0.56f, "Vast junkyard providing untraceable vehicle parts, engines, and chop-shop bays.", "car_repair"),
        Landmark("lm_highway_gas", "Shell Super Highway Travel Plaza", "downtown", LandmarkCategory.COMMERCE, InteriorTier.TIER_2_GAMEPLAY, 0.62f, 0.38f, "24-hour service station with 12 fuel pumps, convenience store, and repair bays.", "local_gas_station"),

        // Transportation
        Landmark("lm_airport_terminal", "Metro International Terminal 1", "metro_airport", LandmarkCategory.TRANSPORTATION, InteriorTier.TIER_1_HERO, 0.77f, 0.30f, "Sweeping glass passenger departure hall with baggage gates and customs scanners.", "flight"),
        Landmark("lm_airport_tower", "Airport Air Traffic Control Tower", "metro_airport", LandmarkCategory.TRANSPORTATION, InteriorTier.TIER_1_HERO, 0.75f, 0.34f, "120-meter radar tower overlooking all runway movements and airspace.", "radar"),
        Landmark("lm_port_terminal", "Karachi Deepwater Container Terminal", "port_district", LandmarkCategory.TRANSPORTATION, InteriorTier.TIER_1_HERO, 0.15f, 0.70f, "Heavy container yard with electric gantry cranes and cargo berthing slips.", "directions_boat"),
        Landmark("lm_saddar_bus", "Saddar Intercity Bus Concourse", "saddar_central", LandmarkCategory.TRANSPORTATION, InteriorTier.TIER_2_GAMEPLAY, 0.45f, 0.44f, "Chaotic transit depot with colorful regional buses departing for provincial routes.", "directions_bus"),
        Landmark("lm_marina_club", "Marina Coastal Yacht Berths", "ocean_drive", LandmarkCategory.TRANSPORTATION, InteriorTier.TIER_2_GAMEPLAY, 0.36f, 0.75f, "Private marina featuring luxury speedboats, motor yachts, and fueling docks.", "sailing"),
        Landmark("lm_mountain_tunnel", "Northern Pass Twin Highway Tunnels", "northern_hills", LandmarkCategory.TRANSPORTATION, InteriorTier.TIER_2_GAMEPLAY, 0.48f, 0.14f, "2.4km engineered mountain tunnel connecting metro core to outer highways.", "alt_route"),

        // Entertainment
        Landmark("lm_national_stadium", "National Sports & Cricket Stadium", "downtown", LandmarkCategory.ENTERTAINMENT, InteriorTier.TIER_1_HERO, 0.58f, 0.40f, "45,000-seat sports colosseum with illuminated floodlights and VIP skyboxes.", "stadium"),
        Landmark("lm_velvet_mirage", "The Velvet Mirage Coastal Club", "clifton_heights", LandmarkCategory.ENTERTAINMENT, InteriorTier.TIER_1_HERO, 0.49f, 0.68f, "Exclusive nightlife sanctuary with rooftop infinity pool and private VIP suites.", "nightlife"),
        Landmark("lm_lyari_football", "Lyari Peoples Football Arena", "lyari_blocks", LandmarkCategory.ENTERTAINMENT, InteriorTier.TIER_2_GAMEPLAY, 0.33f, 0.36f, "Electrifying community turf stadium famous for grassroots tournaments.", "sports_soccer"),
        Landmark("lm_pearl_hotel", "Grand Pearl Coastal Palace Hotel", "clifton_heights", LandmarkCategory.ENTERTAINMENT, InteriorTier.TIER_1_HERO, 0.51f, 0.63f, "Five-star luxury coastal resort hosting diplomats, tycoons, and international syndicates.", "hotel"),
        Landmark("lm_boardwalk_arcade", "Ocean Drive Retro Arcade & Pier", "ocean_drive", LandmarkCategory.ENTERTAINMENT, InteriorTier.TIER_2_GAMEPLAY, 0.39f, 0.80f, "Nostalgic neon-lit seaside arcade with prize machines and carnival games.", "sports_esports"),

        // Gameplay & Safehouses
        Landmark("lm_safehouse_ayan", "Ayan's Rooftop Flat & Boxing Loft", "lyari_blocks", LandmarkCategory.GAMEPLAY, InteriorTier.TIER_1_HERO, 0.31f, 0.39f, "Protagonist Ayan's home base: punching bags, tactical map board, bed, and rooftop exit.", "home", "Rooftop Level"),
        Landmark("lm_safehouse_shahroz", "Shahroz's Salvage Yard Workshop", "port_district", LandmarkCategory.GAMEPLAY, InteriorTier.TIER_1_HERO, 0.17f, 0.67f, "Protagonist Shahroz's base: heavy hydraulic lifts, tool benches, metal forge, and cot.", "build", "Ground Level"),
        Landmark("lm_safehouse_daniyal", "Daniyal's Gated Penthouse Villa", "defence_gardens", LandmarkCategory.GAMEPLAY, InteriorTier.TIER_1_HERO, 0.70f, 0.60f, "Protagonist Daniyal's luxury sanctuary: biometric security, wine cellar, pool, and surveillance wall.", "apartment", "Elevated / Villa"),
        Landmark("lm_sewer_hub", "Underground Drainage Infiltration Hub", "saddar_central", LandmarkCategory.GAMEPLAY, InteriorTier.TIER_2_GAMEPLAY, 0.42f, 0.40f, "Subterranean sewer tunnel intersection providing covert movement beneath city police.", "explore", "Underground Level"),
        Landmark("lm_quarry_bunker", "Abandoned Limestone Quarry Bunker", "northern_hills", LandmarkCategory.GAMEPLAY, InteriorTier.TIER_2_GAMEPLAY, 0.44f, 0.10f, "Cold War era subterranean concrete bunker hidden behind blasted rock faces.", "military_tech", "Underground Level"),
        Landmark("lm_smugglers_cove", "Smuggler's Cove Hidden Jetty", "fishing_village", LandmarkCategory.GAMEPLAY, InteriorTier.TIER_2_GAMEPLAY, 0.10f, 0.84f, "Secluded tidal inlet sheltered by dense mangroves used for nighttime sea drops.", "waves", "Ground Level")
    )

    val protagonists: List<Protagonist> = listOf(
        Protagonist(
            id = "ayan",
            name = "Ayan Khan",
            title = "The Street Prodigy",
            startingDistrictId = "lyari_blocks",
            startingDistrictName = "Lyari Blocks",
            safehouseName = "Lyari Rooftop Loft & Boxing Gym",
            safehouseTier = InteriorTier.TIER_1_HERO,
            spawnCoordsX = 0.31f,
            spawnCoordsY = 0.39f,
            biography = "Born and raised in the tenement canyons of Lyari. A lightning-fast boxer and parkour specialist with an unmatched mental map of the city's alleyways and rooftops.",
            tacticalSpecialty = "Rooftop traversal, crowd blending, rapid street combat, and working-class street informant network.",
            startingVehicleStatus = "[NOT IMPLEMENTED] — Reserved for Prompt 02: 125cc Modified Street Motorcycle",
            startingWeaponStatus = "[NOT IMPLEMENTED] — Reserved for Prompt 03: Concealed Boxing Wraps & 9mm Semi-Auto",
            accentColorHex = 0xFFFF5722
        ),
        Protagonist(
            id = "shahroz",
            name = "Shahroz 'Shera' Malik",
            title = "The Industrial Enforcer",
            startingDistrictId = "port_district",
            startingDistrictName = "Port District & Industrial Zone",
            safehouseName = "Shahroz's Salvage Yard Workshop",
            safehouseTier = InteriorTier.TIER_1_HERO,
            spawnCoordsX = 0.17f,
            spawnCoordsY = 0.67f,
            biography = "A veteran heavy diesel mechanic and ex-dockworker union leader. Built like an armored freight car, with intimate knowledge of maritime smuggling manifests and industrial machinery.",
            tacticalSpecialty = "Heavy vehicle handling, industrial hacking, lock destruction, container maneuvering, and brutal close-quarters strength.",
            startingVehicleStatus = "[NOT IMPLEMENTED] — Reserved for Prompt 02: Customized Heavy Diesel Flatbed Truck",
            startingWeaponStatus = "[NOT IMPLEMENTED] — Reserved for Prompt 03: Heavy Pipe Wrench & 12-Gauge Pump Shotgun",
            accentColorHex = 0xFF546E7A
        ),
        Protagonist(
            id = "daniyal",
            name = "Daniyal H. Qureshi",
            title = "The High-Stakes Fixer",
            startingDistrictId = "defence_gardens",
            startingDistrictName = "Defence Gardens",
            safehouseName = "Daniyal's Gated Penthouse Villa",
            safehouseTier = InteriorTier.TIER_1_HERO,
            spawnCoordsX = 0.70f,
            spawnCoordsY = 0.60f,
            biography = "A former hedge fund executive and political consultant cast out after a multi-billion high-level financial coup. Ruthlessly calculated, with access to offshore accounts, luxury gates, and elite intelligence.",
            tacticalSpecialty = "Electronic counter-surveillance, diplomatic immunity bribery, sniper rifle precision, and luxury vehicle escapes.",
            startingVehicleStatus = "[NOT IMPLEMENTED] — Reserved for Prompt 02: Armored Luxury V8 Executive Sedan",
            startingWeaponStatus = "[NOT IMPLEMENTED] — Reserved for Prompt 03: Suppressed Tactical Pistol & Precision Marksman Rifle",
            accentColorHex = 0xFFFFD700
        )
    )

    fun getDistrictById(id: String): District? = allDistricts.find { it.id == id }

    fun getLandmarksByDistrict(districtId: String): List<Landmark> =
        allLandmarks.filter { it.districtId == districtId }

    // Room Database delegations
    fun getAllMarkers(): Flow<List<SavedMarkerEntity>> = worldDao.getAllMarkers()

    suspend fun insertMarker(marker: SavedMarkerEntity): Long = worldDao.insertMarker(marker)

    suspend fun deleteMarker(marker: SavedMarkerEntity) = worldDao.deleteMarker(marker)

    suspend fun deleteMarkerById(id: Long) = worldDao.deleteMarkerById(id)

    fun getDiscoveredDistricts(): Flow<List<DiscoveredDistrictEntity>> =
        worldDao.getDiscoveredDistricts()

    suspend fun discoverDistrict(districtId: String) {
        worldDao.setDistrictDiscovered(DiscoveredDistrictEntity(districtId, true, true))
    }
}
