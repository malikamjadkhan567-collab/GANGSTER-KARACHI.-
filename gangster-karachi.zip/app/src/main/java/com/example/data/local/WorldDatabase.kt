package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SavedMarkerEntity::class,
        DiscoveredDistrictEntity::class,
        SavedVehicleEntity::class,
        SavedWeaponEntity::class,
        ProtagonistStateEntity::class,
        CustomOutfitEntity::class,
        MissionProgressEntity::class,
        FactionReputationEntity::class,
        WorldSimulationEntity::class
    ],
    version = 6,
    exportSchema = false
)
abstract class WorldDatabase : RoomDatabase() {
    abstract fun worldDao(): WorldDao

    companion object {
        @Volatile
        private var INSTANCE: WorldDatabase? = null

        fun getInstance(context: Context): WorldDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    WorldDatabase::class.java,
                    "karachi_metro_world.db"
                ).fallbackToDestructiveMigration(dropAllTables = true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}
