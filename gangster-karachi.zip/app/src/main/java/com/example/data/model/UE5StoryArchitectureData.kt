package com.example.data.model

object UE5StoryArchitectureData {

    val missionSubsystemHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiStorySystem / Public / KarachiMissionSubsystem.h
// ==============================================================================
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Engine/DataTable.h"
#include "KarachiMissionSubsystem.generated.h"

UENUM(BlueprintType)
enum class EStoryAct : uint8
{
    ActI_LyariToKemari     UMETA(DisplayName = "Act I: Lyari to Kemari"),
    ActII_Syndicate        UMETA(DisplayName = "Act II: The Syndicate Alliance"),
    ActIII_Betrayal        UMETA(DisplayName = "Act III: Betrayal & Cartel War"),
    ActIV_FinalReckoning   UMETA(DisplayName = "Act IV: The Final Reckoning")
};

UENUM(BlueprintType)
enum class EMissionState : uint8
{
    Locked,
    Available,
    InProgress,
    Completed,
    Failed
};

USTRUCT(BlueprintType)
struct FMissionObjectiveData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText ObjectiveText;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bIsOptional = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bIsCompleted = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FVector TargetLocation = FVector::ZeroVector;
};

USTRUCT(BlueprintType)
struct FKarachiStoryMission : public FTableRowBase
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FName MissionID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 MissionNumber = 1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    EStoryAct Act = EStoryAct::ActI_LyariToKemari;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText Title;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int64 CashRewardPkr = 50000;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FName AssociatedFactionID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TArray<FMissionObjectiveData> Objectives;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnMissionStatusChanged, FName, MissionID, EMissionState, NewState);

UCLASS()
class KARACHIMETRO_API UKarachiMissionSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Story Missions")
    void StartMission(FName MissionID);

    UFUNCTION(BlueprintCallable, Category = "Story Missions")
    void CompleteObjective(FName MissionID, int32 ObjectiveIndex);

    UFUNCTION(BlueprintCallable, Category = "Story Missions")
    void FinishMission(FName MissionID, bool bSuccess, int32 MedalTier);

    UPROPERTY(BlueprintAssignable, Category = "Story Missions")
    FOnMissionStatusChanged OnMissionStatusChanged;

private:
    FName ActiveMissionID = NAME_None;
    TMap<FName, EMissionState> MissionProgressMap;
};
    """.trimIndent()

    val factionSubsystemHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiStorySystem / Public / KarachiFactionSubsystem.h
// ==============================================================================
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "KarachiFactionSubsystem.generated.h"

UENUM(BlueprintType)
enum class EFactionStandingType : uint8
{
    Hostile      UMETA(DisplayName = "Hostile (-100 to -61)"),
    Unfriendly   UMETA(DisplayName = "Unfriendly (-60 to -21)"),
    Neutral      UMETA(DisplayName = "Neutral (-20 to +29)"),
    Allied       UMETA(DisplayName = "Allied (+30 to +69)"),
    Honored      UMETA(DisplayName = "Honored (+70 to +100)")
};

USTRUCT(BlueprintType)
struct FFactionData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FName FactionID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText DisplayName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    int32 ReputationScore = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    EFactionStandingType Standing = EFactionStandingType::Neutral;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FLinearColor TerritoryColor = FLinearColor::White;
};

UCLASS()
class KARACHIMETRO_API UKarachiFactionSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Factions")
    void ModifyReputation(FName FactionID, int32 Delta);

    UFUNCTION(BlueprintPure, Category = "Factions")
    EFactionStandingType GetFactionStanding(FName FactionID) const;

    UFUNCTION(BlueprintPure, Category = "Factions")
    bool IsFactionHostileToPlayer(FName FactionID) const;

private:
    TMap<FName, FFactionData> FactionsMap;
};
    """.trimIndent()

    val dialogueComponentHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiStorySystem / Public / KarachiDialogueComponent.h
// ==============================================================================
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Sound/SoundWave.h"
#include "KarachiDialogueComponent.generated.h"

USTRUCT(BlueprintType)
struct FRomanUrduDialogueLine
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FName SpeakerID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText RomanUrduText;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText EnglishTranslation;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TSoftObjectPtr<USoundWave> VoiceAudioAsset;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float DurationSeconds = 3.5f;
};

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class KARACHIMETRO_API UKarachiDialogueComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Dialogue")
    void PlayDialogueSequence(const TArray<FRomanUrduDialogueLine>& DialogueLines);

    UFUNCTION(BlueprintCallable, Category = "Dialogue")
    void SkipCurrentLine();

    UFUNCTION(BlueprintCallable, Category = "Dialogue")
    void StopDialogue();

protected:
    UPROPERTY(BlueprintReadOnly, Category = "Dialogue")
    bool bIsDialogueActive = false;
};
    """.trimIndent()
}
