package com.example.data.model

object UE5VehicleArchitectureData {

    val vehicleDataAssetHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiVehicleSystem / Public / KarachiVehicleDataAsset.h
// Description: Primary UDataAsset defining all physical, visual, audio, and damage specs
// Engine Target: Unreal Engine 5.4+ (Chaos Vehicles + Lumen + Nanite)
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "ChaosVehicleMovementComponent.h"
#include "KarachiVehicleDataAsset.generated.h"

UENUM(BlueprintType)
enum class EVehicleClassification : uint8
{
    Compact UMETA(DisplayName = "Compact Hatchback"),
    Sedan UMETA(DisplayName = "Sedan"),
    SportsCoupe UMETA(DisplayName = "Sports & Tuner Coupe"),
    Supercar UMETA(DisplayName = "Exotic Supercar / Hypercar"),
    Muscle UMETA(DisplayName = "Muscle Car"),
    SUV UMETA(DisplayName = "SUV & 4x4"),
    Pickup UMETA(DisplayName = "Pickup Truck"),
    Motorcycle UMETA(DisplayName = "Motorcycle & Scooter"),
    Boat UMETA(DisplayName = "Speedboat & Marine"),
    Helicopter UMETA(DisplayName = "Helicopter & Aircraft"),
    Emergency UMETA(DisplayName = "Police & Emergency"),
    Commercial UMETA(DisplayName = "Bus, Taxi & Freight")
};

UENUM(BlueprintType)
enum class EDrivetrainLayout : uint8
{
    FWD UMETA(DisplayName = "Front-Wheel Drive"),
    RWD UMETA(DisplayName = "Rear-Wheel Drive"),
    AWD UMETA(DisplayName = "All-Wheel Drive"),
    FourByFour UMETA(DisplayName = "4x4 Low/High Transfer"),
    MarineJet UMETA(DisplayName = "Marine Impeller / Jet"),
    TurboshaftRotor UMETA(DisplayName = "Helicopter Turboshaft")
};

USTRUCT(BlueprintType)
struct KARACHIVEHICLESYSTEM_API FVehiclePhysicsConfiguration
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mass")
    float MassKg = 1450.f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Mass")
    FVector CenterOfMassOffset = FVector(0.f, 0.f, -15.f);

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Powertrain")
    int32 Horsepower = 380;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Powertrain")
    float MaxTorqueNm = 480.f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Powertrain")
    float MaxSpeedKmh = 270.f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Powertrain")
    int32 ForwardGearCount = 6;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Powertrain")
    EDrivetrainLayout Drivetrain = EDrivetrainLayout::RWD;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Suspension")
    float SuspensionMaxRaiseCm = 12.f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Suspension")
    float SuspensionMaxDropCm = 15.f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Suspension")
    float SpringRate = 45000.f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Tires")
    float BaseFrictionMultiplier = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Aerodynamics")
    float DragCoefficient = 0.32f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Aerodynamics")
    float DownforceFactor = 1.5f;
};

UCLASS(BlueprintType)
class KARACHIVEHICLESYSTEM_API UKarachiVehicleDataAsset : public UPrimaryDataAsset
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vehicle Identity")
    FName VehicleID;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vehicle Identity")
    FText DisplayName;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vehicle Identity")
    FText Manufacturer;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vehicle Identity")
    EVehicleClassification Classification;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Visual")
    TSoftObjectPtr<USkeletalMesh> VehicleSkeletalMesh;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Visual")
    TSubclassOf<UAnimInstance> VehicleAnimInstanceClass;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Physics")
    FVehiclePhysicsConfiguration PhysicsConfig;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Economy")
    int64 PurchasePricePkr = 4500000;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Protagonist Affinity")
    FName RecommendedProtagonist; // Ayan, Shahroz, Daniyal
};
""".trimIndent()

    val vehicleBaseHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiVehicleSystem / Public / KarachiVehicleBase.h
// Description: Core AActor base class for all controllable vehicles in Karachi Metro
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "KarachiVehicleDataAsset.h"
#include "KarachiVehicleBase.generated.h"

class UCameraComponent;
class USpringArmComponent;
class UChaosWheeledVehicleMovementComponent;

UENUM(BlueprintType)
enum class EVehicleCameraPerspective : uint8
{
    ChaseClose,
    ChaseNormal,
    ChaseWide,
    CockpitFirstPerson,
    HoodCam
};

UCLASS(Abstract)
class KARACHIVEHICLESYSTEM_API AKarachiVehicleBase : public APawn
{
    GENERATED_BODY()

public:
    AKarachiVehicleBase();

    virtual void Tick(float DeltaTime) override;
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

    // Core Vehicle Controls
    UFUNCTION(BlueprintCallable, Category = "Vehicle Controls")
    virtual void SetThrottleInput(float Val);

    UFUNCTION(BlueprintCallable, Category = "Vehicle Controls")
    virtual void SetSteeringInput(float Val);

    UFUNCTION(BlueprintCallable, Category = "Vehicle Controls")
    virtual void SetBrakeInput(float Val);

    UFUNCTION(BlueprintCallable, Category = "Vehicle Controls")
    virtual void SetHandbrakeInput(bool bActive);

    // Driver Entry / Exit
    UFUNCTION(BlueprintCallable, Category = "Vehicle Interaction")
    virtual bool EnterVehicle(APawn* DriverPawn);

    UFUNCTION(BlueprintCallable, Category = "Vehicle Interaction")
    virtual APawn* ExitVehicle();

    // Lighting & Audio
    UFUNCTION(BlueprintCallable, Category = "Vehicle Features")
    void ToggleHeadlights();

    UFUNCTION(BlueprintCallable, Category = "Vehicle Features")
    void SetPoliceSirenActive(bool bActive);

    UFUNCTION(BlueprintCallable, Category = "Vehicle Features")
    void TriggerHorn(bool bSounding);

    // Camera Mode Switching
    UFUNCTION(BlueprintCallable, Category = "Vehicle Camera")
    void CycleCameraPerspective();

    // Damage & Collision
    UFUNCTION(BlueprintCallable, Category = "Vehicle Damage")
    virtual void ApplyCollisionDamage(float ImpactSpeed, const FVector& ImpactNormal, const FHitResult& Hit);

    // Getters for Telemetry
    UFUNCTION(BlueprintPure, Category = "Vehicle Telemetry")
    float GetCurrentSpeedKmh() const;

    UFUNCTION(BlueprintPure, Category = "Vehicle Telemetry")
    float GetEngineRPM() const;

    UFUNCTION(BlueprintPure, Category = "Vehicle Telemetry")
    int32 GetCurrentGear() const;

protected:
    virtual void BeginPlay() override;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    USkeletalMeshComponent* MeshComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    USpringArmComponent* SpringArm;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    UCameraComponent* ExternalCamera;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    UCameraComponent* InteriorCamera;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Vehicle Data")
    UKarachiVehicleDataAsset* VehicleData;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    APawn* CurrentDriver;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    EVehicleCameraPerspective CurrentPerspective;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    bool bHeadlightsOn;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    bool bSirenOn;
};
""".trimIndent()

    val vehicleSubsystemHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiVehicleSystem / Public / KarachiVehicleSubsystem.h
// Description: UWorldSubsystem orchestrating vehicle spawning, garage save/load, and traffic
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "KarachiVehicleDataAsset.h"
#include "KarachiVehicleBase.h"
#include "KarachiVehicleSubsystem.generated.h"

USTRUCT(BlueprintType)
struct KARACHIVEHICLESYSTEM_API FGarageSavedVehicle
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Garage")
    FName VehicleID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Garage")
    FName OwnerProtagonist; // Ayan, Shahroz, Daniyal

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Garage")
    FLinearColor CustomPaintColor;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Garage")
    int32 EngineTuneStage = 0;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Garage")
    bool bTurboInstalled = false;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Garage")
    float ConditionPercent = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Garage")
    FName ParkedGarageDistrict;
};

UCLASS()
class KARACHIVEHICLESYSTEM_API UKarachiVehicleSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    virtual void Deinitialize() override;

    // Spawning & District Traffic
    UFUNCTION(BlueprintCallable, Category = "Karachi Vehicles|Spawning")
    AKarachiVehicleBase* SpawnVehicleAtTransform(FName VehicleID, const FTransform& SpawnTransform);

    UFUNCTION(BlueprintCallable, Category = "Karachi Vehicles|Spawning")
    TArray<FName> GetSpawningPoolForDistrict(FName DistrictID) const;

    // Garage Storage
    UFUNCTION(BlueprintCallable, Category = "Karachi Vehicles|Garage")
    bool StoreVehicleInGarage(const FGarageSavedVehicle& VehicleRecord);

    UFUNCTION(BlueprintCallable, Category = "Karachi Vehicles|Garage")
    TArray<FGarageSavedVehicle> GetGarageVehiclesForProtagonist(FName ProtagonistID) const;

    UFUNCTION(BlueprintCallable, Category = "Karachi Vehicles|Garage")
    AKarachiVehicleBase* RetrieveVehicleFromGarage(FName VehicleID, const FTransform& GarageDoorTransform);

private:
    UPROPERTY()
    TMap<FName, UKarachiVehicleDataAsset*> VehicleRegistry;

    UPROPERTY()
    TArray<FGarageSavedVehicle> PlayerGarageDatabase;

    void LoadAllVehicleDataAssets();
};
""".trimIndent()
}
