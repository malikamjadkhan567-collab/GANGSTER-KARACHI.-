package com.example.data.model

enum class BiomeType(val displayName: String) {
    COASTAL("Coastal Shore & Marina"),
    LUXURY_SUBURB("Luxury Gated Suburb"),
    COASTAL_SKYLINE("Coastal High-Rise Skyline"),
    DENSE_URBAN("Dense Commercial & Transit"),
    MARKET_BAZAAR("High-Density Traditional Bazaar"),
    OLD_TOWN("Heritage Masonry & Colonial"),
    WORKING_CLASS("Dense Working-Class Residential"),
    HILLSIDE_URBAN("Hillside Informal Urban"),
    HEAVY_INDUSTRIAL("Heavy Industrial & Manufacturing"),
    PORT_DOCKLANDS("Deepwater Cargo Port"),
    AIRPORT_TRANSIT("International Airport Hub"),
    MOUNTAIN_HIGHLANDS("Mountain Ridge & Switchbacks"),
    NATURE_RESERVE("Greenbelt Nature Reserve"),
    FISHING_SETTLEMENT("Rustic Coastal Stilt Village"),
    RING_EXPRESSWAY("Peripheral Ring Highway")
}

enum class SecurityLevel(val label: String) {
    MINIMAL("Minimal / Self-Governed"),
    LOW("Low Gang Turf Patrols"),
    MEDIUM("Municipal Police Presence"),
    HIGH("Private Armed Security & Gatehouses"),
    GARRISONED("Heavy Police Garrison & Checkpoints")
}

data class District(
    val id: String,
    val name: String,
    val biome: BiomeType,
    val populationDensity: String,
    val trafficDensity: String,
    val architectureStyle: String,
    val securityLevel: SecurityLevel,
    val weatherProfile: String,
    val mapCoordsX: Float, // 0.0f to 1.0f relative map canvas
    val mapCoordsY: Float,
    val radius: Float,
    val description: String,
    val heroBuildings: List<String>,
    val gameplayInteriors: List<String>,
    val factionZones: List<String>,
    val missionZones: List<String>,
    val navigationFeatures: List<String>,
    val colorHex: Long
)
