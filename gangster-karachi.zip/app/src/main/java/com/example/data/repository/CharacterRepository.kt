package com.example.data.repository

import com.example.data.local.CustomOutfitEntity
import com.example.data.local.ProtagonistStateEntity
import com.example.data.local.WorldDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class CharacterRepository(private val worldDao: WorldDao) {

    // ==========================================================================
    // CLOTHING CATALOG (All Slots & Categories)
    // ==========================================================================

    val clothingCatalog: List<ClothingItem> = listOf(
        // Upper Body - Ayan Styles
        ClothingItem("ayan_hoodie_blk", "Lyari Graphic Oversized Hoodie", ClothingSlot.UPPER_BODY, OutfitCategory.STREET, "Heavy cotton drop-shoulder streetwear hoodie with Urdu typography.", 4500L, 0xFF1E1E24, warmthFactor = 0.7f),
        ClothingItem("ayan_anorak_neon", "Cyber-Wave Windbreaker", ClothingSlot.UPPER_BODY, OutfitCategory.WEATHER, "Reflective water-resistant neon-accented track anorak.", 7200L, 0xFF0EA5E9, warmthFactor = 0.5f),
        ClothingItem("ayan_tee_distressed", "Raw Edge Street Tee", ClothingSlot.UPPER_BODY, OutfitCategory.CASUAL, "Lightweight breathable cotton vintage washed t-shirt.", 2200L, 0xFF334155, warmthFactor = 0.3f),
        ClothingItem("ayan_stealth_knit", "Shadow Weave Turtle-neck", ClothingSlot.UPPER_BODY, OutfitCategory.TACTICAL, "Form-fitting silent thermal weave for covert night operations.", 8900L, 0xFF0F172A, warmthFactor = 0.6f, armorBonus = 10f),
        ClothingItem("ayan_blazer_crimson", "Tailored Street Velvet Blazer", ClothingSlot.UPPER_BODY, OutfitCategory.FORMAL, "Modern slim-cut velvet blazer in deep Karachi burgundy.", 18500L, 0xFF881337, warmthFactor = 0.6f),

        // Upper Body - Shahroz Styles
        ClothingItem("shahroz_canvas_jacket", "Reinforced Dockland Utility Coat", ClothingSlot.UPPER_BODY, OutfitCategory.CASUAL, "Heavy canvas insulated work coat with reinforced shoulder rivets.", 12000L, 0xFF78350F, warmthFactor = 0.8f, armorBonus = 15f),
        ClothingItem("shahroz_plate_carrier", "Tactical Raid Ballistic Vest", ClothingSlot.UPPER_BODY, OutfitCategory.TACTICAL, "Level III-A concealable tactical rig over heavy duty BDU tactical shirt.", 32000L, 0xFF1C1917, warmthFactor = 0.5f, armorBonus = 45f),
        ClothingItem("shahroz_leather_biker", "Distressed Cowhide Biker Jacket", ClothingSlot.UPPER_BODY, OutfitCategory.STREET, "Weathered heavy leather motorcycle jacket with padded elbows.", 24000L, 0xFF27272A, warmthFactor = 0.8f, armorBonus = 20f),
        ClothingItem("shahroz_double_coat", "Charcoal Wool Syndicate Overcoat", ClothingSlot.UPPER_BODY, OutfitCategory.FORMAL, "Classic knee-length tailored winter wool coat with wide notch lapels.", 38000L, 0xFF18181B, warmthFactor = 0.9f),
        ClothingItem("shahroz_oilskin_heavy", "Industrial Waterproof Storm Parka", ClothingSlot.UPPER_BODY, OutfitCategory.WEATHER, "Heavy coated marine canvas with storm hood built for port weather.", 16500L, 0xFF365314, warmthFactor = 0.9f, armorBonus = 10f),

        // Upper Body - Daniyal Styles
        ClothingItem("daniyal_suit_pinstripe", "Bespoke Navy Pinstripe Suit Jacket", ClothingSlot.UPPER_BODY, OutfitCategory.FORMAL, "Handmade Super 160s Italian wool tailored by elite Clifton clothiers.", 95000L, 0xFF172554, warmthFactor = 0.6f),
        ClothingItem("daniyal_merino_mock", "Sand Dune Cashmere Mock-Neck", ClothingSlot.UPPER_BODY, OutfitCategory.CASUAL, "Luxurious lightweight Mongolian cashmere tailored knitwear.", 42000L, 0xFFD6D3D1, warmthFactor = 0.5f),
        ClothingItem("daniyal_trench_matte", "Matte Carbon Stealth Trenchcoat", ClothingSlot.UPPER_BODY, OutfitCategory.TACTICAL, "Kevlar-interwoven waterproof lightweight trench with concealed pockets.", 115000L, 0xFF020617, warmthFactor = 0.6f, armorBonus = 30f),
        ClothingItem("daniyal_tux_silk", "Midnight Silk Satin Dinner Jacket", ClothingSlot.UPPER_BODY, OutfitCategory.STREET, "Bespoke formal dinner jacket with genuine silk shawl lapels.", 130000L, 0xFF030712, warmthFactor = 0.5f),
        ClothingItem("daniyal_nautical_wind", "Riviera Marina Deck Jacket", ClothingSlot.UPPER_BODY, OutfitCategory.WEATHER, "High-tech sailing microfiber jacket in nautical cream and deep navy.", 54000L, 0xFFF8FAFC, warmthFactor = 0.4f),

        // Lower Body
        ClothingItem("lower_biker_jeans", "Slim Taper Moto Jeans", ClothingSlot.LOWER_BODY, OutfitCategory.STREET, "Stretch selvedge denim with ribbed knee articulation.", 5500L, 0xFF1E293B),
        ClothingItem("lower_cargo_joggers", "Modular Tactical Ripstop Cargoes", ClothingSlot.LOWER_BODY, OutfitCategory.TACTICAL, "Heavy duty ripstop combat pants with 8 magnetic utility pockets.", 9800L, 0xFF14532D, armorBonus = 10f),
        ClothingItem("lower_heavy_denim", "Triple-Stitched Work Jeans", ClothingSlot.LOWER_BODY, OutfitCategory.CASUAL, "Indestructible raw indigo work denim.", 7500L, 0xFF1E3A8A),
        ClothingItem("lower_dress_trousers", "Tailored Pleated Wool Trousers", ClothingSlot.LOWER_BODY, OutfitCategory.FORMAL, "Sharp crease Italian wool trousers.", 36000L, 0xFF0F172A),
        ClothingItem("lower_deck_shorts", "Nautical Linen Shorts", ClothingSlot.LOWER_BODY, OutfitCategory.WEATHER, "Lightweight breathable summer shorts for beach and marina.", 14000L, 0xFFE2E8F0),

        // Footwear
        ClothingItem("shoes_neon_runners", "Hyper-Cushion Street Runners", ClothingSlot.FOOTWEAR, OutfitCategory.STREET, "High-grip responsive parkour sneakers with neon accents.", 6800L, 0xFF0284C7),
        ClothingItem("shoes_dock_boots", "Steel-Toe Dockland Combat Boots", ClothingSlot.FOOTWEAR, OutfitCategory.TACTICAL, "Oil-resistant heavy lug sole boots built for industrial warfare.", 14500L, 0xFF451A03, armorBonus = 5f),
        ClothingItem("shoes_oxfords", "Handcrafted Italian Leather Oxfords", ClothingSlot.FOOTWEAR, OutfitCategory.FORMAL, "Full-grain calfskin dress shoes with blake-stitched leather sole.", 48000L, 0xFF18181B),
        ClothingItem("shoes_tactical_boots", "Silent Tread Assault Boots", ClothingSlot.FOOTWEAR, OutfitCategory.TACTICAL, "Vibram stealth sole boots with ankle stabilizer shank.", 19000L, 0xFF0F172A),
        ClothingItem("shoes_driving_mocs", "Perforated Suede Driving Moccasins", ClothingSlot.FOOTWEAR, OutfitCategory.CASUAL, "Ultra-flexible driving loafers with rubber pebble sole.", 34000L, 0xFF78350F),

        // Headwear
        ClothingItem("head_flat_cap", "Charcoal Herringbone Flat Cap", ClothingSlot.HEADWEAR, OutfitCategory.FORMAL, "Classic gentleman driver cap.", 3200L, 0xFF334155),
        ClothingItem("head_snapback", "Karachi Metro Embroidered Snapback", ClothingSlot.HEADWEAR, OutfitCategory.STREET, "Flat-brim street cap with 3D metallic embroidery.", 2400L, 0xFF0F172A),
        ClothingItem("head_balaclava", "Kevlar Thermal Balaclava", ClothingSlot.HEADWEAR, OutfitCategory.TACTICAL, "Conceals identity from police surveillance and CCTV.", 4500L, 0xFF020617, armorBonus = 5f),

        // Eyewear
        ClothingItem("eye_aviators_gold", "24K Gold Plated Luxury Aviators", ClothingSlot.EYEWEAR, OutfitCategory.FORMAL, "Polarized gradient lenses with 24k gold wire frames.", 38000L, 0xFFF59E0B),
        ClothingItem("eye_stealth_shades", "Polarized Matte Black Wayfarers", ClothingSlot.EYEWEAR, OutfitCategory.STREET, "Sleek low-profile tactical street sunglasses.", 5600L, 0xFF0F172A),
        ClothingItem("eye_hud_specs", "Encrypted Smart HUD Glasses", ClothingSlot.EYEWEAR, OutfitCategory.TACTICAL, "Displays police frequency alerts and GPS waypoint telemetry.", 85000L, 0xFF06B6D4),

        // Wristwear
        ClothingItem("wrist_chrono_gold", "Royal Chronograph 41mm Automatic", ClothingSlot.WRISTWEAR, OutfitCategory.FORMAL, "Swiss certified tourbillon with rose gold bezel.", 350000L, 0xFFF59E0B),
        ClothingItem("wrist_tactical_watch", "Mil-Spec Shock Barometer Watch", ClothingSlot.WRISTWEAR, OutfitCategory.TACTICAL, "Tough resin sports chronometer with compass and altimeter.", 16000L, 0xFF374151),
        ClothingItem("wrist_leather_cuff", "Braided Leather Double Wrap", ClothingSlot.WRISTWEAR, OutfitCategory.STREET, "Rustic tanned leather cord with brushed silver clasp.", 2800L, 0xFF78350F)
    )

    // Helper item lookups
    fun getItem(id: String): ClothingItem {
        return clothingCatalog.find { it.id == id } ?: clothingCatalog.first()
    }

    // ==========================================================================
    // DEFAULT OUTFITS
    // ==========================================================================

    val defaultAyanOutfits: List<CustomOutfit> = listOf(
        CustomOutfit(
            id = "ayan_outfit_street",
            protagonistId = "ayan",
            name = "Street Runner",
            category = OutfitCategory.STREET,
            upperBody = getItem("ayan_hoodie_blk"),
            lowerBody = getItem("lower_biker_jeans"),
            footwear = getItem("shoes_neon_runners"),
            headwear = getItem("head_snapback"),
            eyewear = getItem("eye_stealth_shades"),
            wristwear = getItem("wrist_leather_cuff")
        ),
        CustomOutfit(
            id = "ayan_outfit_tactical",
            protagonistId = "ayan",
            name = "Covert Night Infiltrator",
            category = OutfitCategory.TACTICAL,
            upperBody = getItem("ayan_stealth_knit"),
            lowerBody = getItem("lower_cargo_joggers"),
            footwear = getItem("shoes_tactical_boots"),
            headwear = getItem("head_balaclava"),
            eyewear = getItem("eye_stealth_shades"),
            wristwear = getItem("wrist_tactical_watch")
        ),
        CustomOutfit(
            id = "ayan_outfit_weather",
            protagonistId = "ayan",
            name = "Coastal Storm Anorak",
            category = OutfitCategory.WEATHER,
            upperBody = getItem("ayan_anorak_neon"),
            lowerBody = getItem("lower_cargo_joggers"),
            footwear = getItem("shoes_neon_runners"),
            headwear = getItem("head_snapback")
        ),
        CustomOutfit(
            id = "ayan_outfit_formal",
            protagonistId = "ayan",
            name = "Velvet Club Royale",
            category = OutfitCategory.FORMAL,
            upperBody = getItem("ayan_blazer_crimson"),
            lowerBody = getItem("lower_dress_trousers"),
            footwear = getItem("shoes_oxfords"),
            wristwear = getItem("wrist_chrono_gold")
        )
    )

    val defaultShahrozOutfits: List<CustomOutfit> = listOf(
        CustomOutfit(
            id = "shahroz_outfit_enforcer",
            protagonistId = "shahroz",
            name = "Dockland Enforcer",
            category = OutfitCategory.CASUAL,
            upperBody = getItem("shahroz_canvas_jacket"),
            lowerBody = getItem("lower_heavy_denim"),
            footwear = getItem("shoes_dock_boots"),
            wristwear = getItem("wrist_tactical_watch")
        ),
        CustomOutfit(
            id = "shahroz_outfit_tactical",
            protagonistId = "shahroz",
            name = "Tactical Raid Armor",
            category = OutfitCategory.TACTICAL,
            upperBody = getItem("shahroz_plate_carrier"),
            lowerBody = getItem("lower_cargo_joggers"),
            footwear = getItem("shoes_dock_boots"),
            headwear = getItem("head_balaclava"),
            eyewear = getItem("eye_stealth_shades"),
            wristwear = getItem("wrist_tactical_watch")
        ),
        CustomOutfit(
            id = "shahroz_outfit_street",
            protagonistId = "shahroz",
            name = "Heavy Leather Biker",
            category = OutfitCategory.STREET,
            upperBody = getItem("shahroz_leather_biker"),
            lowerBody = getItem("lower_heavy_denim"),
            footwear = getItem("shoes_dock_boots"),
            eyewear = getItem("eye_stealth_shades"),
            wristwear = getItem("wrist_leather_cuff")
        ),
        CustomOutfit(
            id = "shahroz_outfit_formal",
            protagonistId = "shahroz",
            name = "Syndicate Double Overcoat",
            category = OutfitCategory.FORMAL,
            upperBody = getItem("shahroz_double_coat"),
            lowerBody = getItem("lower_dress_trousers"),
            footwear = getItem("shoes_oxfords"),
            wristwear = getItem("wrist_chrono_gold")
        )
    )

    val defaultDaniyalOutfits: List<CustomOutfit> = listOf(
        CustomOutfit(
            id = "daniyal_outfit_executive",
            protagonistId = "daniyal",
            name = "Clifton Pinstripe Executive",
            category = OutfitCategory.FORMAL,
            upperBody = getItem("daniyal_suit_pinstripe"),
            lowerBody = getItem("lower_dress_trousers"),
            footwear = getItem("shoes_oxfords"),
            eyewear = getItem("eye_aviators_gold"),
            wristwear = getItem("wrist_chrono_gold")
        ),
        CustomOutfit(
            id = "daniyal_outfit_penthouse",
            protagonistId = "daniyal",
            name = "Penthouse Sand Cashmere",
            category = OutfitCategory.CASUAL,
            upperBody = getItem("daniyal_merino_mock"),
            lowerBody = getItem("lower_dress_trousers"),
            footwear = getItem("shoes_driving_mocs"),
            wristwear = getItem("wrist_chrono_gold")
        ),
        CustomOutfit(
            id = "daniyal_outfit_covert",
            protagonistId = "daniyal",
            name = "Executive Covert Trench",
            category = OutfitCategory.TACTICAL,
            upperBody = getItem("daniyal_trench_matte"),
            lowerBody = getItem("lower_cargo_joggers"),
            footwear = getItem("shoes_tactical_boots"),
            eyewear = getItem("eye_hud_specs"),
            wristwear = getItem("wrist_tactical_watch")
        ),
        CustomOutfit(
            id = "daniyal_outfit_riviera",
            protagonistId = "daniyal",
            name = "Riviera Yacht Deck",
            category = OutfitCategory.WEATHER,
            upperBody = getItem("daniyal_nautical_wind"),
            lowerBody = getItem("lower_deck_shorts"),
            footwear = getItem("shoes_driving_mocs"),
            eyewear = getItem("eye_aviators_gold")
        )
    )

    // ==========================================================================
    // INITIAL PROTAGONIST DATA
    // ==========================================================================

    val initialProtagonists: List<PlayableCharacterData> = listOf(
        PlayableCharacterData(
            id = "ayan",
            fullName = "Ayan Khan",
            alias = "The Ghost of Lyari",
            age = 24,
            title = "Street Racer & Urban Infiltrator",
            bio = "Born and raised in the maze-like back-alleys of Lyari. Highly agile, sharp-eyed, and intuitively attuned to urban navigation, motorcycles, and tuned sports cars. Loyal to his roots, but fiercely ambitious.",
            homeDistrictId = "lyari_blocks",
            homeDistrictName = "Lyari Blocks",
            currentDistrictId = "lyari_blocks",
            currentDistrictName = "Lyari Blocks",
            safehouseName = "Lyari Rooftop Flat & Workshop",
            safehouseDescription = "Modest top-floor apartment overlooking the dense alleyways, equipped with high-spec simulation rigs, tuner motorcycle parts, street art, and emergency rooftop escape lines.",
            worldPosX = 250f,
            worldPosY = 580f,
            cashBalancePkr = 185000L,
            baseStats = CharacterStats(
                health = 100f,
                maxHealth = 100f,
                stamina = 120f,
                maxStamina = 120f,
                strength = 62,
                agility = 92,
                driving = 86,
                shooting = 74,
                stealth = 88,
                endurance = 72,
                accuracy = 76,
                technicalSkill = 82,
                socialSkill = 65
            ),
            currentStats = CharacterStats(
                health = 100f,
                maxHealth = 100f,
                stamina = 120f,
                maxStamina = 120f,
                strength = 62,
                agility = 92,
                driving = 86,
                shooting = 74,
                stealth = 88,
                endurance = 72,
                accuracy = 76,
                technicalSkill = 82,
                socialSkill = 65
            ),
            movementProfile = MovementProfile(
                protagonistId = "ayan",
                sprintSpeedMultiplier = 1.30f,
                vaultSpeedSeconds = 0.38f,
                meleeKnockbackMultiplier = 0.85f,
                adsTransitionSeconds = 0.16f,
                recoilDampingFactor = 0.80f,
                signatureMovementStyle = "Agile Parkour Locomotion with rapid counter-directional cuts and fast recovery."
            ),
            activeOutfit = defaultAyanOutfits[0],
            appearance = FaceCustomization(
                presetId = 1,
                skinToneIndex = 2,
                hairstyleId = "Street Low Fade",
                facialHairId = "5 O'clock Stubble",
                scarId = "none"
            ),
            relationships = listOf(
                ProtagonistRelationship("shahroz", "Shahroz Malik", trustScore = 72, respectScore = 85, loyaltyScore = 80, hostilityScore = 15, relationshipStatus = "Respected Elder Operator", narrativeNotes = "Shahroz protects Ayan from harbor cartel cartels; Ayan provides fast underground courier runs."),
                ProtagonistRelationship("daniyal", "Daniyal Qureshi", trustScore = 48, respectScore = 65, loyaltyScore = 40, hostilityScore = 35, relationshipStatus = "Uneasy Alliance", narrativeNotes = "Distrusts Daniyal's billionaire corporate veneer, but acknowledges his indispensable financial corridors and tech tools.")
            ),
            assignedVehicleId = "bike_yamaha_r6",
            equippedPrimaryWeaponId = "smg_mp5",
            equippedSecondaryWeaponId = "pistol_9mm",
            portraitDrawableResName = "img_ayan_portrait",
            themeColorHex = 0xFF00E5FF
        ),

        PlayableCharacterData(
            id = "shahroz",
            fullName = "Shahroz Malik",
            alias = "The Port Enforcer",
            age = 39,
            title = "Tactical Enforcer & Heavy Operations",
            bio = "Former private security commander turned independent harbor logistics boss. A veteran who commands respect with quiet authority, tactical discipline, and lethal proficiency with heavy ordnance.",
            homeDistrictId = "port_district",
            homeDistrictName = "Port District",
            currentDistrictId = "port_district",
            currentDistrictName = "Port District",
            safehouseName = "Port Salvage Yard & Heavy Bunker",
            safehouseDescription = "Reinforced shipyard workshop with steel container blast walls, heavy weapons rack, armoring hoist, satellite uplink, and subterranean escape tunnel to the docks.",
            worldPosX = 380f,
            worldPosY = 780f,
            cashBalancePkr = 1450000L,
            baseStats = CharacterStats(
                health = 130f,
                maxHealth = 130f,
                stamina = 95f,
                maxStamina = 95f,
                strength = 95,
                agility = 64,
                driving = 78,
                shooting = 92,
                stealth = 58,
                endurance = 94,
                accuracy = 82,
                technicalSkill = 64,
                socialSkill = 72
            ),
            currentStats = CharacterStats(
                health = 130f,
                maxHealth = 130f,
                stamina = 95f,
                maxStamina = 95f,
                strength = 95,
                agility = 64,
                driving = 78,
                shooting = 92,
                stealth = 58,
                endurance = 94,
                accuracy = 82,
                technicalSkill = 64,
                socialSkill = 72
            ),
            movementProfile = MovementProfile(
                protagonistId = "shahroz",
                sprintSpeedMultiplier = 0.95f,
                vaultSpeedSeconds = 0.65f,
                meleeKnockbackMultiplier = 1.45f,
                adsTransitionSeconds = 0.24f,
                recoilDampingFactor = 1.40f,
                signatureMovementStyle = "Grounded heavy combat stance with devastating shoulder-tackle melee and zero-flinch weapon brace."
            ),
            activeOutfit = defaultShahrozOutfits[0],
            appearance = FaceCustomization(
                presetId = 2,
                skinToneIndex = 3,
                hairstyleId = "Textured Crew Cut",
                facialHairId = "Full Tactical Beard",
                scarId = "Right Brow Scar"
            ),
            relationships = listOf(
                ProtagonistRelationship("ayan", "Ayan Khan", trustScore = 80, respectScore = 78, loyaltyScore = 88, hostilityScore = 10, relationshipStatus = "Protective Mentor", narrativeNotes = "Sees younger self in Ayan's street grit, though frequently reprimands his impulsive speed."),
                ProtagonistRelationship("daniyal", "Daniyal Qureshi", trustScore = 55, respectScore = 75, loyaltyScore = 50, hostilityScore = 30, relationshipStatus = "Strategic Business Partner", narrativeNotes = "Partners on major maritime contraband clearing; keeps private leverage on Daniyal's shell accounts.")
            ),
            assignedVehicleId = "suv_landcruiser_v8",
            equippedPrimaryWeaponId = "ar_ak47",
            equippedSecondaryWeaponId = "shotgun_remington",
            portraitDrawableResName = "img_shahroz_portrait",
            themeColorHex = 0xFFFF4444
        ),

        PlayableCharacterData(
            id = "daniyal",
            fullName = "Daniyal Qureshi",
            alias = "The Cantonment Financier",
            age = 31,
            title = "Billionaire Tech & Capital Architect",
            bio = "Heir to an old-money shipping and real estate dynasty with degrees in cybersecurity and economics. Smooth, sharp-witted, with a calculated understanding of high-stakes corporate power, digital espionage, and precision.",
            homeDistrictId = "defence_gardens",
            homeDistrictName = "Defence Gardens",
            currentDistrictId = "defence_gardens",
            currentDistrictName = "Defence Gardens",
            safehouseName = "Defence Gardens Gated Compound & Penthouse",
            safehouseDescription = "Ultra-modern architectural villa with glass garage showroom, encrypted fiber server room, helipad access, panoramic terrace overlooking Clifton shoreline, and walk-in tailored wardrobe.",
            worldPosX = 620f,
            worldPosY = 450f,
            cashBalancePkr = 28500000L,
            baseStats = CharacterStats(
                health = 100f,
                maxHealth = 100f,
                stamina = 100f,
                maxStamina = 100f,
                strength = 64,
                agility = 74,
                driving = 88,
                shooting = 84,
                stealth = 78,
                endurance = 70,
                accuracy = 96,
                technicalSkill = 98,
                socialSkill = 98
            ),
            currentStats = CharacterStats(
                health = 100f,
                maxHealth = 100f,
                stamina = 100f,
                maxStamina = 100f,
                strength = 64,
                agility = 74,
                driving = 88,
                shooting = 84,
                stealth = 78,
                endurance = 70,
                accuracy = 96,
                technicalSkill = 98,
                socialSkill = 98
            ),
            movementProfile = MovementProfile(
                protagonistId = "daniyal",
                sprintSpeedMultiplier = 1.05f,
                vaultSpeedSeconds = 0.52f,
                meleeKnockbackMultiplier = 0.95f,
                adsTransitionSeconds = 0.14f,
                recoilDampingFactor = 1.05f,
                signatureMovementStyle = "Refined upright executive posture with rapid precision aim-down-sights snap and stealth utility deployment."
            ),
            activeOutfit = defaultDaniyalOutfits[0],
            appearance = FaceCustomization(
                presetId = 3,
                skinToneIndex = 1,
                hairstyleId = "Slicked Back Pompadour",
                facialHairId = "Sculpted Royal Goatee",
                scarId = "none"
            ),
            relationships = listOf(
                ProtagonistRelationship("ayan", "Ayan Khan", trustScore = 52, respectScore = 70, loyaltyScore = 45, hostilityScore = 25, relationshipStatus = "Valued High-Speed Asset", narrativeNotes = "Appreciates Ayan's untouchable getaway agility; supplies him with encrypted trackers and high-end rides."),
                ProtagonistRelationship("shahroz", "Shahroz Malik", trustScore = 65, respectScore = 88, loyaltyScore = 60, hostilityScore = 20, relationshipStatus = "Heavy Logistics Ally", narrativeNotes = "Relies on Shahroz's ironclad control of the port customs gates to safeguard his multi-million dollar import shipments.")
            ),
            assignedVehicleId = "supercar_ferrari_f8",
            equippedPrimaryWeaponId = "ar_m4a1",
            equippedSecondaryWeaponId = "sniper_awp",
            portraitDrawableResName = "img_daniyal_portrait",
            themeColorHex = 0xFFFFB703
        )
    )

    // ==========================================================================
    // ROOM DATABASE OPERATIONS
    // ==========================================================================

    suspend fun saveProtagonistStateToDb(character: PlayableCharacterData) {
        val entity = ProtagonistStateEntity(
            protagonistId = character.id,
            currentDistrictId = character.currentDistrictId,
            currentDistrictName = character.currentDistrictName,
            worldPosX = character.worldPosX,
            worldPosY = character.worldPosY,
            worldRotationZ = character.worldRotationZ,
            health = character.currentStats.health,
            armor = 50f,
            stamina = character.currentStats.stamina,
            cashBalancePkr = character.cashBalancePkr,
            equippedPrimaryWeaponId = character.equippedPrimaryWeaponId,
            equippedSecondaryWeaponId = character.equippedSecondaryWeaponId,
            assignedVehicleId = character.assignedVehicleId,
            activeOutfitName = character.activeOutfit.name,
            upperBodyId = character.activeOutfit.upperBody.id,
            lowerBodyId = character.activeOutfit.lowerBody.id,
            footwearId = character.activeOutfit.footwear.id,
            headwearId = character.activeOutfit.headwear?.id ?: "none",
            eyewearId = character.activeOutfit.eyewear?.id ?: "none",
            wristwearId = character.activeOutfit.wristwear?.id ?: "none",
            facePresetId = character.appearance.presetId,
            hairstyleId = character.appearance.hairstyleId,
            facialHairId = character.appearance.facialHairId,
            statStrength = character.currentStats.strength,
            statAgility = character.currentStats.agility,
            statDriving = character.currentStats.driving,
            statShooting = character.currentStats.shooting,
            statStealth = character.currentStats.stealth,
            statEndurance = character.currentStats.endurance,
            statAccuracy = character.currentStats.accuracy,
            statTechnical = character.currentStats.technicalSkill,
            statSocial = character.currentStats.socialSkill,
            relationshipAyan = character.relationships.find { it.targetProtagonistId == "ayan" }?.trustScore ?: 50,
            relationshipShahroz = character.relationships.find { it.targetProtagonistId == "shahroz" }?.trustScore ?: 50,
            relationshipDaniyal = character.relationships.find { it.targetProtagonistId == "daniyal" }?.trustScore ?: 50
        )
        worldDao.saveProtagonistState(entity)
    }

    suspend fun loadProtagonistStateFromDb(id: String): ProtagonistStateEntity? {
        return worldDao.getProtagonistStateById(id)
    }

    suspend fun saveCustomOutfit(outfit: CustomOutfit): Long {
        val entity = CustomOutfitEntity(
            protagonistId = outfit.protagonistId,
            outfitName = outfit.name,
            outfitCategory = outfit.category.name,
            upperBodyId = outfit.upperBody.id,
            lowerBodyId = outfit.lowerBody.id,
            footwearId = outfit.footwear.id,
            headwearId = outfit.headwear?.id ?: "none",
            eyewearId = outfit.eyewear?.id ?: "none",
            wristwearId = outfit.wristwear?.id ?: "none",
            isEquipped = true
        )
        return worldDao.insertCustomOutfit(entity)
    }

    fun getCustomOutfitsForProtagonist(protagonistId: String): Flow<List<CustomOutfitEntity>> {
        return worldDao.getOutfitsForProtagonist(protagonistId)
    }
}
