package com.example.data.model

object UE5CharacterArchitectureData {

    val karachiCharacterHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiCharacterSystem / Public / KarachiProtagonistCharacter.h
// ==============================================================================
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "GameplayTagContainer.h"
#include "KarachiProtagonistCharacter.generated.h"

class UWardrobeComponent;
class UCombatComponent;
class UInteractionComponent;
class UCameraComponent;
class USpringArmComponent;

UENUM(BlueprintType)
enum class EProtagonistType : uint8
{
    Ayan       UMETA(DisplayName = "Ayan Khan (Lyari Urban Infiltrator)"),
    Shahroz    UMETA(DisplayName = "Shahroz Malik (Port Tactical Enforcer)"),
    Daniyal    UMETA(DisplayName = "Daniyal Qureshi (Cantonment Tech Financier)")
};

USTRUCT(BlueprintType)
struct FKarachiCharacterStats
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float Health = 100.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float Armor = 50.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float Stamina = 100.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    int32 Strength = 70;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    int32 Agility = 70;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    int32 DrivingSkill = 70;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    int32 ShootingSkill = 70;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    int32 StealthSkill = 70;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    int32 TechnicalSkill = 70;
};

UCLASS()
class KARACHIMETRO_API AKarachiProtagonistCharacter : public ACharacter
{
    GENERATED_BODY()

public:
    AKarachiProtagonistCharacter();

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Protagonist")
    EProtagonistType ProtagonistId;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    TObjectPtr<UWardrobeComponent> WardrobeComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    TObjectPtr<UCombatComponent> CombatComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    TObjectPtr<UInteractionComponent> InteractionComponent;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    TObjectPtr<USpringArmComponent> CameraBoom;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    TObjectPtr<UCameraComponent> FollowCamera;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    FKarachiCharacterStats CharacterStats;

    UFUNCTION(BlueprintCallable, Category = "Protagonist")
    void ApplyMovementProfile();

    UFUNCTION(BlueprintCallable, Category = "Protagonist")
    void OnSwitchActivated(bool bCinematicTransition);

    UFUNCTION(BlueprintCallable, Category = "Protagonist")
    void OnSwitchDeactivated();

protected:
    virtual void BeginPlay() override;
    virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
};
    """.trimIndent()

    val characterSwitchSubsystemHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiCharacterSystem / Public / KarachiCharacterSwitchSubsystem.h
// ==============================================================================
#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "KarachiProtagonistCharacter.h"
#include "KarachiCharacterSwitchSubsystem.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnCharacterSwitchCompleted, EProtagonistType, NewProtagonist, FVector, NewLocation);

UCLASS()
class KARACHIMETRO_API UKarachiCharacterSwitchSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Character Switch")
    void SwitchToProtagonist(EProtagonistType TargetProtagonist, bool bCinematicCamera = true);

    UFUNCTION(BlueprintPure, Category = "Character Switch")
    EProtagonistType GetActiveProtagonist() const { return CurrentProtagonist; }

    UFUNCTION(BlueprintPure, Category = "Character Switch")
    FVector GetProtagonistWorldLocation(EProtagonistType Protagonist) const;

    UPROPERTY(BlueprintAssignable, Category = "Character Switch")
    FOnCharacterSwitchCompleted OnSwitchCompleted;

private:
    EProtagonistType CurrentProtagonist = EProtagonistType::Ayan;
    TMap<EProtagonistType, FTransform> ProtagonistWorldTransforms;

    void ExecuteCinematicCameraSequence(const FVector& StartPos, const FVector& EndPos, EProtagonistType Target);
    void StreamTargetWorldPartitionCells(const FVector& TargetLocation);
};
    """.trimIndent()

    val wardrobeComponentHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiCharacterSystem / Public / WardrobeComponent.h
// ==============================================================================
#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Engine/DataTable.h"
#include "WardrobeComponent.generated.h"

UENUM(BlueprintType)
enum class EClothingSlotType : uint8
{
    UpperBody,
    LowerBody,
    Footwear,
    Headwear,
    Eyewear,
    Wristwear,
    Accessories
};

USTRUCT(BlueprintType)
struct FClothingItemData : public FTableRowBase
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    FText DisplayName;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    EClothingSlotType Slot;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    TSoftObjectPtr<USkeletalMesh> MeshAsset;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float ArmorBonus = 0.0f;
};

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class KARACHIMETRO_API UWardrobeComponent : public UActorComponent
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Wardrobe")
    void EquipClothingItem(FName ItemId);

    UFUNCTION(BlueprintCallable, Category = "Wardrobe")
    void LoadOutfitPreset(FName OutfitPresetId);

    UFUNCTION(BlueprintCallable, Category = "Wardrobe")
    void SaveCurrentAsCustomOutfit(int32 SlotIndex);

protected:
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Meshes")
    TMap<EClothingSlotType, TObjectPtr<USkeletalMeshComponent>> ModularMeshSlots;
};
    """.trimIndent()
}
