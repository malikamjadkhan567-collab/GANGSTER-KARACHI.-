package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "saved_markers")
data class SavedMarkerEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val note: String,
    val posX: Float,
    val posY: Float,
    val districtName: String,
    val markerType: String, // WAYPOINT, INTEL, SAFEHOUSE, CUSTOM
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "discovered_districts")
data class DiscoveredDistrictEntity(
    @PrimaryKey val districtId: String,
    val isDiscovered: Boolean = true,
    val fastTravelUnlocked: Boolean = false,
    val discoveredTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "garage_vehicles")
data class SavedVehicleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val vehicleId: String,
    val customName: String,
    val ownerProtagonistId: String, // ayan, shahroz, daniyal
    val paintColorHex: Long,
    val paintFinish: String,
    val windowTintPct: Int,
    val spoilerStage: Int,
    val engineTuneStage: Int,
    val turboInstalled: Boolean,
    val sportSuspension: Boolean,
    val raceBrakes: Boolean,
    val sportTires: Boolean,
    val armorPlating: Boolean,
    val mileageKm: Float = 0f,
    val conditionPct: Float = 100f,
    val fuelLevelPct: Float = 100f,
    val parkedDistrictId: String = "downtown",
    val isFavorite: Boolean = false,
    val savedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "saved_weapons")
data class SavedWeaponEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val weaponId: String,
    val customName: String,
    val ownerProtagonistId: String, // ayan, shahroz, daniyal
    val slotType: String, // PRIMARY, SECONDARY, HEAVY, MELEE, UTILITY
    val currentAmmo: Int,
    val reserveAmmo: Int,
    val isEquipped: Boolean = false,
    val suppressorAttached: Boolean = false,
    val opticAttached: String = "NONE",
    val extendedMagAttached: Boolean = false,
    val laserAttached: Boolean = false,
    val savedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "protagonist_states")
data class ProtagonistStateEntity(
    @PrimaryKey val protagonistId: String, // ayan, shahroz, daniyal
    val currentDistrictId: String,
    val currentDistrictName: String,
    val worldPosX: Float,
    val worldPosY: Float,
    val worldRotationZ: Float = 0f,
    val health: Float = 100f,
    val armor: Float = 50f,
    val stamina: Float = 100f,
    val cashBalancePkr: Long,
    val equippedPrimaryWeaponId: String,
    val equippedSecondaryWeaponId: String,
    val assignedVehicleId: String,
    val activeOutfitName: String,
    val upperBodyId: String,
    val lowerBodyId: String,
    val footwearId: String,
    val headwearId: String = "none",
    val eyewearId: String = "none",
    val wristwearId: String = "none",
    val facePresetId: Int = 1,
    val hairstyleId: String = "default",
    val facialHairId: String = "default",
    val statStrength: Int,
    val statAgility: Int,
    val statDriving: Int,
    val statShooting: Int,
    val statStealth: Int,
    val statEndurance: Int,
    val statAccuracy: Int,
    val statTechnical: Int,
    val statSocial: Int,
    val relationshipAyan: Int = 50,
    val relationshipShahroz: Int = 50,
    val relationshipDaniyal: Int = 50,
    val lastSavedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "custom_outfits")
data class CustomOutfitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val protagonistId: String,
    val outfitName: String,
    val outfitCategory: String, // CASUAL, FORMAL, STREET, TACTICAL, WEATHER, CUSTOM
    val upperBodyId: String,
    val lowerBodyId: String,
    val footwearId: String,
    val headwearId: String = "none",
    val eyewearId: String = "none",
    val wristwearId: String = "none",
    val isEquipped: Boolean = false,
    val savedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "mission_progress")
data class MissionProgressEntity(
    @PrimaryKey val missionId: String,
    val status: String, // LOCKED, AVAILABLE, IN_PROGRESS, COMPLETED, FAILED
    val scoreRating: String = "BRONZE", // GOLD, SILVER, BRONZE
    val completedTimestamp: Long = 0L,
    val bestTimeSeconds: Int = 0
)

@Entity(tableName = "faction_reputations")
data class FactionReputationEntity(
    @PrimaryKey val factionId: String,
    val reputationScore: Int, // -100 to +100
    val standingLevel: String, // HOSTILE, UNFRIENDLY, NEUTRAL, ALLIED, HONORED
    val lastUpdatedTimestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "world_simulation_state")
data class WorldSimulationEntity(
    @PrimaryKey val stateId: String = "primary_simulation",
    val dayNumber: Int,
    val hour: Int,
    val minute: Int,
    val second: Int,
    val dayOfWeek: String,
    val season: String,
    val timeSpeedMultiplier: Float,
    val weatherType: String,
    val rainIntensity: Float,
    val fogDensity: Float,
    val windSpeedKmh: Float,
    val windBearingDegrees: Float,
    val streetLightsActive: Boolean,
    val lastSavedTimestamp: Long = System.currentTimeMillis()
)


