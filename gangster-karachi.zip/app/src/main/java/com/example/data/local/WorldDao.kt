package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface WorldDao {
    @Query("SELECT * FROM saved_markers ORDER BY timestamp DESC")
    fun getAllMarkers(): Flow<List<SavedMarkerEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMarker(marker: SavedMarkerEntity): Long

    @Delete
    suspend fun deleteMarker(marker: SavedMarkerEntity)

    @Query("DELETE FROM saved_markers WHERE id = :id")
    suspend fun deleteMarkerById(id: Long)

    @Query("SELECT * FROM discovered_districts")
    fun getDiscoveredDistricts(): Flow<List<DiscoveredDistrictEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setDistrictDiscovered(entity: DiscoveredDistrictEntity)

    // Garage Vehicle Persistence
    @Query("SELECT * FROM garage_vehicles ORDER BY isFavorite DESC, savedTimestamp DESC")
    fun getAllGarageVehicles(): Flow<List<SavedVehicleEntity>>

    @Query("SELECT * FROM garage_vehicles WHERE ownerProtagonistId = :ownerId ORDER BY savedTimestamp DESC")
    fun getGarageVehiclesByOwner(ownerId: String): Flow<List<SavedVehicleEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGarageVehicle(vehicle: SavedVehicleEntity): Long

    @Delete
    suspend fun deleteGarageVehicle(vehicle: SavedVehicleEntity)

    @Query("DELETE FROM garage_vehicles WHERE id = :id")
    suspend fun deleteGarageVehicleById(id: Long)

    // Weapon Inventory Persistence
    @Query("SELECT * FROM saved_weapons ORDER BY isEquipped DESC, savedTimestamp DESC")
    fun getAllSavedWeapons(): Flow<List<SavedWeaponEntity>>

    @Query("SELECT * FROM saved_weapons WHERE ownerProtagonistId = :ownerId ORDER BY savedTimestamp DESC")
    fun getWeaponsByOwner(ownerId: String): Flow<List<SavedWeaponEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSavedWeapon(weapon: SavedWeaponEntity): Long

    @Delete
    suspend fun deleteSavedWeapon(weapon: SavedWeaponEntity)

    @Query("DELETE FROM saved_weapons WHERE id = :id")
    suspend fun deleteSavedWeaponById(id: Long)

    // Protagonist State Persistence (Master Prompt 04)
    @Query("SELECT * FROM protagonist_states")
    fun getAllProtagonistStates(): Flow<List<ProtagonistStateEntity>>

    @Query("SELECT * FROM protagonist_states WHERE protagonistId = :id LIMIT 1")
    suspend fun getProtagonistStateById(id: String): ProtagonistStateEntity?

    @Query("SELECT * FROM protagonist_states WHERE protagonistId = :id LIMIT 1")
    fun observeProtagonistStateById(id: String): Flow<ProtagonistStateEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveProtagonistState(state: ProtagonistStateEntity)

    @Query("UPDATE protagonist_states SET worldPosX = :posX, worldPosY = :posY, currentDistrictId = :districtId, currentDistrictName = :districtName WHERE protagonistId = :id")
    suspend fun updateProtagonistLocation(id: String, posX: Float, posY: Float, districtId: String, districtName: String)

    @Query("UPDATE protagonist_states SET health = :health, armor = :armor, stamina = :stamina WHERE protagonistId = :id")
    suspend fun updateProtagonistHealth(id: String, health: Float, armor: Float, stamina: Float)

    @Query("UPDATE protagonist_states SET cashBalancePkr = :cash WHERE protagonistId = :id")
    suspend fun updateProtagonistCash(id: String, cash: Long)

    // Custom Outfit Persistence
    @Query("SELECT * FROM custom_outfits WHERE protagonistId = :protagonistId ORDER BY savedTimestamp DESC")
    fun getOutfitsForProtagonist(protagonistId: String): Flow<List<CustomOutfitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomOutfit(outfit: CustomOutfitEntity): Long

    @Delete
    suspend fun deleteCustomOutfit(outfit: CustomOutfitEntity)

    @Query("DELETE FROM custom_outfits WHERE id = :id")
    suspend fun deleteCustomOutfitById(id: Long)

    // Master Prompt 05: Story Mission & Faction Persistence
    @Query("SELECT * FROM mission_progress")
    fun getAllMissionProgress(): Flow<List<MissionProgressEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMissionProgress(entity: MissionProgressEntity)

    @Query("UPDATE mission_progress SET status = :status, scoreRating = :rating, completedTimestamp = :timestamp WHERE missionId = :id")
    suspend fun updateMissionStatus(id: String, status: String, rating: String, timestamp: Long)

    @Query("SELECT * FROM faction_reputations")
    fun getAllFactionReputations(): Flow<List<FactionReputationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveFactionReputation(entity: FactionReputationEntity)

    @Query("UPDATE faction_reputations SET reputationScore = :score, standingLevel = :standing WHERE factionId = :id")
    suspend fun updateFactionScore(id: String, score: Int, standing: String)

    // Master Prompt 06: World Simulation State Persistence
    @Query("SELECT * FROM world_simulation_state WHERE stateId = :id LIMIT 1")
    fun getWorldSimulationState(id: String = "primary_simulation"): Flow<WorldSimulationEntity?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveWorldSimulationState(entity: WorldSimulationEntity)
}
