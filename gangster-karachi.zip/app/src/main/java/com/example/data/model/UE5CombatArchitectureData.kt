package com.example.data.model

object UE5CombatArchitectureData {

    val weaponDataAssetHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiCombatSystem / Public / KarachiWeaponDataAsset.h
// Description: UPrimaryDataAsset defining complete ballistic, recoil, audio & VFX specs
// Engine Target: Unreal Engine 5.4+ (Enhanced Input + Niagara + Lumen + Chaos Damage)
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "KarachiWeaponDataAsset.generated.h"

UENUM(BlueprintType)
enum class EWeaponClassification : uint8
{
    Pistol UMETA(DisplayName = "Handgun / Pistol"),
    SubmachineGun UMETA(DisplayName = "Submachine Gun (SMG)"),
    AssaultRifle UMETA(DisplayName = "Assault Rifle"),
    Shotgun UMETA(DisplayName = "Shotgun"),
    MarksmanRifle UMETA(DisplayName = "Marksman / Sniper"),
    HeavyOrdnance UMETA(DisplayName = "Heavy Weapon (RPG / Grenade Launcher)"),
    MeleeWeapon UMETA(DisplayName = "Close Quarters Melee")
};

UENUM(BlueprintType)
enum class EWeaponFiringMode : uint8
{
    SemiAuto UMETA(DisplayName = "Semi-Automatic"),
    FullAuto UMETA(DisplayName = "Fully Automatic"),
    Burst UMETA(DisplayName = "3-Round Burst"),
    PumpAction UMETA(DisplayName = "Pump Action"),
    BoltAction UMETA(DisplayName = "Bolt Action"),
    MeleeSwing UMETA(DisplayName = "Melee Swing")
};

USTRUCT(BlueprintType)
struct KARACHICOMBATSYSTEM_API FWeaponRecoilSpecification
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Recoil")
    float VerticalKickDegrees = 2.2f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Recoil")
    float HorizontalDriftDegrees = 0.6f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Recoil")
    float RecoilRecoverySpeed = 8.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Recoil")
    float CrosshairBloomSpreadDeg = 1.4f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Recoil")
    float AimDownSightsDampingFactor = 0.55f;
};

UCLASS(BlueprintType)
class KARACHICOMBATSYSTEM_API UKarachiWeaponDataAsset : public UPrimaryDataAsset
{
    GENERATED_BODY()

public:
    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
    FName WeaponID;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
    FText DisplayName;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Identity")
    FText Manufacturer;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Classification")
    EWeaponClassification Category;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Classification")
    EWeaponFiringMode FiringMode;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Ballistics")
    float BaseDamage = 45.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Ballistics")
    float EffectiveRangeCm = 15000.0f; // 150 meters

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Ballistics")
    int32 FireRateRPM = 650;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Magazine & Ammo")
    int32 MagazineCapacity = 30;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Magazine & Ammo")
    float ReloadTimeSeconds = 2.1f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Recoil & Bloom")
    FWeaponRecoilSpecification RecoilProfile;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio Profiles")
    TSoftObjectPtr<USoundBase> FireSound;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Audio Profiles")
    TSoftObjectPtr<USoundBase> SuppressedFireSound;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "VFX Profiles")
    TSoftObjectPtr<class UNiagaraSystem> MuzzleFlashNiagara;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "VFX Profiles")
    TSoftObjectPtr<class UNiagaraSystem> ShellEjectionNiagara;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Protagonist Affinity")
    FName RecommendedProtagonist; // Ayan, Shahroz, Daniyal
};
""".trimIndent()

    val weaponBaseHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiCombatSystem / Public / KarachiWeaponBase.h
// Description: Core AActor base class for all weapons, ballistics, and recoil handling
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "KarachiWeaponDataAsset.h"
#include "KarachiWeaponBase.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnAmmoChangedSignature, int32, CurrentAmmo, int32, ReserveAmmo);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FOnWeaponFiredSignature, const FVector&, MuzzleLocation, const FVector&, ShotDirection, bool, bSilenced);

UENUM(BlueprintType)
enum class EPlayerAimMode : uint8
{
    HipFire UMETA(DisplayName = "Hip Fire"),
    ShoulderAim UMETA(DisplayName = "Shoulder Aim"),
    AimDownSights UMETA(DisplayName = "Aim Down Sights (ADS)")
};

UCLASS(Abstract)
class KARACHICOMBATSYSTEM_API AKarachiWeaponBase : public AActor
{
    GENERATED_BODY()

public:
    AKarachiWeaponBase();

    virtual void Tick(float DeltaTime) override;

    UFUNCTION(BlueprintCallable, Category = "Weapon Fire")
    virtual bool StartFire();

    UFUNCTION(BlueprintCallable, Category = "Weapon Fire")
    virtual void StopFire();

    UFUNCTION(BlueprintCallable, Category = "Weapon Fire")
    virtual bool TriggerReload();

    UFUNCTION(BlueprintCallable, Category = "Weapon Aim")
    void SetAimMode(EPlayerAimMode NewMode);

    UFUNCTION(BlueprintPure, Category = "Weapon State")
    int32 GetCurrentMagazineAmmo() const { return CurrentMagAmmo; }

    UFUNCTION(BlueprintPure, Category = "Weapon State")
    int32 GetCurrentReserveAmmo() const { return CurrentReserveAmmo; }

    UPROPERTY(BlueprintAssignable, Category = "Weapon Events")
    FOnAmmoChangedSignature OnAmmoChanged;

    UPROPERTY(BlueprintAssignable, Category = "Weapon Events")
    FOnWeaponFiredSignature OnWeaponFired;

protected:
    virtual void BeginPlay() override;

    void ExecuteLineTraceShot();
    void ApplyRecoilImpulse();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
    USkeletalMeshComponent* WeaponMesh;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Data")
    UKarachiWeaponDataAsset* WeaponData;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    int32 CurrentMagAmmo;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    int32 CurrentReserveAmmo;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    bool bIsFiring;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    bool bIsReloading;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "State")
    EPlayerAimMode CurrentAimMode;

    FTimerHandle FireRateTimerHandle;
    FTimerHandle ReloadTimerHandle;
};
""".trimIndent()

    val policeWantedSubsystemHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiCombatSystem / Public / KarachiPoliceWantedSubsystem.h
// Description: UWorldSubsystem orchestrating 5-Star Wanted Level, LKP Memory, and Dispatch
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "KarachiPoliceWantedSubsystem.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWantedLevelChangedSignature, int32, NewWantedStars);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnPoliceRadioDispatchSignature, const FString&, Callsign, const FString&, Message);

UENUM(BlueprintType)
enum class EPoliceSearchState : uint8
{
    InVisualContact UMETA(DisplayName = "Visual Contact Active"),
    LostVisualSearchingLKP UMETA(DisplayName = "Lost Visual - Searching Last Known Position"),
    DecayCooldown UMETA(DisplayName = "Search Cooldown / Evading"),
    AllClear UMETA(DisplayName = "All Clear / Pursuit Terminated")
};

USTRUCT(BlueprintType)
struct KARACHICOMBATSYSTEM_API FCrimeIncidentReport
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Crime")
    FName CrimeType;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Crime")
    FVector IncidentLocation;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Crime")
    FName DistrictID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Crime")
    bool bWitnessReported = true;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Crime")
    float HeatIncrease = 20.f;
};

UCLASS()
class KARACHICOMBATSYSTEM_API UKarachiPoliceWantedSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    virtual void Deinitialize() override;

    // Crime Reporting & Escalation
    UFUNCTION(BlueprintCallable, Category = "Karachi Police|Wanted")
    void ReportCrimeIncident(const FCrimeIncidentReport& Report);

    UFUNCTION(BlueprintCallable, Category = "Karachi Police|Wanted")
    void SetWantedLevel(int32 Stars);

    UFUNCTION(BlueprintPure, Category = "Karachi Police|Wanted")
    int32 GetCurrentWantedStars() const { return CurrentStars; }

    UFUNCTION(BlueprintPure, Category = "Karachi Police|Wanted")
    float GetCurrentPoliceHeat() const { return DistrictPoliceHeat; }

    UFUNCTION(BlueprintPure, Category = "Karachi Police|Memory")
    FVector GetLastKnownPlayerPosition() const { return LastKnownPosition; }

    // Visual Loss & Search Logic
    UFUNCTION(BlueprintCallable, Category = "Karachi Police|Pursuit")
    void OnPlayerEvadedLineOfSight(const FVector& FinalSeenLocation);

    UFUNCTION(BlueprintCallable, Category = "Karachi Police|Pursuit")
    void UpdateSearchDecay(float DeltaTime);

    UPROPERTY(BlueprintAssignable, Category = "Karachi Police|Events")
    FOnWantedLevelChangedSignature OnWantedLevelChanged;

    UPROPERTY(BlueprintAssignable, Category = "Karachi Police|Events")
    FOnPoliceRadioDispatchSignature OnPoliceRadioDispatch;

private:
    int32 CurrentStars = 0;
    float DistrictPoliceHeat = 0.f;
    FVector LastKnownPosition;
    float SearchDecayTimer = 0.f;
    EPoliceSearchState CurrentSearchPhase = EPoliceSearchState::AllClear;

    void BroadcastDispatchMessage(const FString& Callsign, const FString& Message);
    void DispatchUnitsForWantedLevel(int32 Stars);
};
""".trimIndent()
}
