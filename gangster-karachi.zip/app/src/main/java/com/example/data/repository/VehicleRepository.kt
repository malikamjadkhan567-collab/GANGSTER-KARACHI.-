package com.example.data.repository

import com.example.data.local.SavedVehicleEntity
import com.example.data.local.WorldDao
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlin.math.*

class VehicleRepository(private val worldDao: WorldDao) {

    val allVehicles: List<Vehicle> = listOf(
        // SPORTS & TUNERS
        Vehicle(
            id = "veh_khyber_rspec",
            name = "Khyber R-Spec 2.0T",
            manufacturer = "Khyber Motors",
            category = VehicleCategory.SPORTS,
            categorySubtitle = "Japanese Style Tuner Coupe",
            description = "A lightweight, rear-wheel-drive turbocharged street warrior engineered for high-revving agility and responsive drifting through the dense alleys of Saddar and Lyari.",
            protagonistAffinity = "Ayan Khan",
            defaultDistrictSpawn = "lyari_blocks",
            physics = VehiclePhysicsSpecs(
                massKg = 1240f,
                horsepower = 340,
                torqueNm = 420,
                topSpeedKmh = 275,
                acceleration0To100 = 4.2f,
                brakeForceKn = 14.5f,
                gearCount = 6,
                drivetrain = Drivetrain.RWD,
                dragCoefficient = 0.29f,
                suspensionTravelCm = 12f,
                suspensionStiffness = 0.75f,
                baseTireGrip = 0.95f,
                steeringAngleDeg = 38f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 4500000,
                sellPricePkr = 3200000,
                repairBaseCostPkr = 35000,
                insuranceCostPkr = 25000,
                rarityTier = "STREET"
            ),
            interiorDetail = "Alcantara sport bucket seats, carbon dash trim, analog boost gauge, red stitching, short-throw manual shifter.",
            audioProfile = "High-pitched 4-cylinder turbo spool, aggressive blow-off valve flutter, burble exhaust overrun.",
            isHeroVehicle = true
        ),
        Vehicle(
            id = "veh_indus_gtawd",
            name = "Indus GT-AWD Turbo",
            manufacturer = "Indus Velocity",
            category = VehicleCategory.SPORTS,
            categorySubtitle = "All-Wheel Drive Rally Coupe",
            description = "Torque-vectoring twin-scroll turbocharged coupe capable of unmatched launch traction in torrential coastal rains or loose dirt trails.",
            protagonistAffinity = "Ayan Khan",
            defaultDistrictSpawn = "tariq_bazaar",
            physics = VehiclePhysicsSpecs(
                massKg = 1480f,
                horsepower = 420,
                torqueNm = 550,
                topSpeedKmh = 290,
                acceleration0To100 = 3.6f,
                brakeForceKn = 16.0f,
                gearCount = 7,
                drivetrain = Drivetrain.AWD,
                dragCoefficient = 0.31f,
                suspensionTravelCm = 15f,
                suspensionStiffness = 0.70f,
                baseTireGrip = 1.05f,
                steeringAngleDeg = 35f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 8500000,
                sellPricePkr = 6000000,
                repairBaseCostPkr = 55000,
                insuranceCostPkr = 45000,
                rarityTier = "EXOTIC"
            ),
            interiorDetail = "Dual digital displays, rally handbrake, Recaro leather seats, steering-mounted shift paddles.",
            audioProfile = "Boxer turbo rumble, high-frequency anti-lag bangs on downshift.",
            isHeroVehicle = true
        ),
        Vehicle(
            id = "veh_bolan_predator",
            name = "Bolan V8 Predator",
            manufacturer = "Bolan Heavy Works",
            category = VehicleCategory.MUSCLE,
            categorySubtitle = "High-Torque American Style Muscle",
            description = "A raw, supercharged 6.2L V8 beast producing earth-shaking torque. Built for tire smoke and straight-line highway dominance on the Outer Expressway.",
            protagonistAffinity = "Shahroz Malik",
            defaultDistrictSpawn = "industrial_zone",
            physics = VehiclePhysicsSpecs(
                massKg = 1780f,
                horsepower = 650,
                torqueNm = 820,
                topSpeedKmh = 310,
                acceleration0To100 = 3.8f,
                brakeForceKn = 15.0f,
                gearCount = 6,
                drivetrain = Drivetrain.RWD,
                dragCoefficient = 0.36f,
                suspensionTravelCm = 13f,
                suspensionStiffness = 0.65f,
                baseTireGrip = 0.88f,
                steeringAngleDeg = 34f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 11000000,
                sellPricePkr = 7800000,
                repairBaseCostPkr = 65000,
                insuranceCostPkr = 60000,
                rarityTier = "EXOTIC"
            ),
            interiorDetail = "Retro analog speedometer, Hurst pistol-grip shifter, leather seats with contrast stripes.",
            audioProfile = "Deep guttural V8 cam lope at idle, deafening supercharger whine under wide-open throttle.",
            isHeroVehicle = true
        ),

        // EXOTICS & SUPERCARS
        Vehicle(
            id = "veh_daniyal_pegaso",
            name = "Pegaso V12 Hyperion",
            manufacturer = "Pegaso Automobili",
            category = VehicleCategory.SUPERCAR,
            categorySubtitle = "Italian Mid-Engine Hypercar",
            description = "A masterpiece of carbon-composite aerodynamics, active rear diffuser, and an 800-horsepower naturally aspirated V12 that screams down Clifton Heights at sunset.",
            protagonistAffinity = "Daniyal Qureshi",
            defaultDistrictSpawn = "defence_gardens",
            physics = VehiclePhysicsSpecs(
                massKg = 1320f,
                horsepower = 810,
                torqueNm = 760,
                topSpeedKmh = 355,
                acceleration0To100 = 2.8f,
                brakeForceKn = 22.0f,
                gearCount = 7,
                drivetrain = Drivetrain.RWD,
                dragCoefficient = 0.27f,
                suspensionTravelCm = 8f,
                suspensionStiffness = 0.90f,
                baseTireGrip = 1.15f,
                steeringAngleDeg = 33f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 75000000,
                sellPricePkr = 52000000,
                repairBaseCostPkr = 450000,
                insuranceCostPkr = 350000,
                rarityTier = "BLACK_MARKET"
            ),
            interiorDetail = "Carbon-fiber monocoque cockpit, digital telemetry HUD, center touchscreen, hand-stitched Italian leather.",
            audioProfile = "Screaming 9000 RPM V12 crescendo, laser-sharp throttle crackles, dual-clutch lightning shifts.",
            isHeroVehicle = true
        ),
        Vehicle(
            id = "veh_caledon_spitfire",
            name = "Caledon Spitfire GT",
            manufacturer = "Caledon Motors",
            category = VehicleCategory.SUPERCAR,
            categorySubtitle = "British Grand Touring Supercar",
            description = "Front-mid engine twin-turbocharged V8 grand tourer combining timeless elegance with devastating high-speed cruise performance.",
            protagonistAffinity = "Daniyal Qureshi",
            defaultDistrictSpawn = "clifton_heights",
            physics = VehiclePhysicsSpecs(
                massKg = 1590f,
                horsepower = 715,
                torqueNm = 900,
                topSpeedKmh = 340,
                acceleration0To100 = 3.2f,
                brakeForceKn = 18.5f,
                gearCount = 8,
                drivetrain = Drivetrain.RWD,
                dragCoefficient = 0.30f,
                suspensionTravelCm = 10f,
                suspensionStiffness = 0.80f,
                baseTireGrip = 1.08f,
                steeringAngleDeg = 34f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 55000000,
                sellPricePkr = 38000000,
                repairBaseCostPkr = 320000,
                insuranceCostPkr = 250000,
                rarityTier = "EXOTIC"
            ),
            interiorDetail = "Handcrafted walnut trim, acoustic insulated cabin, bespoke Bang & Olufsen sound system, ventilated luxury thrones.",
            audioProfile = "Sophisticated V8 baritone growl, explosive acoustic bypass valves on hard acceleration.",
            isHeroVehicle = false
        ),

        // SUVS & PICKUPS
        Vehicle(
            id = "veh_shahroz_marauder",
            name = "Marauder 4x4 Ironclad",
            manufacturer = "Sultan Heavy Industries",
            category = VehicleCategory.SUV,
            categorySubtitle = "Armored Off-Road Heavy Assault SUV",
            description = "A military-derived tactical 4x4 with reinforced steel underbody armor, run-flat tires, and high ground clearance capable of smashing through roadblocks.",
            protagonistAffinity = "Shahroz Malik",
            defaultDistrictSpawn = "port_district",
            physics = VehiclePhysicsSpecs(
                massKg = 2850f,
                horsepower = 480,
                torqueNm = 890,
                topSpeedKmh = 210,
                acceleration0To100 = 6.2f,
                brakeForceKn = 20.0f,
                gearCount = 8,
                drivetrain = Drivetrain.FOUR_BY_FOUR,
                dragCoefficient = 0.44f,
                suspensionTravelCm = 28f,
                suspensionStiffness = 0.60f,
                baseTireGrip = 0.95f,
                steeringAngleDeg = 32f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 22000000,
                sellPricePkr = 16000000,
                repairBaseCostPkr = 95000,
                insuranceCostPkr = 80000,
                rarityTier = "EXOTIC"
            ),
            interiorDetail = "Ballistic glass windows, tactical GPS monitor, heavy switchgear, roll cage, overhead communications console.",
            audioProfile = "Massive 6.7L turbo diesel roar, hydraulic brake hisses, turbo whistle.",
            isHeroVehicle = true
        ),
        Vehicle(
            id = "veh_clifton_imperial",
            name = "Clifton Imperial V8",
            manufacturer = "Indus Luxury Division",
            category = VehicleCategory.SUV,
            categorySubtitle = "Ultra-Luxury Executive Flagship SUV",
            description = "The undisputed status symbol of Defence Gardens and Clifton Heights. Features active air suspension, plush seating, and quiet twin-turbo V8 propulsion.",
            protagonistAffinity = "Daniyal Qureshi",
            defaultDistrictSpawn = "defence_gardens",
            physics = VehiclePhysicsSpecs(
                massKg = 2450f,
                horsepower = 560,
                torqueNm = 750,
                topSpeedKmh = 260,
                acceleration0To100 = 4.8f,
                brakeForceKn = 17.5f,
                gearCount = 8,
                drivetrain = Drivetrain.AWD,
                dragCoefficient = 0.35f,
                suspensionTravelCm = 20f,
                suspensionStiffness = 0.65f,
                baseTireGrip = 1.02f,
                steeringAngleDeg = 35f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 38000000,
                sellPricePkr = 27000000,
                repairBaseCostPkr = 180000,
                insuranceCostPkr = 140000,
                rarityTier = "EXOTIC"
            ),
            interiorDetail = "Panoramic sunroof, executive rear lounge with recliners and champagne fridge, dual infotainment displays.",
            audioProfile = "Whisper-quiet cruising with muted metallic exhaust surge under kickdown.",
            isHeroVehicle = false
        ),
        Vehicle(
            id = "veh_titan_flatbed",
            name = "Titan Dually Heavy Hauler",
            manufacturer = "Bolan Heavy Works",
            category = VehicleCategory.PICKUP,
            categorySubtitle = "Commercial Heavy Pickup Truck",
            description = "Shahroz's primary port scrapyard hauler. Twin rear wheels, massive steel bed, and indestructible mechanical linkages.",
            protagonistAffinity = "Shahroz Malik",
            defaultDistrictSpawn = "industrial_zone",
            physics = VehiclePhysicsSpecs(
                massKg = 3100f,
                horsepower = 400,
                torqueNm = 1050,
                topSpeedKmh = 180,
                acceleration0To100 = 8.0f,
                brakeForceKn = 24.0f,
                gearCount = 6,
                drivetrain = Drivetrain.FOUR_BY_FOUR,
                dragCoefficient = 0.48f,
                suspensionTravelCm = 24f,
                suspensionStiffness = 0.85f,
                baseTireGrip = 0.90f,
                steeringAngleDeg = 30f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 9500000,
                sellPricePkr = 6800000,
                repairBaseCostPkr = 45000,
                insuranceCostPkr = 40000,
                rarityTier = "STREET"
            ),
            interiorDetail = "Heavy vinyl durable seats, CB radio transceiver, mechanical column shifter, rubberized floor mats.",
            audioProfile = "Industrial inline-6 turbo diesel clatter with high-pressure air brake releases.",
            isHeroVehicle = true
        ),

        // MOTORCYCLES & BIKES
        Vehicle(
            id = "veh_ayan_cyclone",
            name = "Ayan Cyclone 125R",
            manufacturer = "Lyari Custom Speed",
            category = VehicleCategory.MOTORCYCLE,
            categorySubtitle = "Modified 125cc Street Rocket",
            description = "Ayan's custom-built street motorcycle. Stripped of excess weight, high-flow exhaust, extended swingarm, and razor-sharp steering for weaving through dense Saddar traffic.",
            protagonistAffinity = "Ayan Khan",
            defaultDistrictSpawn = "lyari_blocks",
            physics = VehiclePhysicsSpecs(
                massKg = 108f,
                horsepower = 24,
                torqueNm = 28,
                topSpeedKmh = 145,
                acceleration0To100 = 6.8f,
                brakeForceKn = 6.5f,
                gearCount = 5,
                drivetrain = Drivetrain.RWD,
                dragCoefficient = 0.38f,
                suspensionTravelCm = 14f,
                suspensionStiffness = 0.60f,
                baseTireGrip = 1.05f,
                steeringAngleDeg = 45f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 320000,
                sellPricePkr = 220000,
                repairBaseCostPkr = 8000,
                insuranceCostPkr = 6000,
                rarityTier = "STREET"
            ),
            interiorDetail = "Digital tachometer, clip-on handlebars, bar-end mirrors, quick-turn throttle.",
            audioProfile = "High-revving single-cylinder roar with distinctive open-pipe crackle.",
            isHeroVehicle = true
        ),
        Vehicle(
            id = "veh_raptor_1000",
            name = "Raptor 1000RR",
            manufacturer = "Falcon Dynamics",
            category = VehicleCategory.MOTORCYCLE,
            categorySubtitle = "Liter-Class Superbike",
            description = "An uncompromising 200-horsepower racing superbike engineered for adrenaline-fueled highway speeds and severe lean angles.",
            protagonistAffinity = "Universal",
            defaultDistrictSpawn = "clifton_heights",
            physics = VehiclePhysicsSpecs(
                massKg = 185f,
                horsepower = 210,
                torqueNm = 118,
                topSpeedKmh = 320,
                acceleration0To100 = 2.9f,
                brakeForceKn = 11.5f,
                gearCount = 6,
                drivetrain = Drivetrain.RWD,
                dragCoefficient = 0.32f,
                suspensionTravelCm = 12f,
                suspensionStiffness = 0.85f,
                baseTireGrip = 1.20f,
                steeringAngleDeg = 36f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 4800000,
                sellPricePkr = 3400000,
                repairBaseCostPkr = 45000,
                insuranceCostPkr = 35000,
                rarityTier = "EXOTIC"
            ),
            interiorDetail = "Color TFT race dashboard with lean angle meter, lap timer, traction control settings.",
            audioProfile = "Screaming 14000 RPM inline-4 wail, quickshifter ignition cut pops.",
            isHeroVehicle = false
        ),
        Vehicle(
            id = "veh_karachi_70",
            name = "Karachi Metro 70cc",
            manufacturer = "Indus Motors",
            category = VehicleCategory.MOTORCYCLE,
            categorySubtitle = "Ubiquitous City Commuter",
            description = "The unkillable workhorse of Karachi. Millions navigate the streets on this lightweight, fuel-efficient commuter daily.",
            protagonistAffinity = "Universal",
            defaultDistrictSpawn = "saddar_central",
            physics = VehiclePhysicsSpecs(
                massKg = 82f,
                horsepower = 8,
                torqueNm = 12,
                topSpeedKmh = 90,
                acceleration0To100 = 14.5f,
                brakeForceKn = 4.0f,
                gearCount = 4,
                drivetrain = Drivetrain.RWD,
                dragCoefficient = 0.42f,
                suspensionTravelCm = 10f,
                suspensionStiffness = 0.50f,
                baseTireGrip = 0.85f,
                steeringAngleDeg = 48f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 145000,
                sellPricePkr = 95000,
                repairBaseCostPkr = 3500,
                insuranceCostPkr = 2500,
                rarityTier = "COMMON"
            ),
            interiorDetail = "Simple analog speedometer with neutral gear light and turn signal indicator.",
            audioProfile = "High-pitched steady commuter thrum, mechanical chain buzz.",
            isHeroVehicle = false
        ),

        // BOATS & MARINE CRAFTS
        Vehicle(
            id = "veh_seadart_speedboat",
            name = "Indus Sea-Dart 32",
            manufacturer = "Karachi Marine Crafts",
            category = VehicleCategory.BOAT,
            categorySubtitle = "Twin-Outboard Offshore Speedboat",
            description = "A deep-V hull offshore speedboat equipped with dual 350hp marine outboards. Slices through Arabian Sea coastal waves with ease.",
            protagonistAffinity = "Ayan Khan",
            defaultDistrictSpawn = "ocean_drive",
            physics = VehiclePhysicsSpecs(
                massKg = 2200f,
                horsepower = 700,
                torqueNm = 840,
                topSpeedKmh = 115, // ~62 knots
                acceleration0To100 = 5.0f,
                brakeForceKn = 10.0f, // reverse water thrust
                gearCount = 2,
                drivetrain = Drivetrain.WATER_JET,
                dragCoefficient = 0.22f, // hydrodynamic
                suspensionTravelCm = 35f, // wave heave
                suspensionStiffness = 0.55f,
                baseTireGrip = 0.85f, // water rudder authority
                steeringAngleDeg = 38f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 16000000,
                sellPricePkr = 11500000,
                repairBaseCostPkr = 110000,
                insuranceCostPkr = 90000,
                rarityTier = "EXOTIC"
            ),
            interiorDetail = "Waterproof marine digital compass, dual throttle levers, GPS chartplotter, marine radio.",
            audioProfile = "Throaty twin-V6 marine outboard drone with resonant water bubbling at idle.",
            isHeroVehicle = true
        ),
        Vehicle(
            id = "veh_waverider_jetski",
            name = "WaveRider Stealth Jet-Ski",
            manufacturer = "Karachi Marine Crafts",
            category = VehicleCategory.BOAT,
            categorySubtitle = "High-Performance Personal Watercraft",
            description = "Ultra-nimble supercharged jet-ski engineered for jumping shoreline surf along Ocean Drive and navigating tight mangrove channels.",
            protagonistAffinity = "Universal",
            defaultDistrictSpawn = "ocean_drive",
            physics = VehiclePhysicsSpecs(
                massKg = 380f,
                horsepower = 300,
                torqueNm = 310,
                topSpeedKmh = 125, // ~67 knots
                acceleration0To100 = 3.4f,
                brakeForceKn = 7.0f,
                gearCount = 1,
                drivetrain = Drivetrain.WATER_JET,
                dragCoefficient = 0.18f,
                suspensionTravelCm = 20f,
                suspensionStiffness = 0.60f,
                baseTireGrip = 0.95f,
                steeringAngleDeg = 42f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 3800000,
                sellPricePkr = 2700000,
                repairBaseCostPkr = 30000,
                insuranceCostPkr = 25000,
                rarityTier = "STREET"
            ),
            interiorDetail = "Handlebar-mounted LCD display, tether kill switch, waterproof storage locker.",
            audioProfile = "High-RPM supercharger whistle and high-pressure jet nozzle water wash.",
            isHeroVehicle = false
        ),
        Vehicle(
            id = "veh_dhow_fishing",
            name = "Sindh Sagar Wooden Dhow",
            manufacturer = "Traditional Shipwrights",
            category = VehicleCategory.BOAT,
            categorySubtitle = "Heritage Coastal Fishing Vessel",
            description = "Handcrafted teak-wood fishing vessel with a heavy single diesel engine. Used by generational fishermen and covert creek contraband runners.",
            protagonistAffinity = "Universal",
            defaultDistrictSpawn = "fishing_village",
            physics = VehiclePhysicsSpecs(
                massKg = 8500f,
                horsepower = 220,
                torqueNm = 920,
                topSpeedKmh = 35, // ~19 knots
                acceleration0To100 = 18.0f,
                brakeForceKn = 12.0f,
                gearCount = 3,
                drivetrain = Drivetrain.WATER_JET,
                dragCoefficient = 0.38f,
                suspensionTravelCm = 45f,
                suspensionStiffness = 0.40f,
                baseTireGrip = 0.70f,
                steeringAngleDeg = 30f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 4500000,
                sellPricePkr = 3100000,
                repairBaseCostPkr = 40000,
                insuranceCostPkr = 28000,
                rarityTier = "COMMON"
            ),
            interiorDetail = "Wooden steering wheel, brass engine telegraph, hanging oil lantern, fish hold hatch.",
            audioProfile = "Slow, heavy 1-cylinder maritime diesel chug (tuk-tuk-tuk) with deep hull reverberation.",
            isHeroVehicle = false
        ),

        // AIRCRAFT & HELICOPTERS
        Vehicle(
            id = "veh_daniyal_skyhawk",
            name = "Executive Sky-Hawk H145",
            manufacturer = "Aero Falcon",
            category = VehicleCategory.AIRCRAFT,
            categorySubtitle = "Twin-Turbine VIP Luxury Helicopter",
            description = "Daniyal's private corporate transport. Features Fenestron shrouded tail rotor, four-axis autopilot, and whisper-quiet executive interior.",
            protagonistAffinity = "Daniyal Qureshi",
            defaultDistrictSpawn = "metro_airport",
            physics = VehiclePhysicsSpecs(
                massKg = 3800f,
                horsepower = 1600,
                torqueNm = 2400,
                topSpeedKmh = 270,
                acceleration0To100 = 5.5f,
                brakeForceKn = 15.0f,
                gearCount = 1,
                drivetrain = Drivetrain.AERO_ROTOR,
                dragCoefficient = 0.28f,
                suspensionTravelCm = 15f,
                suspensionStiffness = 0.80f,
                baseTireGrip = 1.0f,
                steeringAngleDeg = 45f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 120000000,
                sellPricePkr = 85000000,
                repairBaseCostPkr = 850000,
                insuranceCostPkr = 750000,
                rarityTier = "BLACK_MARKET"
            ),
            interiorDetail = "Four luxury executive captain chairs, satellite phone, noise-canceling headsets, glass glass cockpit MFDs.",
            audioProfile = "High-pitched jet turbine spool-up, resonant rotor blade chop, subdued cabin hum.",
            isHeroVehicle = true
        ),

        // CIVILIAN TRAFFIC & EMERGENCY
        Vehicle(
            id = "veh_metro_taxi",
            name = "Karachi Metro Yellow-Black Cab",
            manufacturer = "Indus Motors",
            category = VehicleCategory.CIVILIAN,
            categorySubtitle = "Standard Municipal Sedan Taxi",
            description = "The iconic black and yellow compact sedan taxi found on every corner from Saddar to the Airport.",
            protagonistAffinity = "Universal",
            defaultDistrictSpawn = "saddar_central",
            physics = VehiclePhysicsSpecs(
                massKg = 1120f,
                horsepower = 95,
                torqueNm = 135,
                topSpeedKmh = 160,
                acceleration0To100 = 11.8f,
                brakeForceKn = 9.0f,
                gearCount = 5,
                drivetrain = Drivetrain.FWD,
                dragCoefficient = 0.34f,
                suspensionTravelCm = 16f,
                suspensionStiffness = 0.50f,
                baseTireGrip = 0.88f,
                steeringAngleDeg = 40f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 1800000,
                sellPricePkr = 1200000,
                repairBaseCostPkr = 18000,
                insuranceCostPkr = 12000,
                rarityTier = "COMMON"
            ),
            interiorDetail = "Roof taxi fare meter, beaded seat covers, mechanical handbrake, radio cassette deck.",
            audioProfile = "Standard 1.3L inline-4 hum with occasional transmission whine.",
            isHeroVehicle = false
        ),
        Vehicle(
            id = "veh_w11_bus",
            name = "W-11 Decorated Metro Bus",
            manufacturer = "Master Fabricators",
            category = VehicleCategory.CIVILIAN,
            categorySubtitle = "Iconic Painted Public Transit Bus",
            description = "A world-renowned cultural symbol of Karachi. Completely adorned in intricate floral enamel artwork, reflective tape, brass bells, and a rooftop passenger deck.",
            protagonistAffinity = "Universal",
            defaultDistrictSpawn = "saddar_central",
            physics = VehiclePhysicsSpecs(
                massKg = 6800f,
                horsepower = 190,
                torqueNm = 620,
                topSpeedKmh = 110,
                acceleration0To100 = 16.5f,
                brakeForceKn = 22.0f,
                gearCount = 5,
                drivetrain = Drivetrain.RWD,
                dragCoefficient = 0.58f,
                suspensionTravelCm = 22f,
                suspensionStiffness = 0.75f,
                baseTireGrip = 0.82f,
                steeringAngleDeg = 36f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 7500000,
                sellPricePkr = 5200000,
                repairBaseCostPkr = 45000,
                insuranceCostPkr = 35000,
                rarityTier = "COMMON"
            ),
            interiorDetail = "Ornate wooden ceilings, velvet curtain trims, multi-tone air horn levers, passenger benches.",
            audioProfile = "Heavy un-muffled diesel rumble, multi-tone musical air horn, pneumatic door hisses.",
            isHeroVehicle = false
        ),
        Vehicle(
            id = "veh_police_interceptor",
            name = "Metro Police Pursuit Interceptor",
            manufacturer = "Indus Police Fleet",
            category = VehicleCategory.EMERGENCY,
            categorySubtitle = "V6 High-Speed Police Cruiser",
            description = "Upgraded tactical law enforcement sedan equipped with heavy front push bumper, strobe lights, siren, and tuned 380hp V6 engine.",
            protagonistAffinity = "Universal",
            defaultDistrictSpawn = "downtown",
            physics = VehiclePhysicsSpecs(
                massKg = 1750f,
                horsepower = 380,
                torqueNm = 480,
                topSpeedKmh = 270,
                acceleration0To100 = 4.7f,
                brakeForceKn = 17.0f,
                gearCount = 8,
                drivetrain = Drivetrain.AWD,
                dragCoefficient = 0.33f,
                suspensionTravelCm = 15f,
                suspensionStiffness = 0.75f,
                baseTireGrip = 1.05f,
                steeringAngleDeg = 38f
            ),
            economy = VehicleEconomyData(
                purchasePricePkr = 12000000,
                sellPricePkr = 8000000,
                repairBaseCostPkr = 60000,
                insuranceCostPkr = 50000,
                rarityTier = "EXOTIC"
            ),
            interiorDetail = "Police mobile data terminal (MDT), tactical radio console, shotgun rack between seats, rear prisoner cage.",
            audioProfile = "Urgent high-output V6 roar, multi-tone dual-siren wail and yelp, aggressive pursuit horn.",
            isHeroVehicle = false
        )
    )

    fun getVehicleById(id: String): Vehicle? = allVehicles.find { it.id == id }

    fun getVehiclesByCategory(category: VehicleCategory): List<Vehicle> =
        allVehicles.filter { it.category == category }

    fun getVehiclesByProtagonist(protagonistName: String): List<Vehicle> =
        allVehicles.filter { it.protagonistAffinity.contains(protagonistName, ignoreCase = true) || it.protagonistAffinity == "Universal" }

    // Room Database Garage Integration
    fun getAllGarageVehicles(): Flow<List<SavedVehicleEntity>> = worldDao.getAllGarageVehicles()

    fun getGarageVehiclesByOwner(ownerId: String): Flow<List<SavedVehicleEntity>> =
        worldDao.getGarageVehiclesByOwner(ownerId)

    suspend fun saveVehicleToGarage(entity: SavedVehicleEntity): Long =
        worldDao.insertGarageVehicle(entity)

    suspend fun removeVehicleFromGarage(entity: SavedVehicleEntity) =
        worldDao.deleteGarageVehicle(entity)

    suspend fun removeVehicleById(id: Long) =
        worldDao.deleteGarageVehicleById(id)
}
