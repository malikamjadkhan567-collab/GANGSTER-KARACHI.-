package com.example.data.model

enum class WeaponCategory(val displayName: String) {
    PISTOL("Sidearms & Pistols"),
    SMG("Submachine Guns"),
    ASSAULT_RIFLE("Assault & Battle Rifles"),
    SHOTGUN("Shotguns & Breachers"),
    MARKSMAN_SNIPER("Marksman & Sniper Rifles"),
    HEAVY("Heavy Ordnance"),
    MELEE("Close-Quarters Melee"),
    THROWABLE("Tactical Throwables")
}

enum class WeaponSlot(val title: String) {
    PRIMARY("Primary Rifle/Shotgun"),
    SECONDARY("Sidearm/SMG"),
    HEAVY("Heavy Support"),
    MELEE("Melee Weapon"),
    UTILITY("Tactical Utility")
}

enum class FiringMode(val label: String) {
    SEMI_AUTO("Semi-Automatic"),
    FULL_AUTO("Fully Automatic"),
    BURST_3("3-Round Burst"),
    PUMP_ACTION("Pump Action"),
    BOLT_ACTION("Bolt Action"),
    MELEE_SWING("Hand-to-Hand")
}

enum class AmmoType(val label: String, val baseDamage: Float) {
    AMMO_9MM("9x19mm Parabellum", 32f),
    AMMO_45ACP(".45 ACP Heavy", 42f),
    AMMO_44MAG(".44 Magnum Express", 75f),
    AMMO_556NATO("5.56x45mm NATO", 48f),
    AMMO_762SOVIET("7.62x39mm High-Impact", 58f),
    AMMO_12GAUGE("12-Gauge Buckshot", 95f),
    AMMO_308WIN(".308 Precision Match", 120f),
    AMMO_50BMG(".50 Anti-Material", 260f),
    AMMO_ROCKET("RPG High-Explosive Rocket", 450f),
    AMMO_GRENADE("40mm Concussion Grenade", 320f),
    AMMO_NONE("Melee Kinetic", 50f)
}

enum class AimState(val label: String, val accuracyMultiplier: Float, val zoomFov: Float) {
    HIP_FIRE("Hip Fire", 0.65f, 75f),
    SHOULDER_AIM("Shoulder Aim", 0.85f, 60f),
    ADS("Aim Down Sights (ADS)", 1.25f, 40f)
}

enum class PlayerStance(val label: String, val stealthBonus: Float) {
    STANDING("Standing Combat", 0f),
    CROUCHING("Crouched Stealth", 0.45f),
    SPRINTING("Sprinting", -0.30f),
    LOW_COVER("Behind Low Cover", 0.60f),
    HIGH_COVER("Peeking High Wall Cover", 0.70f)
}

enum class StealthState(val label: String) {
    HIDDEN("Undetected / Ghost"),
    SUSPICIOUS("Suspicious Investigation"),
    DETECTED("Target Identified"),
    SEARCHING("Searching Last Known Position"),
    ALERT("Combat Alert"),
    COMBAT("Full Engagement")
}

enum class HitZone(val multiplier: Float, val isCritical: Boolean) {
    HEAD(2.5f, true),
    TORSO(1.0f, false),
    ARMS(0.75f, false),
    LEGS(0.60f, false)
}

enum class ImpactSurface(val label: String, val particleEffect: String) {
    CONCRETE("Concrete Wall", "Dust Puff & Stone Chips"),
    METAL("Steel Sheet / Vehicle", "Sparks & Ricochet Whistle"),
    GLASS("Window / Windshield", "Glass Shatter & Fragments"),
    WOOD("Wooden Door / Crate", "Wood Splinters"),
    DIRT("Dirt Ground / Mud", "Dirt Blast & Smoke"),
    WATER("Coastal Water", "Water Plume Splash"),
    VEHICLE_BODY("Vehicle Armor", "Metallic Dent & Sparks")
}

data class WeaponRecoilProfile(
    val verticalKickDeg: Float,
    val horizontalDriftDeg: Float,
    val recoverySpeed: Float,
    val bloomSpreadDeg: Float
)

data class WeaponAttachments(
    var suppressorInstalled: Boolean = false,
    var opticType: String = "NONE", // NONE, RED_DOT, ACOG_4X, SNIPER_8X
    var extendedMag: Boolean = false,
    var laserSight: Boolean = false,
    var recoilCompensator: Boolean = false
)

data class Weapon(
    val id: String,
    val name: String,
    val manufacturer: String,
    val category: WeaponCategory,
    val defaultSlot: WeaponSlot,
    val firingMode: FiringMode,
    val baseDamage: Float,
    val effectiveRangeMeters: Float,
    val fireRateRpm: Int,
    val magazineCapacity: Int,
    val reloadTimeSec: Float,
    val recoil: WeaponRecoilProfile,
    val ammoType: AmmoType,
    val weightKg: Float,
    val rarityTier: String, // STREET, MILITARY, BLACK_MARKET, CUSTOM
    val description: String,
    val protagonistAffinity: String, // "Ayan Khan", "Shahroz Malik", "Daniyal Qureshi", "Universal"
    var attachments: WeaponAttachments = WeaponAttachments(),
    var currentMagazineAmmo: Int = magazineCapacity,
    var reserveAmmoTotal: Int = magazineCapacity * 4
)
