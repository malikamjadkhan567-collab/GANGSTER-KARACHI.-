package com.example.data.model

// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// MASTER PROMPT 05: 30 Story Missions, Roman Urdu Dialogue, Factions & Endings
// ==============================================================================

enum class StoryAct(val title: String, val subtitle: String, val missionRange: String) {
    ACT_I("Act I: Lyari to Kemari", "Street turf, harbor rackets, and early alliances", "Missions 01–08"),
    ACT_II("Act II: The Syndicate Alliance", "Coordinated bank vaults, highway interception, and sea heists", "Missions 09–16"),
    ACT_III("Act III: Betrayal & Cartel War", "Internal syndicate fractures, street ambushes, and martial lockdown", "Missions 17–24"),
    ACT_IV("Act IV: The Final Reckoning", "The grand Karachi Metro Port heist and climactic branch endings", "Missions 25–30")
}

enum class MissionStatus {
    LOCKED,
    AVAILABLE,
    IN_PROGRESS,
    COMPLETED,
    FAILED
}

data class DialogueLine(
    val speakerName: String,
    val speakerId: String, // ayan, shahroz, daniyal, faction_boss, structural
    val romanUrduText: String,
    val englishTranslation: String,
    val speakerAccentHex: Long,
    val audioDurationMs: Long = 3500L,
    val emotion: String = "Neutral" // Agitated, Whispering, Tactical, Confident, Threatening
)

data class MissionObjective(
    val description: String,
    val isCompleted: Boolean = false,
    val isOptional: Boolean = false,
    val goldCondition: String = ""
)

data class StoryMission(
    val id: String,
    val act: StoryAct,
    val missionNumber: Int,
    val title: String,
    val summary: String,
    val protagonistIds: List<String>, // "ayan", "shahroz", "daniyal"
    val districtId: String,
    val districtName: String,
    val worldCoordsX: Float,
    val worldCoordsY: Float,
    val rewardCashPkr: Long,
    val rewardFactionId: String,
    val rewardFactionPoints: Int,
    val unlockedVehicleId: String? = null,
    val unlockedWeaponId: String? = null,
    val dialogueScript: List<DialogueLine>,
    val objectives: List<MissionObjective>,
    var status: MissionStatus = MissionStatus.LOCKED,
    val heistPrepType: String? = null
)

enum class FactionStanding(val label: String, val policeResponseDesc: String) {
    HOSTILE("Hostile Enemy", "Open fire on sight, calls armed hit squads"),
    UNFRIENDLY("Distrusted Rival", "Denies access to territory, high extortion fees"),
    NEUTRAL("Neutral Business", "Allows transit, standard market rates"),
    ALLIED("Trusted Partner", "Provides armed ambient backup, safehouse access"),
    HONORED("Underworld Syndicate", "Unlocks top-tier black market weapons & custom tuning")
}

data class Faction(
    val id: String,
    val name: String,
    val shortCode: String,
    val districtTerritory: String,
    val description: String,
    val colorHex: Long,
    var reputationScore: Int, // -100 to +100
    val standing: FactionStanding,
    val bossName: String,
    val perkDescription: String
)

enum class StoryEndingChoice(
    val endingCode: String,
    val title: String,
    val synopsis: String,
    val survivorProtagonists: String,
    val moralTheme: String
) {
    ENDING_A_BROTHERHOOD(
        "ENDING_A",
        "The Karachi Brotherhood (All 3 Stand Together)",
        "Ayan, Shahroz, and Daniyal reject outside oligarch contracts and coordinate an unprecedented three-way counter-strike against the corrupt Sindh task force and cartels, securing undisputed control of Karachi Metro.",
        "Ayan, Shahroz & Daniyal all survive and rule the metropolitan underworld.",
        "Loyalty, solidarity, and street brotherhood triumph over corporate greed."
    ),
    ENDING_B_CORPORATE(
        "ENDING_B",
        "The Cantonment Financial Monopoly",
        "Daniyal triggers a billion-rupee financial takeover of the port authority, privatizing the shipping terminals and laundering the cartel funds into legitimate offshore tech corporations.",
        "Daniyal controls the corporate board; Ayan & Shahroz operate as covert executive enforcers.",
        "Pragmatism, high-finance capital, and modern state capitalism."
    ),
    ENDING_C_PORT_SIEGE(
        "ENDING_C",
        "The Port Lockdown & Iron Bastion",
        "Shahroz locks down the entire Kemari Port District behind shipping container fortifications, turning the harbor into an impenetrable sovereign stronghold.",
        "Shahroz rules the harbor with an iron fist; street turf falls to secondary syndicates.",
        "Uncompromising military grit, fortified defiance, and heavy firepower."
    ),
    ENDING_D_LONE_GHOST(
        "ENDING_D",
        "The Ghost of Karachi (Solo Disappearance)",
        "Ayan intercepts the sovereign bearer bonds alone during the confusion of the Port Heist, fleeing on a modified offshore hydroplane into the Arabian Sea sunset.",
        "Ayan vanishes with 200M PKR into international waters; Karachi Metro plunges into power vacuum.",
        "Individual survival, untamable street freedom, and living as a legend."
    )
}
