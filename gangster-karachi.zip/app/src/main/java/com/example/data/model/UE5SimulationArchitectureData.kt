package com.example.data.model

object UE5SimulationArchitectureData {

    val worldSimulationHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiWorldSimulationSubsystem
// Engine Target: Unreal Engine 5.4+ (Lumen, Nanite, World Partition, Mass Entity)
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Engine/DirectionalLight.h"
#include "Engine/SkyLight.h"
#include "KarachiWorldSimulationSubsystem.generated.h"

UENUM(BlueprintType)
enum class EKarachiDayNightPhase : uint8
{
    PreDawn,
    Dawn,
    Morning,
    Midday,
    Afternoon,
    GoldenHour,
    Sunset,
    Evening,
    Night,
    LateNight
};

UENUM(BlueprintType)
enum class EKarachiWeatherState : uint8
{
    Clear,
    PartlyCloudy,
    Cloudy,
    Overcast,
    LightRain,
    HeavyRain,
    Storm,
    Fog,
    DustyHazy,
    Windy
};

USTRUCT(BlueprintType)
struct GANGSTERKARACHI_API FKarachiClockData
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | Clock")
    int32 Day = 1;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | Clock")
    float CurrentHour = 12.0f; // 0.0 - 24.0

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | Clock")
    float TimeSpeedMultiplier = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | Clock")
    EKarachiDayNightPhase CurrentPhase = EKarachiDayNightPhase::Midday;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnWeatherChangedSignature, EKarachiWeatherState, NewWeather);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnDayNightPhaseChangedSignature, EKarachiDayNightPhase, NewPhase);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnLightningFlashSignature, FVector, FlashOrigin, float, Intensity);

/**
 * Centralized World Simulation Subsystem for Karachi Metro.
 * Synchronizes Sun/Moon trajectory, Lumen skylight bounce, atmospheric fog,
 * street light grid activation, and weather transitions.
 */
UCLASS()
class GANGSTERKARACHI_API UKarachiWorldSimulationSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    virtual void Initialize(FSubsystemCollectionBase& Collection) override;
    virtual void Deinitialize() override;

    UFUNCTION(BlueprintCallable, Category = "Karachi | Simulation")
    void SetGameHour(float InHour);

    UFUNCTION(BlueprintCallable, Category = "Karachi | Simulation")
    void SetWeatherState(EKarachiWeatherState InWeather, float TransitionDurationSec = 15.0f);

    UFUNCTION(BlueprintCallable, Category = "Karachi | Simulation")
    void TriggerMonsoonLightning();

    UFUNCTION(BlueprintPure, Category = "Karachi | Simulation")
    float GetRoadGripFactor() const { return RoadGripFactor; }

    UFUNCTION(BlueprintPure, Category = "Karachi | Simulation")
    float GetRainIntensity() const { return CurrentRainIntensity; }

    UPROPERTY(BlueprintAssignable, Category = "Karachi | Events")
    FOnWeatherChangedSignature OnWeatherChanged;

    UPROPERTY(BlueprintAssignable, Category = "Karachi | Events")
    FOnDayNightPhaseChangedSignature OnPhaseChanged;

    UPROPERTY(BlueprintAssignable, Category = "Karachi | Events")
    FOnLightningFlashSignature OnLightningStrike;

protected:
    void AdvanceClock(float DeltaTime);
    void UpdateSunMoonLumenLighting();
    void UpdateStreetLightsGrid(bool bEnable);

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Karachi | State")
    FKarachiClockData ClockData;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Karachi | State")
    EKarachiWeatherState ActiveWeather = EKarachiWeatherState::Clear;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Karachi | Parameters")
    float RoadGripFactor = 1.0f;

    UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Karachi | Parameters")
    float CurrentRainIntensity = 0.0f;

    UPROPERTY()
    ADirectionalLight* SunLightActor;

    UPROPERTY()
    ADirectionalLight* MoonLightActor;

    UPROPERTY()
    ASkyLight* SkyLightActor;
};
    """.trimIndent()

    val trafficManagerHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiTrafficManager
// Integration: Chaos Vehicles + Mass Entity AI Traffic
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "KarachiTrafficManager.generated.h"

UENUM(BlueprintType)
enum class ETrafficLightState : uint8
{
    Green,
    Yellow,
    Red,
    EmergencyPriority
};

USTRUCT(BlueprintType)
struct GANGSTERKARACHI_API FKarachiTrafficLane
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | Traffic")
    FName LaneID;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | Traffic")
    float SpeedLimitKmh = 50.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | Traffic")
    ETrafficLightState CurrentSignal = ETrafficLightState::Green;
};

/**
 * Manages procedural vehicle flow, Karachi W-11 buses, rickshaws, and
 * priority emergency corridor routing.
 */
UCLASS()
class GANGSTERKARACHI_API AKarachiTrafficManager : public AActor
{
    GENERATED_BODY()

public:
    AKarachiTrafficManager();

    UFUNCTION(BlueprintCallable, Category = "Karachi | Traffic")
    void TriggerEmergencyCorridor(FVector SirenLocation, float ClearanceRadiusMeters = 150.0f);

    UFUNCTION(BlueprintCallable, Category = "Karachi | Traffic")
    void SpawnProceduralAccident(FName TargetLaneID, FVector CollisionPoint);

    UFUNCTION(BlueprintCallable, Category = "Karachi | Traffic")
    void SetRainSlickMultiplier(float Slickness);

protected:
    virtual void Tick(float DeltaTime) override;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | Traffic")
    TArray<FKarachiTrafficLane> ActiveLanes;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Karachi | LOD")
    float HighLODRadius = 5000.0f; // 50 meters
};
    """.trimIndent()

    val pedestrianCrowdHeader = """
// ==============================================================================
// GANGSTER KARACHI — NEXT GEN
// Module: KarachiPedestrianCrowdSubsystem
// Integration: UE5 Mass Crowds + Smart Object Schedules
// ==============================================================================

#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "KarachiPedestrianCrowdSubsystem.generated.h"

UENUM(BlueprintType)
enum class EKarachiNPCSchedule : uint8
{
    MorningCommute,
    DaytimeWork,
    EveningBazaar,
    NightLeisure,
    LateNightQuiet
};

USTRUCT(BlueprintType)
struct GANGSTERKARACHI_API FKarachiCrowdPerception
{
    GENERATED_BODY()

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float HearingRadiusMeters = 40.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    float SightConeDegrees = 110.0f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite)
    bool bReactsToWeapons = true;
};

UCLASS()
class GANGSTERKARACHI_API UKarachiPedestrianCrowdSubsystem : public UWorldSubsystem
{
    GENERATED_BODY()

public:
    UFUNCTION(BlueprintCallable, Category = "Karachi | Crowd")
    void BroadcastWorldEvent(FVector Origin, float PanicRadius, bool bIsGunfire);

    UFUNCTION(BlueprintCallable, Category = "Karachi | Crowd")
    void UpdateWeatherReactions(bool bIsRaining);

    UFUNCTION(BlueprintPure, Category = "Karachi | Crowd")
    int32 GetActivePedestrianCount() const { return ActiveCount; }

private:
    int32 ActiveCount = 0;
};
    """.trimIndent()
}
