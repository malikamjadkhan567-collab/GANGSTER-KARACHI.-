package com.example.data.repository

import com.example.data.local.WorldDao
import com.example.data.local.WorldSimulationEntity
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class WorldSimulationRepository(private val dao: WorldDao) {

    // Dynamic Pedestrians Catalog across Karachi Metro
    val initialPedestrians: List<PedestrianAgent> = listOf(
        PedestrianAgent(
            id = "ped_01",
            name = "Farhan Tariq",
            districtId = "d_downtown",
            worldPosX = 0.48f,
            worldPosY = 0.42f,
            state = PedestrianActionState.WALKING,
            dialogueSnippet = "Office time ho gaya hai, traffic check karo pehle.",
            hasUmbrella = false,
            outfitStyle = "Office Formal Suit",
            lodLevel = 0
        ),
        PedestrianAgent(
            id = "ped_02",
            name = "Chacha Rafiq",
            districtId = "d_saddar",
            worldPosX = 0.52f,
            worldPosY = 0.47f,
            state = PedestrianActionState.SHOPPING,
            dialogueSnippet = "Khaadi ki qameez ka kya rate lagaya hai bhai?",
            hasUmbrella = false,
            outfitStyle = "Traditional Cotton Kurta",
            lodLevel = 0
        ),
        PedestrianAgent(
            id = "ped_03",
            name = "Zubair Baloch",
            districtId = "d_lyari",
            worldPosX = 0.41f,
            worldPosY = 0.45f,
            state = PedestrianActionState.EATING,
            dialogueSnippet = "Lyari ka dhabay wala doodh patti chai zabardast hai!",
            hasUmbrella = false,
            outfitStyle = "Street Tracksuit",
            lodLevel = 0
        ),
        PedestrianAgent(
            id = "ped_04",
            name = "Captain Aslam",
            districtId = "d_kemari",
            worldPosX = 0.32f,
            worldPosY = 0.65f,
            state = PedestrianActionState.WORKING,
            dialogueSnippet = "Gantry 4 pe container utar raha hai, side pe hato!",
            hasUmbrella = false,
            outfitStyle = "Heavy Port Boiler Suit",
            lodLevel = 1
        ),
        PedestrianAgent(
            id = "ped_05",
            name = "Hamza & Bilal",
            districtId = "d_clifton",
            worldPosX = 0.43f,
            worldPosY = 0.72f,
            state = PedestrianActionState.RELAXING,
            dialogueSnippet = "Sea View ki thandi hawa chal rahi hai shaam ko.",
            hasUmbrella = false,
            outfitStyle = "Western Denim Casual",
            lodLevel = 1
        ),
        PedestrianAgent(
            id = "ped_06",
            name = "Rashid Khan",
            districtId = "d_orangi",
            worldPosX = 0.36f,
            worldPosY = 0.28f,
            state = PedestrianActionState.WAITING,
            dialogueSnippet = "Chingchi wale ko boli 50 rupay main Chowk tak le jaye.",
            hasUmbrella = false,
            outfitStyle = "Traditional Shalwar",
            lodLevel = 2
        ),
        PedestrianAgent(
            id = "ped_07",
            name = "Natasha Qureshi",
            districtId = "d_defence",
            worldPosX = 0.62f,
            worldPosY = 0.68f,
            state = PedestrianActionState.USING_PHONE,
            dialogueSnippet = "Yes dad, meeting finished at Marina Club, heading back.",
            hasUmbrella = false,
            outfitStyle = "Designer Silk Kurti",
            lodLevel = 0
        ),
        PedestrianAgent(
            id = "ped_08",
            name = "Constable Nawaz",
            districtId = "d_saddar",
            worldPosX = 0.54f,
            worldPosY = 0.44f,
            state = PedestrianActionState.INVESTIGATING,
            dialogueSnippet = "Gaari theek jagah park karo, traffic block ho rahi hai.",
            hasUmbrella = false,
            outfitStyle = "Sindh Police Uniform",
            lodLevel = 0
        )
    )

    // Dynamic Traffic Vehicles across Karachi Metro Arterials
    val initialTrafficVehicles: List<TrafficVehicleAgent> = listOf(
        TrafficVehicleAgent(
            id = "veh_trf_01",
            type = TrafficVehicleType.CHINGCHI_RICKSHAW,
            laneName = "M.A. Jinnah Road (Westbound)",
            currentSpeedKmh = 34f,
            targetSpeedKmh = 38f,
            isBraking = false,
            isYieldingToEmergency = false,
            headlightsOn = false,
            indicatorsLeft = false,
            indicatorsRight = false,
            distanceToFrontVehicleMeters = 8.5f,
            lodLevel = 0
        ),
        TrafficVehicleAgent(
            id = "veh_trf_02",
            type = TrafficVehicleType.METRO_W11_BUS,
            laneName = "Saddar Empress Loop",
            currentSpeedKmh = 40f,
            targetSpeedKmh = 42f,
            isBraking = false,
            isYieldingToEmergency = false,
            headlightsOn = false,
            indicatorsLeft = true,
            indicatorsRight = false,
            distanceToFrontVehicleMeters = 15.0f,
            lodLevel = 0
        ),
        TrafficVehicleAgent(
            id = "veh_trf_03",
            type = TrafficVehicleType.COROLLA_SEDAN,
            laneName = "Shahrah-e-Faisal Expressway",
            currentSpeedKmh = 68f,
            targetSpeedKmh = 70f,
            isBraking = false,
            isYieldingToEmergency = false,
            headlightsOn = false,
            indicatorsLeft = false,
            indicatorsRight = false,
            distanceToFrontVehicleMeters = 24.0f,
            lodLevel = 0
        ),
        TrafficVehicleAgent(
            id = "veh_trf_04",
            type = TrafficVehicleType.HEAVY_BEDFORD_TRUCK,
            laneName = "Kemari Marine Arterial",
            currentSpeedKmh = 32f,
            targetSpeedKmh = 35f,
            isBraking = false,
            isYieldingToEmergency = false,
            headlightsOn = false,
            indicatorsLeft = false,
            indicatorsRight = false,
            distanceToFrontVehicleMeters = 30.0f,
            lodLevel = 1
        ),
        TrafficVehicleAgent(
            id = "veh_trf_05",
            type = TrafficVehicleType.HONDA_125_BIKE,
            laneName = "Tariq Road Inbound",
            currentSpeedKmh = 48f,
            targetSpeedKmh = 50f,
            isBraking = false,
            isYieldingToEmergency = false,
            headlightsOn = false,
            indicatorsLeft = false,
            indicatorsRight = false,
            distanceToFrontVehicleMeters = 6.0f,
            lodLevel = 0
        ),
        TrafficVehicleAgent(
            id = "veh_trf_06",
            type = TrafficVehicleType.EDHI_AMBULANCE,
            laneName = "Jinnah Hospital Corridor",
            currentSpeedKmh = 72f,
            targetSpeedKmh = 75f,
            isBraking = false,
            isYieldingToEmergency = false,
            headlightsOn = true,
            indicatorsLeft = true,
            indicatorsRight = true,
            distanceToFrontVehicleMeters = 40.0f,
            lodLevel = 0
        ),
        TrafficVehicleAgent(
            id = "veh_trf_07",
            type = TrafficVehicleType.YELLOW_CAB,
            laneName = "Clifton Sea View Boulevard",
            currentSpeedKmh = 45f,
            targetSpeedKmh = 50f,
            isBraking = false,
            isYieldingToEmergency = false,
            headlightsOn = false,
            indicatorsLeft = false,
            indicatorsRight = false,
            distanceToFrontVehicleMeters = 18.0f,
            lodLevel = 1
        )
    )

    // Wildlife in Karachi Metro
    val initialWildlife: List<WildlifeAgent> = listOf(
        WildlifeAgent(
            id = "wl_01",
            species = WildlifeSpecies.SEAGULL,
            worldPosX = 0.44f,
            worldPosY = 0.76f,
            behaviorState = "Soaring Coastal Winds",
            reactionToHuman = "Circles overhead catching sea breeze"
        ),
        WildlifeAgent(
            id = "wl_02",
            species = WildlifeSpecies.STRAY_CAT,
            worldPosX = 0.51f,
            worldPosY = 0.48f,
            behaviorState = "Prowling Fish Market Alley",
            reactionToHuman = "Darts under vegetable cart when approached"
        ),
        WildlifeAgent(
            id = "wl_03",
            species = WildlifeSpecies.ROCK_PIGEON,
            worldPosX = 0.49f,
            worldPosY = 0.40f,
            behaviorState = "Feeding on Grain in Downtown Plaza",
            reactionToHuman = "Flocks take flight together on sudden noise"
        ),
        WildlifeAgent(
            id = "wl_04",
            species = WildlifeSpecies.STRAY_DOG,
            worldPosX = 0.35f,
            worldPosY = 0.62f,
            behaviorState = "Resting in Industrial Container Shade",
            reactionToHuman = "Alert gaze, barks if vehicle horns blare"
        ),
        WildlifeAgent(
            id = "wl_05",
            species = WildlifeSpecies.SEA_TURTLE,
            worldPosX = 0.22f,
            worldPosY = 0.78f,
            behaviorState = "Surfacing along Hawke's Bay Coast",
            reactionToHuman = "Submerges quietly beneath coastal tide"
        )
    )

    // Dynamic World Events
    val initialWorldEvents: List<DynamicWorldEvent> = listOf(
        DynamicWorldEvent(
            id = "evt_01",
            title = "Tariq Road Qingqi Fender Bender",
            category = WorldEventCategory.ACCIDENT,
            districtName = "Tariq Road Bazaar",
            description = "A delivery motorcycle nudged an overloaded Chingchi rickshaw near Liberty Chowk. Loud debate underway with spectators gathered.",
            romanUrduAmbientCall = "\"Ustaad! Break kyun nahi lagaya? Sara chashma toot gaya mera!\"",
            severityLevel = 1,
            policeInvolved = false,
            trafficRerouting = true,
            playerRewardCashPkr = 15000,
            coordinates = Pair(0.56f, 0.46f)
        ),
        DynamicWorldEvent(
            id = "evt_02",
            title = "High-Speed Saddar Police Mobile Pursuit",
            category = WorldEventCategory.CRIME_PURSUIT,
            districtName = "Saddar Historic Core",
            description = "Two armed suspects on an unnumbered 125 bike are evading a Sindh Police 4x4 mobile through narrow heritage lanes.",
            romanUrduAmbientCall = "\"Control room! Suspects Regal Chowk ki taraf mure hain, barricade lagao!\"",
            severityLevel = 4,
            policeInvolved = true,
            trafficRerouting = true,
            playerRewardCashPkr = 85000,
            coordinates = Pair(0.50f, 0.45f)
        ),
        DynamicWorldEvent(
            id = "evt_03",
            title = "Overheated Bedford on Marine Arterial",
            category = WorldEventCategory.CIVIL_EMERGENCY,
            districtName = "Kemari Docks",
            description = "A floral-decorated Bedford cargo truck's radiator boiled over, spilling steam across the harbor bridge approach.",
            romanUrduAmbientCall = "\"Ustaad garam paani nikal raha hai, radiator thanda hone do bhai!\"",
            severityLevel = 2,
            policeInvolved = false,
            trafficRerouting = true,
            playerRewardCashPkr = 25000,
            coordinates = Pair(0.33f, 0.63f)
        ),
        DynamicWorldEvent(
            id = "evt_04",
            title = "Sindh Monsoon Flash Drain Overflow",
            category = WorldEventCategory.ENVIRONMENTAL_HAZARD,
            districtName = "Shaheed-e-Millat Belt",
            description = "Torrential rain clogged stormwater culverts, creating 0.4m deep water puddles slowing sedans to a crawl.",
            romanUrduAmbientCall = "\"Pani barh gaya hai road pe, choti gaari mat ghusao band ho jaye gi!\"",
            severityLevel = 3,
            policeInvolved = false,
            trafficRerouting = true,
            playerRewardCashPkr = 40000,
            coordinates = Pair(0.58f, 0.52f)
        ),
        DynamicWorldEvent(
            id = "evt_05",
            title = "Defence VIP Armored Convoy Escort",
            category = WorldEventCategory.VIP_ESCORT,
            districtName = "Defence Gardens",
            description = "Three black SUVs with strobe flashers clearing traffic along Khayaban-e-Shahbaz heading toward the Marina Club.",
            romanUrduAmbientCall = "\"Gaadiyan baen janib karein! VIP convoy passing!\"",
            severityLevel = 2,
            policeInvolved = true,
            trafficRerouting = true,
            playerRewardCashPkr = 50000,
            coordinates = Pair(0.64f, 0.66f)
        )
    )

    // Room Database persistence
    fun getSavedSimulationState(): Flow<WorldSimulationEntity?> =
        dao.getWorldSimulationState()

    suspend fun saveSimulationState(
        clock: GameClock,
        env: EnvironmentSnapshot
    ) {
        val entity = WorldSimulationEntity(
            stateId = "primary_simulation",
            dayNumber = clock.dayNumber,
            hour = clock.hour,
            minute = clock.minute,
            second = clock.second,
            dayOfWeek = clock.dayOfWeek,
            season = clock.season,
            timeSpeedMultiplier = clock.timeSpeedMultiplier,
            weatherType = env.weatherType.name,
            rainIntensity = env.rainIntensity,
            fogDensity = env.fogDensity,
            windSpeedKmh = env.windSpeedKmh,
            windBearingDegrees = env.windBearingDegrees,
            streetLightsActive = env.streetLightsActive
        )
        dao.saveWorldSimulationState(entity)
    }
}
