package com.example.data.model

enum class CellState {
    LOADED,       // Within active radius (full Nanite mesh + collision + dynamic actors)
    HLOD,         // Hierarchical LOD (merged proxy mesh + simplified materials)
    UNLOADED,     // Culled from memory
    PRIORITY      // Player immediate cell + pre-streamed prediction
}

enum class WorldDataLayer(val layerName: String, val memoryMb: Float, val defaultLoaded: Boolean) {
    LAYER_TERRAIN_NANITE("DataLayer_TerrainNanite", 320f, true),
    LAYER_BUILDINGS_CORE("DataLayer_BuildingsCore", 540f, true),
    LAYER_PROPS_FOLIAGE("DataLayer_PropsFoliage", 210f, true),
    LAYER_INTERIORS_HERO("DataLayer_InteriorsHero", 180f, false),
    LAYER_TRAFFIC_NAV("DataLayer_TrafficNavGrid", 95f, true),
    LAYER_LUMEN_LIGHTING("DataLayer_LumenEmissive", 140f, true),
    LAYER_UNDERGROUND_SEWER("DataLayer_UndergroundTunnels", 115f, false)
}

data class StreamingCell(
    val gridX: Int,
    val gridY: Int,
    val worldCoordX: Float,
    val worldCoordY: Float,
    val state: CellState,
    val assignedDistrictId: String
)

enum class TimeOfDay(
    val label: String,
    val sunAngleDeg: Float,
    val ambientLux: Float,
    val lumenIndirectBounce: Float,
    val wetSurfaceReflectivity: Float,
    val skyTintHex: Long
) {
    DAWN("06:00 - Dawn Marine Mist", 12f, 1500f, 0.65f, 0.45f, 0xFF4A6572),
    NOON("12:00 - Intense Coastal Sun", 88f, 110000f, 1.0f, 0.20f, 0xFFE0F7FA),
    GOLDEN_HOUR("18:15 - Ocean Drive Sunset", 8f, 8500f, 0.90f, 0.75f, 0xFFFF7043),
    TWILIGHT("19:30 - Blue Hour Dusks", -4f, 400f, 0.40f, 0.60f, 0xFF283593),
    MIDNIGHT("01:00 - Neon Cyber Night", -55f, 50f, 0.25f, 0.85f, 0xFF0A0E1A)
}
