package com.example.data.model

enum class VehicleCameraView(val title: String) {
    CHASE_CLOSE("Chase Close"),
    CHASE_WIDE("Chase Wide"),
    COCKPIT_FIRST_PERSON("Cockpit (1st Person)"),
    HOOD_CAM("Hood Cam")
}

data class DrivingSimulationState(
    val currentSpeedKmh: Float = 0f,
    val currentRpm: Float = 900f,
    val currentGear: Int = 1,
    val isReverse: Boolean = false,
    val throttleInput: Float = 0f,
    val brakeInput: Float = 0f,
    val steeringAngleDeg: Float = 0f,
    val handbrakeActive: Boolean = false,
    val lateralGForce: Float = 0f,
    val longitudinalGForce: Float = 0f,
    val activeSurface: RoadSurface = RoadSurface.DRY_ASPHALT,
    val absActive: Boolean = true,
    val tcsActive: Boolean = true,
    val escActive: Boolean = true,
    val headlightsOn: Boolean = true,
    val highBeamsOn: Boolean = false,
    val policeSirenActive: Boolean = false,
    val hornActive: Boolean = false,
    val cameraView: VehicleCameraView = VehicleCameraView.CHASE_CLOSE,
    val engineTempC: Float = 88f,
    val tireSlipPercentage: Float = 0f,
    val suspensionCompressionFL: Float = 0.5f,
    val suspensionCompressionFR: Float = 0.5f,
    val suspensionCompressionRL: Float = 0.5f,
    val suspensionCompressionRR: Float = 0.5f
)
