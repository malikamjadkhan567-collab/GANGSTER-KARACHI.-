package com.example.data.model

enum class LandmarkCategory(val title: String) {
    EMERGENCY("Emergency Services"),
    COMMERCE("Commerce & Retail"),
    TRANSPORTATION("Transit & Logistics"),
    ENTERTAINMENT("Entertainment & Leisure"),
    GAMEPLAY("Gameplay & Safehouses")
}

enum class InteriorTier(val tierName: String, val description: String) {
    TIER_1_HERO("Tier 1 — Hero Interior", "Fully modeled, custom physics, bespoke lighting and mission interactives"),
    TIER_2_GAMEPLAY("Tier 2 — Gameplay Interior", "Functional modular interiors (shops, garages, offices, safehouses)"),
    TIER_3_BACKGROUND("Tier 3 — Exterior Only", "Exterior Nanite mesh with parallax interior cubemaps and baked emissives")
}

data class Landmark(
    val id: String,
    val name: String,
    val districtId: String,
    val category: LandmarkCategory,
    val interiorTier: InteriorTier,
    val posX: Float, // relative 0.0 to 1.0
    val posY: Float,
    val description: String,
    val iconName: String,
    val elevationLevel: String = "Ground Level" // Underground, Ground, Elevated/Rooftop
)
